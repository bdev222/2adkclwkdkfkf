const slsw = require('serverless-webpack');

const webpackDevConfig = require('./client/webpack.dev.config');
const webpackProdConfig = require('./client/webpack.prod.config');

const isDev = slsw.lib.webpack.isLocal;

module.exports = isDev ? webpackDevConfig : webpackProdConfig;
