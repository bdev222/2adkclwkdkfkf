const autoprefixer = require('autoprefixer');

const babelLoader = {
  loader: require.resolve('babel-loader'),
  options: {
    compact: true,
    cacheDirectory: true,
  },
};

module.exports = (isDev = true) => ({
  mode: isDev ? 'development' : 'production',
  devtool: isDev ? 'source-map' : false,
  resolve: {
    extensions: ['.css', '.js', '.json', '.jsx', '.scss', '.ts', '.tsx'],
  },
  module: {
    rules: [
      {
        test: /\.(ts|tsx)$/,
        exclude: /node_modules/,
        use: [babelLoader],
      },
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: [babelLoader],
      },
      {
        // For global stylesheets
        test: /^((?!\.module).)*\.(sass|scss|less|css)$/,
        use: [
          {
            loader: 'isomorphic-style-loader',
          },
          {
            loader: require.resolve('css-loader'),
            options: {
              importLoaders: 1,
              sourceMap: isDev,
            },
          },
          {
            loader: require.resolve('postcss-loader'),
            options: {
              // Necessary for external CSS imports to work
              // https://github.com/facebookincubator/create-react-app/issues/2677
              ident: 'postcss',
              sourceMap: isDev,
              plugins: () => [
                require('postcss-flexbugs-fixes'),
                require('postcss-object-fit-images'),
                autoprefixer({
                  flexbox: 'no-2009',
                }),
              ],
            },
          },
          {
            loader: require.resolve('sass-loader'),
            options: {
              sourceMap: isDev,
            },
          },
        ],
      },
      {
        // For module stylesheets
        test: /\.module\.(sass|scss|less|css)$/,
        loader: [
          {
            loader: 'isomorphic-style-loader',
          },
          {
            loader: require.resolve('dts-css-modules-loader'),
            options: {
              namedExport: true,
            },
          },
          {
            loader: require.resolve('css-loader'),
            options: {
              importLoaders: 1,
              sourceMap: isDev,
              localsConvention: 'camelCaseOnly',
              modules: {
                localIdentName: isDev
                  ? '[name]__[local]-[hash:base64:4]'
                  : '[hash:base64:8]',
              },
            },
          },
          {
            loader: require.resolve('postcss-loader'),
            options: {
              // Necessary for external CSS imports to work
              // https://github.com/facebookincubator/create-react-app/issues/2677
              ident: 'postcss',
              sourceMap: isDev,
              plugins: () => [
                require('postcss-flexbugs-fixes'),
                require('postcss-object-fit-images'),
                autoprefixer({
                  flexbox: 'no-2009',
                }),
              ],
            },
          },
          {
            loader: require.resolve('sass-loader'),
            options: {
              sourceMap: isDev,
            },
          },
        ],
      },
    ],
  },
  plugins: [],
});
