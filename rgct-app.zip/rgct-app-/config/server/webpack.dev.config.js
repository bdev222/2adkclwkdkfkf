const merge = require('webpack-merge');

const baseConfig = require('../webpack.base.config');
const serverBaseConfig = require('./webpack.base.config');

module.exports = merge(baseConfig(), serverBaseConfig());