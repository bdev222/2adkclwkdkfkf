const fs = require('fs');
const FileManagerPlugin = require('filemanager-webpack-plugin');
const LoadablePlugin = require('@loadable/webpack-plugin');
const path = require('path');
const slsw = require('serverless-webpack');
const webpack = require('webpack');

const buildVersion =
  `${process.env.GIT_SEM_VERSION || ''}${process.env.ARTIFACT_VERSION || ''}` ||
  'local';

const entries = {};
Object.keys(slsw.lib.entries).forEach(
  key => (entries[key] = ['./src/source-map-install.js', slsw.lib.entries[key]])
);

module.exports = (isDev = true) => ({
  entry: entries,
  resolve: {
    modules: [path.resolve('./node_modules')],
  },
  output: {
    libraryTarget: 'commonjs2',
    path: path.resolve(__dirname, '../..', '.webpack'),
    filename: '[name].js',
  },
  externals: {
    sharp: 'sharp',
  },
  target: 'node',
  module: {
    rules: [
      {
        test: /\.html$/,
        exclude: /node_modules/,
        loader: 'html-loader',
        options: {
          interpolate: true,
          exportAsEs6Default: true,
          minimize: true,
        },
      },
      {
        test: [
          /\.jpe?g$/,
          /\.png$/,
          /\.svg$/,
          /\.ttf$/,
          /\.otf$/,
          /\.woff2?/,
          /\.eot/,
        ],
        loader: require.resolve('url-loader'),
      },
    ],
  },
  plugins: [
    new webpack.WatchIgnorePlugin([/\.scss\.d\.ts$/]),
    new LoadablePlugin({
      filename: 'node-loadable-stats.json',
    }),
    // Because serverless-webpack creates entry points based on configuration,
    // generated chunks for dynamic imports are not correctly placed in their
    // relative directories. This additional copy task rectifies that.
    // https://github.com/serverless-heaven/serverless-webpack/issues/523
    new FileManagerPlugin({
      onStart: {
        copy: [
          {
            source: '.*',
            destination: '.webpack/dependencies',
          },
        ],
      },
      onEnd: {
        copy: [
          {
            source: '.webpack/service/*.js',
            destination: '.webpack/service/src/functions/render',
          },
          {
            source: `dist/rgct/static/${buildVersion}/js/web-loadable-stats.json`,
            destination: '.webpack/service/web-loadable-stats.json',
          },
        ],
      },
    }),
  ],
});
