const axios = require('axios');
const errorOverlayMiddleware = require('react-dev-utils/errorOverlayMiddleware');
const merge = require('webpack-merge');
const noopServiceWorkerMiddleware = require('react-dev-utils/noopServiceWorkerMiddleware');
const webpack = require('webpack');

const baseConfig = require('../webpack.base.config');
const localBaseConfig = require('./webpack.base.config');

const toyotaProxyPrefixes = [
  '/analytics/',
  '/config/',
  '/content/',
  '/rest/',
  '/tagms/',
  '/tcom-apps/',
  '/tcom/',
  '/tcom1/',
  '/ToyotaSite/',
];

module.exports = merge(baseConfig(), localBaseConfig(), {
  entry: [require.resolve('react-dev-utils/webpackHotDevClient')],
  devServer: {
    contentBase: './public/',
    compress: true,
    hot: true,
    historyApiFallback: true,
    host: '0.0.0.0',
    proxy: [
      {
        context: '/rgct/api/**',
        target: 'http://localhost:3000',
        changeOrigin: true,
        secure: false,
      },
      {
        context: '/rgct/config/**',
        target: 'https://next.ws.tms.aws.toyota.com',
        changeOrigin: true,
        secure: false,
        pathRewrite(path) {
          return path.replace('/rgct/', '/');
        },
      },
      {
        context: [
          '/local-specials/**',
          '/**/local-specials/**',
          '/rgct/sharpr/**',
        ],
        target: 'http://localhost:3000',
        changeOrigin: true,
        secure: false,
      },
      {
        context: '/rgct/assets/**',
        target: 'https://dev.nonprod.rct.tms.aws.toyota.com/',
        auth: 'tcom_user:@1L!gaT0r',
        changeOrigin: true,
      },
      {
        context: toyotaProxyPrefixes.map(p => `${p}**`),
        target: 'https://staging.toyota.com',
        auth: 'tcom_user:@1L!gaT0r',
        changeOrigin: true,
        secure: false,
      },
      {
        changeOrigin: true,
        context: '/submitlead',
        secure: false,
        target: 'https://www.toyota.com',
      },
    ],
    before(app) {
      // This lets us open files from the runtime error overlay.
      app.use(errorOverlayMiddleware());
      // This service worker file is effectively a 'no-op' that will reset any
      // previous service worker registered for the same host:port combination.
      // We do this in development to avoid hitting the production cache if
      // it used the same host and port.
      // https://github.com/facebookincubator/create-react-app/issues/2272#issuecomment-302832432
      app.use(noopServiceWorkerMiddleware());
      app.use(async (req, res, next) => {
        if (
          !toyotaProxyPrefixes.find(p => req.path.startsWith(p)) &&
          !req.path.includes('/local-specials') &&
          (req.path.endsWith('/') || req.path.endsWith('.amp'))
        ) {
          console.log('Rendering URL:', req.originalUrl);
          try {
            const url = `http://localhost:3000/render${req.originalUrl}`;
            const params = {
              ...req.query,
              __siteContext__: 'true',
            };

            const { data } = await axios.get(url, {
              headers: {
                ...req.headers,
                cookie: req.headers.cookie || '',
              },
              maxRedirects: 0,
              params,
            });

            res.send(data);
          } catch (error) {
            if (error.response.status > 300 && error.response.status < 400) {
              return res
                .status(error.response.status)
                .header(error.response.headers)
                .send('');
            }

            console.log('SSR Failed', error);
            res
              .status(500)
              .send(
                `<h1>Internal Server Error</h1><p>Failed to proxy request to SSR Backend.<br/><strong>${error.message}</strong></p>`
              );
          }
        } else {
          return next();
        }
      });
    },
  },
  plugins: [new webpack.HotModuleReplacementPlugin()],
});
