const Dotenv = require('dotenv-webpack');
const fs = require('fs');
const LoadablePlugin = require('@loadable/webpack-plugin');
const path = require('path');
const webpack = require('webpack');

const appDirectory = fs.realpathSync(process.cwd());
const resolveApp = relativePath => path.resolve(appDirectory, relativePath);

const buildVersion = process.env.BUILD_VERSION || 'local';

const babelLoader = {
  loader: require.resolve('babel-loader'),
  options: {
    cacheDirectory: true,
    compact: true,
    sourceType: 'unambiguous',
  },
};

module.exports = (isDev = true) => ({
  entry: ['./src/app/client.index.tsx'],
  output: {
    filename: `rgct/static/${buildVersion}/js/client.bundle.js`,
    chunkFilename: `rgct/static/${buildVersion}/js/[name].chunk.js`,
    path: resolveApp('dist'),
    publicPath: '/',
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules\/(?!jsds-react|react-hook-form|react-spring)/,
        use: [babelLoader],
      },
      {
        test: /\.svg(\?v=\d+\.\d+\.\d+)?$/,
        issuer: {
          test: /\.(jsx?|tsx?)/,
        },
        use: ['@svgr/webpack', 'url-loader'],
      },
      {
        test: [
          /\.jpe?g$/,
          /\.png$/,
          /\.svg$/,
          /\.ttf$/,
          /\.otf$/,
          /\.woff2?/,
          /\.eot/,
        ],
        loader: require.resolve('url-loader'),
        options: {
          limit: 10000,
          name: `rgct/static/${buildVersion}/media/[name].[hash:8].[ext]`,
        },
      },
    ],
  },
  plugins: [
    new Dotenv({
      path: resolveApp('.serverless/.env'),
    }),
    new webpack.DefinePlugin({
      'process.env.NODE_ENV': JSON.stringify(
        isDev ? 'development' : 'production'
      ),
      'process.env.BUILD_ENV': JSON.stringify('client'),
    }),
    new LoadablePlugin({
      filename: `rgct/static/${buildVersion}/js/web-loadable-stats.json`,
    }),
  ],
});
