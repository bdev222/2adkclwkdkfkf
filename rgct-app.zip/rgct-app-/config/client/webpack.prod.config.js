const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const FileManagerPlugin = require('filemanager-webpack-plugin');
const merge = require('webpack-merge');

const baseConfig = require('../webpack.base.config');
const localBaseConfig = require('./webpack.base.config');

const buildVersion = process.env.BUILD_VERSION || 'local';

module.exports = merge(baseConfig(false), localBaseConfig(false), {
  plugins: [
    new CleanWebpackPlugin(),
    new FileManagerPlugin(
      {
        onEnd: {
          copy: [
            {
              source: 'public/rgct/static/local/public',
              destination: `dist/rgct/static/${buildVersion}/public`,
            },
          ],
        },
      },
      { verbose: true }
    ),
  ],
});
