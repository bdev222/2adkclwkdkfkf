const _ = require('lodash');

class ServerlessTDPActiveActive {
  constructor(serverless, opt) {
    this.serverless = serverless;
    if (opt.stage && !opt.region) {
      this.processStageName(opt);
    }

    this.hooks = {
      // 'after:package:createDeploymentArtifacts': this.createDeploymentArtifacts.bind(this)
      'aws:package:finalize:mergeCustomProviderResources': this.createDeploymentArtifacts.bind(this)
    };
  }

  processStageName(opt) {
    const tokens = opt.stage.split('-');
    
    if (tokens.length > 1) {
      this.serverless.cli.log(`Updating stage and region names from provided compound stage: ${opt.stage}`);

      // We have a formatted stage of both region and stage
      opt.stage = tokens.shift();
      opt.region = tokens.join('-');

      process.env.SERVERLESS_STAGE = process.env.SERVERLESS_STAGE || opt.stage;
      process.env.SERVERLESS_REGION = process.env.SERVERLESS_REGION || opt.region;
    } 
  }

  createDeploymentArtifacts() {
    // Find the deployment
    const template = this.serverless.service.provider.compiledCloudFormationTemplate;
    const deployments = _(template.Resources).pickBy(rsc => rsc.Type === 'AWS::ApiGateway::Deployment').keys().value();
    // console.log('Found deployments', deployments.value());

    // Find any base path mappings
    const mappings = _(template.Resources).pickBy(rsc => rsc.Type === 'AWS::ApiGateway::BasePathMapping');

    // Append the deployments as deps on the mappings
    mappings.each(mapping => mapping.DependsOn = (mapping.DependsOn || []).concat(deployments));

  }
}

module.exports = ServerlessTDPActiveActive;
