const chalk = require('chalk');
const fs = require('fs');
const os = require('os');
const path = require('path');

class ServerlessExportDotenvPlugin {

  constructor(serverless, options) {
    this.serverless = serverless;
    this.config = Object.assign({}, this.serverless.service.custom && this.serverless.service.custom.dotenv);

    this.hooks = {
      'before:package:createDeploymentArtifacts': this.storeEnv.bind(this),
      'before:offline:start:init': this.storeEnv.bind(this),
    };
  }

  storeEnv() {
    try {
      // Figure out where we are writing our env file
      var envFilename = this.config.path || '.env';
      this.serverless.cli.log(`DOTENV: Writing env to ${envFilename}`);

      if(!this.config.overwrite && fs.existsSync(envFilename)) {
        throw new Error('DOTENV: Environment file already exists. Use overwrite property or remove the file to continue.');
      }

      // Ensure the path to the file exists
      var dirName = path.dirname(envFilename);
      fs.mkdirSync(dirName, { recursive: true });

      // Figure out which keys we are interested in
      let envKeys = Object.keys(this.serverless.service.provider.environment);
      if (this.config.include) {
        envKeys = envKeys.filter(key => this.config.include.includes(key));
      }

      if (envKeys.length === 0) {
        throw new Error('DOTENV: No keys found to export');
      }

      // format the values
      const env = [];
      envKeys.forEach(key => {
        env.push(`${key}=${this.serverless.service.provider.environment[key]}${os.EOL}`);
      });

      // Dump it to the file
      fs.writeFileSync(envFilename, env.join(''), { encoding: 'utf8' });
    } catch (e) {
      console.error(chalk.red('\n Serverless Plugin Error --------------------------------------\n'));
      console.error(chalk.red(`  ${e.message}`));
    }
  }

}

module.exports = ServerlessExportDotenvPlugin
