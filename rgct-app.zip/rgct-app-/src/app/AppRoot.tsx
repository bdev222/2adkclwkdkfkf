import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FunctionComponent } from 'react';
import { Route, RouteComponentProps } from 'react-router-dom';

import RootDataLayerContextProvider from './components/shared/Analytics/RootDataLayerContext';
import RouteHandler from './routing/RouteHandler';

interface AppRootProps {
  path: string;
  Router: any;
  styles: any;
}

const AppRoot: FunctionComponent<AppRootProps> = ({ styles, path, Router }) => {
  useStyles(styles);

  const routeRenderFunc = (props: RouteComponentProps<any>) => (
    <RouteHandler {...props} />
  );

  return (
    <RootDataLayerContextProvider>
      <Router location={path} context={{}}>
        <Route path="/:lang([a-z]{2})?/:pageRoute*" render={routeRenderFunc} />
      </Router>
    </RootDataLayerContextProvider>
  );
};

export default AppRoot;
