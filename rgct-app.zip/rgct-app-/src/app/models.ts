import { WithJSDSContextsProps } from 'jsds-react';

import {
  Layout,
  PageContextMeta,
  SiteContext,
} from '../functions/layout/models';

export { Layout };

export enum Devices {
  Desktop = 'desktop',
  Mobile = 'mobile',
}

export type WithContexts = WithJSDSContextsProps<PageContextMeta, SiteContext>;

export type ActionType<
  TType extends string,
  TPayload = undefined
> = TPayload extends undefined
  ? { type: TType }
  : { type: TType; payload: TPayload };
