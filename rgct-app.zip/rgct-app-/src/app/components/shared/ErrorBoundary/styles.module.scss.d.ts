export const container: string;
export const details: string;
export const background: string;
export const content: string;
export const heading: string;
export const ctaContainer: string;
export const ctaButton: string;
