import useStyles from 'isomorphic-style-loader/useStyles';
import { JSDSPlaceholder, JSDSRendering } from 'jsds-react';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import useJsdsContexts from '../../../util/useJsdsContexts';
import Button from '../../html5/Button';
import createSectionBlock from '../Analytics/blocks/createSectionBlock';
import RootAnalyticsContext from '../Analytics/RootAnalyticsContext';
import GlobalDisclaimers from '../GlobalDisclaimers';
import styles from './styles.module.scss';

interface ErrorBoundaryProps {
  details?: {
    stack: string;
  };
  hasError: boolean;
  zipCode?: string;
}

const ErrorBoundary: FC<JSDSRendering<ErrorBoundaryProps>> = ({
  fields: { details, hasError, zipCode },
  placeholders,
}) => {
  useStyles(styles);

  const { t } = useTranslation();

  const { page } = useJsdsContexts();

  return !hasError ? (
    <>
      {placeholders.content && (
        <JSDSPlaceholder components={placeholders.content} />
      )}
    </>
  ) : (
    <RootAnalyticsContext blocks={[createSectionBlock('404 Message')]}>
      <div className={styles.background}>
        {details && (
          <div className={styles.details}>
            <pre>{details.stack}</pre>
          </div>
        )}
        <div className={styles.container}>
          <div className={styles.content}>
            <h2 className={styles.heading}>{t('errorBoundaryHeading')}</h2>
            <p>{t('errorBoundaryDescription')}</p>
          </div>
          <div className={styles.ctaContainer}>
            <Button
              as="link"
              className={styles.ctaButton}
              to={`${page.meta.route.prefix}/deals-incentives/`}
            >
              {t('viewAllOffers')}
            </Button>
          </div>
        </div>
        {zipCode && <GlobalDisclaimers zipCode={zipCode} />}
      </div>
    </RootAnalyticsContext>
  );
};

export default ErrorBoundary;
