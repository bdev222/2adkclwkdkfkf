import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, MouseEvent } from 'react';
import { useTranslation } from 'react-i18next';

import useJsdsContexts from '../../../util/useJsdsContexts';
import { useDisclaimersContext } from '../../html5/DisclaimersContext';
import AnalyticsContext from '../Analytics/AnalyticsContext';
import createLinkBlock from '../Analytics/blocks/createLinkBlock';
import createSectionBlock from '../Analytics/blocks/createSectionBlock';
import EventTypes from '../Analytics/EventTypes';
import useTrigger from '../Analytics/useTrigger';
import styles from './styles.module.scss';

interface GlobalDisclaimersProps {
  showLocalZipDisclaimer?: boolean;
  zipCode: string;
}

const GlobalDisclaimers: FC<GlobalDisclaimersProps> = ({
  showLocalZipDisclaimer = false,
  zipCode,
}) => {
  useStyles(styles);

  const { t } = useTranslation();

  const trigger = useTrigger();

  const { site } = useJsdsContexts();

  const { getDisclaimers } = useDisclaimersContext();

  const allDisclaimers = Array.from(getDisclaimers().values());

  const handleOpenZipModal = (event: MouseEvent<HTMLParagraphElement>) => {
    if (
      event.target instanceof HTMLElement &&
      event.target.tagName.toLowerCase() === 'button'
    ) {
      document.body.dispatchEvent(new CustomEvent('tcom.promptZipcode'));

      if (event.target.textContent) {
        const isValidZip = /^\d{5}$/.test(event.target.textContent);
        const text = isValidZip ? 'zip' : event.target.textContent;

        trigger(EventTypes.Click, createLinkBlock({ text }));
      }
    }
  };

  const disclaimerKey = showLocalZipDisclaimer
    ? 'localZipDisclaimer'
    : 'globalZipDisclaimer';

  return (
    <AnalyticsContext blocks={createSectionBlock('rct_disclaimer')}>
      <div id="desktop-disclaimers" className={styles.container}>
        <p
          className={styles.zipDisclaimer}
          dangerouslySetInnerHTML={{ __html: t(disclaimerKey, { zipCode }) }}
          onClick={handleOpenZipModal}
          role="presentation"
        />
        <p>{t('globalTdaDisclaimer', { tdaName: site.tdaConfig.name })}</p>
        {allDisclaimers.length > 0 && (
          <div className={styles.disclaimers}>
            {allDisclaimers.map(disclaimer => (
              <p id={`disclaimer-${disclaimer.code}`} key={disclaimer.code}>
                {disclaimer.index}. {disclaimer.description}
              </p>
            ))}
          </div>
        )}
      </div>
    </AnalyticsContext>
  );
};

export default GlobalDisclaimers;
