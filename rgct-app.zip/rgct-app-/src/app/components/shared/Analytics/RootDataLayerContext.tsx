import React, { createContext, FC, useContext, useState } from 'react';

import { AnalyticsBlock, AnalyticsBlockType, RootDataLayer } from './models';
import combineBlocks from './util/combineBlocks';

export const RootDataLayerContext = createContext<RootDataLayer | undefined>(
  undefined
);

export const useSetRootDataLayer = () => {
  const dataLayerContext = useContext(RootDataLayerContext);

  if (dataLayerContext === undefined) {
    throw new Error(
      'useSetRootDataLayer must be used within RootDataLayerContextProvider'
    );
  }

  const clearRootDataLayer = () => {
    dataLayerContext.setDataLayer({});
  };

  const setRootDataLayer = (
    blocks: AnalyticsBlockType | AnalyticsBlockType[]
  ) => {
    dataLayerContext.setDataLayer(combineBlocks(blocks));
  };

  return { clearRootDataLayer, setRootDataLayer };
};

const RootDataLayerContextProvider: FC = ({ children }) => {
  const [dataLayer, setDataLayer] = useState<AnalyticsBlock>({});

  return (
    <RootDataLayerContext.Provider value={{ dataLayer, setDataLayer }}>
      {children}
    </RootDataLayerContext.Provider>
  );
};

export default RootDataLayerContextProvider;
