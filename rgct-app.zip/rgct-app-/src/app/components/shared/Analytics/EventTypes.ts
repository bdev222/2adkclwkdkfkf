enum EventTypes {
  Click = 'aa-link',
  KmClick = 'km-link',
  KmPageLoad = 'km-pageload',
  PageLoad = 'aa-pageload',
  SubPageLoad = 'aa-subpageload',
}

export default EventTypes;
