export interface RootDataLayer {
  dataLayer: AnalyticsBlock;
  setDataLayer: (blocks: AnalyticsBlock) => void;
}

export interface AnalyticsBlock {
  [key: string]: string | undefined;
}

export type AnalyticsBlockFunction = (
  context: AnalyticsBlock,
  props?: any
) => AnalyticsBlock;

export type AnalyticsBlockType = AnalyticsBlock | AnalyticsBlockFunction;

export type ContextGenerator = (
  blocks?: AnalyticsBlockType | AnalyticsBlockType[]
) => AnalyticsBlock;

export type EventTrigger = (
  event: string,
  blocks: AnalyticsBlock | AnalyticsBlockType[]
) => void;
