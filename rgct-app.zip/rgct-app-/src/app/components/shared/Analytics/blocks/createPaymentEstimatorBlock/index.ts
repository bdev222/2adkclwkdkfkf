type Estimate = Partial<{
  annualMileage: string;
  aprTerm: string;
  buyOrLease: 'Buy' | 'Lease';
  creditScore: string;
  downPayment: string;
  owedTradeIn: string;
  tradeInValue: string;
}>;

type Vehicle = Partial<{
  seriesName: string;
  year: string;
}>;

export default function createPaymentEstimatorBlock(
  estimate: Estimate,
  vehicle: Vehicle
) {
  return {
    pe_annual_mileage: estimate.annualMileage || '',
    pe_apr_term: estimate.aprTerm || '',
    pe_buy_lease: estimate.buyOrLease || 'Buy',
    pe_credit_score: estimate.creditScore || '',
    pe_down_payment: estimate.downPayment || '',
    pe_model_name: `${vehicle.year} ${vehicle.seriesName}` || '',
    pe_owed_trade_in: estimate.owedTradeIn || '',
    pe_trade_in_value: estimate.tradeInValue || '',
  };
}
