export default function createSupressPageLoadBlock() {
  return {
    suppressPageLoad: 'true',
  };
}
