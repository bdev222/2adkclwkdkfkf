import { Dealer } from '../../../../html5/DealersContext/models';

type DealerBlockProps = 'city' | 'code' | 'metro' | 'name' | 'state' | 'zip';

type DealerBlock = Pick<Dealer, DealerBlockProps> & {
  brand?: string;
};

export default function createDealerBlock(dealer: DealerBlock) {
  return {
    dealer_brand: dealer.brand || 'Toyota',
    dealer_city: dealer.city,
    dealer_code: dealer.code,
    dealer_metro: dealer.metro,
    dealer_name: dealer.name,
    dealer_state: dealer.state,
    dealer_zipcode: dealer.zip,
  };
}
