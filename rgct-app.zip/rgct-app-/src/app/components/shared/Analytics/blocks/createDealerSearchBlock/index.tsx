interface DealerSearchBlock {
  brand?: string;
  queryTerm: string;
  queryType: string;
  resultsCount: number;
}

export default function createDealerSearchBlock({
  brand = 'Toyota',
  queryTerm,
  queryType,
  resultsCount,
}: DealerSearchBlock) {
  return {
    dealer_search_brand: brand,
    dealer_search_results_count: `${resultsCount}`,
    dealer_search_term: queryTerm,
    dealer_search_type: queryType,
  };
}
