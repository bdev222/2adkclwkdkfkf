export default function createCampaignCodeBlock(campaignCode: string) {
  return {
    form_campaign_code: campaignCode,
  };
}
