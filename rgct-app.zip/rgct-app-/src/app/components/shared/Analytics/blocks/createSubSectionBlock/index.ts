export default function createSubSectionBlock(subSection: string) {
  return {
    content_subsection: subSection,
  };
}
