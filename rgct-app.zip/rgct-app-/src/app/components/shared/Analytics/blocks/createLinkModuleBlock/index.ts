export default function createLinkModuleBlock(module: string) {
  return {
    link_module: module,
  };
}
