export default function createListItemBlock(index: number) {
  return {
    list_item_index: `${index}`,
  };
}
