function replaceWhitespace(input: string) {
  return input.replace(/\s/g, '_');
}

export default function createUserInputErrorBlock(
  fields: string | string[],
  messages: string | string[] = ''
) {
  const fieldsAsString = Array.isArray(fields) ? fields.join(',') : fields;

  const messagesAsString = Array.isArray(messages)
    ? messages.join(',')
    : messages;

  return {
    error_field: replaceWhitespace(fieldsAsString),
    error_message: replaceWhitespace(messagesAsString),
  };
}
