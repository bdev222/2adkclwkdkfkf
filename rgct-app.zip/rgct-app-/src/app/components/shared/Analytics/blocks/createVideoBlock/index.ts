import { mapKeys } from 'lodash';

interface VideoBlock {
  headline?: string;
  link: string;
  name?: string;
  title?: string;
}

export default function createVideoBlock(metrics: VideoBlock) {
  return mapKeys(metrics, (value, key) => {
    return `video_${key}`;
  });
}
