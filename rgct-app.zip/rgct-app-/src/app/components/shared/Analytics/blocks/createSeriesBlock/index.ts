type Series = Partial<{
  accessory: string[];
  baseMsrp: number;
  categories: Array<{
    code: string;
    name: string;
  }>;
  color: string;
  engineCode: string;
  exteriorCode: string;
  exteriorTitle: string;
  interiorCode: string;
  interiorTitle: string;
  seriesName: string;
  seriesTrimCode: string;
  transmission: string;
  trimCode: string;
  trimLabel: string;
  vehicleId: string;
  year: number | string;
}>;

function getPackages(series: Series) {
  return series.accessory ? series.accessory.join(',') : '';
}

export default function createSeriesBlock(series: Series) {
  return {
    series_body_style: '',
    series_brand: 'Toyota',
    series_category: series.categories
      ? series.categories.map(category => category.name).join(',')
      : '',
    series_code: series.seriesName || '',
    series_color: series.color || '',
    series_color_ext: series.exteriorTitle || '',
    series_color_ext_code: series.exteriorCode || '',
    series_color_int: series.interiorTitle || '',
    series_color_int_code: series.interiorCode || '',
    series_engine: series.engineCode || '',
    series_fuel_type: '',
    series_grade: series.trimLabel || series.trimCode || '',
    series_inventory_type: 'New',
    series_msrp: series.baseMsrp ? `${series.baseMsrp}` : '',
    series_number: series.seriesTrimCode || '',
    series_packages: getPackages(series),
    series_transmission: series.transmission || '',
    series_vehicleid: series.vehicleId || '',
    series_year: `${series.year || ''}`,
  };
}
