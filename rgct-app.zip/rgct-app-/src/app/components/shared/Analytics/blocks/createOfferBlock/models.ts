import {
  Offer as OfferFromService,
  OfferBase,
} from '../../../../../../functions/layout/transforms/util/getOffers/models';

type OfferProps =
  | 'bonus'
  | 'endDate'
  | 'id'
  | 'includedTrim'
  | 'ribbon'
  | 'series';

export type Offer = OfferBase & Pick<OfferFromService, OfferProps>;
