function getBreakpoint() {
  if (typeof window === 'undefined') {
    return 'unknown';
  }

  const { innerWidth } = window;
  if (innerWidth < 768) {
    return 'Small';
  } else if (innerWidth >= 768 && innerWidth < 960) {
    return 'Medium';
  } else {
    return 'Large';
  }
}

export default function createRootBlock(tdaCode: string, zipCode = '') {
  return {
    appname: 'rct',
    breakpoint: getBreakpoint(),
    tda_code: tdaCode,
    zipcode: zipCode,
  };
}
