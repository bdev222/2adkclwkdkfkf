export default function createOffersListBlock(filters?: string) {
  return {
    offer_list_filter: filters || '',
    offer_list_layout: 'grid',
  };
}
