import { LinkProps } from '../../../../html5/Link';
import EventTypes from '../../EventTypes';
import { AnalyticsBlockType } from '../../models';

export interface LinkBlockOptions {
  href?: LinkProps['to'];
  metrics?: string;
  text?: string;
  typeTitle?: string;
}

function normalizeHref(href: LinkProps['to']) {
  if (typeof href === 'function') {
    return '';
  }

  return typeof href === 'string' ? href : href.pathname;
}

function sanitizeText(text: string) {
  return text
    .replace(/(\r\n|\n|\r)/gm, '')
    .replace(/ /g, '_')
    .trim();
}

function buildUrlFromHref(href = '') {
  if (!href || typeof window === 'undefined') {
    return href;
  } else if (href.charAt(0) === '#') {
    // href starts with '#' tack on window.location.href
    return window.location.href + href;
  } else if (href.charAt(0) === '/') {
    // href starts with '/' tack on window.location.origin
    return window.location.origin + href;
  }

  return href;
}

export default function createLinkBlock({
  href = '#',
  metrics = '',
  text = 'Link',
  typeTitle,
}: LinkBlockOptions) {
  const km = Array.isArray(metrics) ? metrics.join(',') : metrics;

  const normalizedHref = normalizeHref(href);

  const block: AnalyticsBlockType = {
    link_action: km ? EventTypes.KmClick : EventTypes.Click,
    link_href: normalizedHref,
    link_text: sanitizeText(text),
    link_url: buildUrlFromHref(normalizedHref),
  };

  if (typeTitle) {
    block['link_type_title'] = sanitizeText(typeTitle);
  }

  if (km) {
    block.metrics = km;
  }

  return block;
}
