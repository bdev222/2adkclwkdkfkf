import { OfferType } from '../../../../../../functions/layout/transforms/util/getOffers/models';
import { AnalyticsBlock } from '../../models';
import { Offer } from './models';

function getBlockByType(offer: Offer) {
  switch (offer.type) {
    case OfferType.Apr: {
      const block: AnalyticsBlock = {
        offer_rate: offer.apr.rate,
        offer_term: offer.apr.duration,
      };

      if (offer.bonus) {
        block.offer_cashback = offer.bonus.amount;
      }

      return block;
    }
    case OfferType.Cash: {
      return {
        offer_cashback: offer.cash.rate,
      };
    }
    case OfferType.Lease: {
      return {
        offer_term: offer.lease.dueAtSigning,
        offer_amtdue: offer.lease.dueAtSigning,
        offer_monthly: offer.lease.monthlyPayment,
      };
    }
    default:
      return {};
  }
}

export default function createOfferBlock(offer: Offer) {
  const offerBlock = getBlockByType(offer);

  const isMultiVehicle = offer.series.length > 1;

  return {
    ...offerBlock,
    offer_category: 'Vehicle',
    offer_expired_date: `${offer.endDate.month}/${offer.endDate.day}`,
    offer_id: offer.id,
    offer_label: offer.ribbon,
    offer_series_brand: 'Toyota',
    offer_series_code: isMultiVehicle ? '' : offer.series[0].name[0],
    offer_series_grade: offer.includedTrim ?? '',
    offer_series_inventory_type: 'New',
    offer_series_year: isMultiVehicle ? '' : offer.series[0].year,
    offer_type: offer.type.toLowerCase(),
  };
}
