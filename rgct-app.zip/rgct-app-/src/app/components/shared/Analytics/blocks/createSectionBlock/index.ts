export default function createSectionBlock(section: string) {
  return {
    content_section: section,
  };
}
