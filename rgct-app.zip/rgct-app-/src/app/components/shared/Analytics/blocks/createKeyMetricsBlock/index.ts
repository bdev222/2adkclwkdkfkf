export default function createKeyMetricsBlock(...metrics: string[]) {
  return {
    metrics: metrics.filter(metric => !!metric).join(','),
  };
}
