import { AnalyticsBlock, AnalyticsBlockType } from '../../models';

export default function combineBlocks(
  blocks: AnalyticsBlockType | AnalyticsBlockType[],
  context?: AnalyticsBlock
): AnalyticsBlock {
  const blocksAsArray = Array.isArray(blocks) ? blocks : [blocks];

  const mappedBlocks = blocksAsArray
    .map(block =>
      typeof block === 'function' && typeof context !== 'undefined'
        ? block(context)
        : block
    )
    .filter(block => !!block);

  return Object.assign({}, ...mappedBlocks);
}
