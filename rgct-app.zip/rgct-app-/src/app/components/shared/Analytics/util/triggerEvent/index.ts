import getGlobalVariable from '../../../../../util/getGlobalVariable';
import EventTypes from '../../EventTypes';
import { AnalyticsBlock } from '../../models';

type QueuedEvent = [string, any];

const queuedEvents: QueuedEvent[] = [];

async function flushQueueOnLoad() {
  if (typeof window === 'undefined') {
    return;
  }

  const fireTag = await getGlobalVariable('fireTag');

  while (queuedEvents.length > 0) {
    const queuedEvent = queuedEvents.shift();

    if (queuedEvent) {
      fireTag(...queuedEvent);
    }
  }
}

flushQueueOnLoad();

function fireOrQueueTag(id: string, data: any) {
  if (typeof window === 'undefined') {
    return;
  }

  if (typeof window.fireTag === 'function' && queuedEvents.length === 0) {
    window.fireTag(id, data);
    return;
  }

  queuedEvents.push([id, data]);
}

export default function triggerEvent(event: string, block: AnalyticsBlock) {
  let fireEvent = event;

  if (
    event === EventTypes.Click &&
    block &&
    block.metrics &&
    block.metrics.length
  ) {
    fireEvent = block.metrics;
  }

  if (process.env.NODE_ENV === 'development') {
    console.groupCollapsed('Analytics Event:', fireEvent);
    console.table ? console.table(block) : console.log(block);
    console.groupEnd();
  }

  fireOrQueueTag(fireEvent, block);
}
