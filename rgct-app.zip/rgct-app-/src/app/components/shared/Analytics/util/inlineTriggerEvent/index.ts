import { AnalyticsBlockType } from '../../models';
import combineBlocks from '../combineBlocks';

interface InlineTriggerEvent {
  'data-analytics'?: string;
  'data-km'?: string;
  'data-trigger': string;
}

export default function inlineTriggerEvent(
  type: string,
  blocks?: AnalyticsBlockType | AnalyticsBlockType[],
  km?: string
) {
  const dataAttributes: InlineTriggerEvent = {
    'data-trigger': type,
  };

  if (blocks) {
    dataAttributes['data-analytics'] = JSON.stringify(combineBlocks(blocks));
  }

  if (km) {
    dataAttributes['data-km'] = km;
  }

  return dataAttributes;
}
