import React, {
  createElement,
  FC,
  ReactDOM,
  useContext,
  useEffect,
  useState,
} from 'react';
import { useInView } from 'react-intersection-observer';

import AnalyticsContext from '../AnalyticsContext';
import { DataLayerContext } from '../DataLayerContext';
import EventTypes from '../EventTypes';
import { AnalyticsBlockType } from '../models';
import useTrigger from '../useTrigger';
import combineBlocks from '../util/combineBlocks';

interface AnalyticsComponentProps {
  as?: keyof ReactDOM;
  blocks?: AnalyticsBlockType | AnalyticsBlockType[];
  className?: string;
  event?: EventTypes;
  initialBlocks?: AnalyticsBlockType | AnalyticsBlockType[];
  supressComponentView?: boolean;
  supressSubComponentView?: boolean;
  timeout?: number;
}

const AnalyticsComponent: FC<AnalyticsComponentProps> = ({
  as = 'div',
  blocks = [],
  children,
  className,
  event = EventTypes.SubPageLoad,
  initialBlocks = [],
  supressComponentView = false,
  supressSubComponentView = false,
  timeout = 2000,
}) => {
  const [ref, inView] = useInView();

  const context = useContext(DataLayerContext)();

  const trigger = useTrigger();

  const [hasFired, setHasFired] = useState(
    supressComponentView || context.supressComponentView === 'true'
  );

  const [timeoutId, setTimeoutId] = useState<number>();

  useEffect(() => {
    if (hasFired) {
      return;
    }

    inView ? handleComponentEnter() : handleComponentLeave();
  }, [hasFired, inView]);

  const handleEventTrigger = () => {
    if (hasFired) {
      return;
    }

    const initialBlocksAsArray = Array.isArray(initialBlocks)
      ? initialBlocks
      : [initialBlocks];

    trigger(
      event,
      combineBlocks([...blocksAsArray, ...initialBlocksAsArray], context)
    );

    setHasFired(true);
  };

  const handleComponentEnter = () => {
    clearTriggerTimeout();

    setTimeoutId(window.setTimeout(handleEventTrigger, timeout));
  };

  const handleComponentLeave = () => {
    clearTriggerTimeout();
  };

  const clearTriggerTimeout = () => {
    if (timeoutId) {
      clearTimeout(timeoutId);

      setTimeoutId(undefined);
    }
  };

  const blocksAsArray = Array.isArray(blocks) ? blocks : [blocks];

  const subComponentBlock = {
    supressComponentView: supressSubComponentView ? 'true' : 'false',
  };

  return (
    <AnalyticsContext blocks={[subComponentBlock, ...blocksAsArray]}>
      {createElement(as, { className, ref }, children)}
    </AnalyticsContext>
  );
};

export default AnalyticsComponent;
