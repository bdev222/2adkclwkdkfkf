import React, { FC, useEffect } from 'react';

import { AnalyticsBlockType } from '../models';
import { useSetRootDataLayer } from '../RootDataLayerContext';

interface RootAnalyticsContextProps {
  blocks: AnalyticsBlockType | AnalyticsBlockType[];
}

const RootAnalyticsContext: FC<RootAnalyticsContextProps> = ({
  blocks,
  children,
}) => {
  const { clearRootDataLayer, setRootDataLayer } = useSetRootDataLayer();

  useEffect(() => {
    setRootDataLayer(blocks);

    return () => {
      clearRootDataLayer();
    };
  }, []);

  return <>{children}</>;
};

export default RootAnalyticsContext;
