import { createElement, FC, ReactHTML } from 'react';

import { AnalyticsBlockType } from '../models';
import inlineTriggerEvent from '../util/inlineTriggerEvent';

interface AnalyticsInlineTriggerProps {
  as?: keyof ReactHTML;
  blocks?: AnalyticsBlockType | AnalyticsBlockType[];
  km?: string;
  type: string;
}

const AnalyticsInlineTrigger: FC<AnalyticsInlineTriggerProps> = ({
  as = 'div',
  blocks,
  children,
  km,
  type,
}) => {
  const dataAttributes = inlineTriggerEvent(type, blocks, km);

  return createElement(as, dataAttributes, children);
};

export default AnalyticsInlineTrigger;
