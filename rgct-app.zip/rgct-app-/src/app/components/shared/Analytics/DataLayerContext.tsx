import { createContext } from 'react';

import { AnalyticsBlockType, ContextGenerator } from './models';
import combineBlocks from './util/combineBlocks';

const defaultGenerator: ContextGenerator = (blocks?: AnalyticsBlockType) =>
  blocks ? combineBlocks(blocks) : {};

export const DataLayerContext = createContext(defaultGenerator);
