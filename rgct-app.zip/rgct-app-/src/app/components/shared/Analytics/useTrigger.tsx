import { useContext } from 'react';

import { DataLayerContext } from './DataLayerContext';
import { EventTrigger } from './models';
import combineBlocks from './util/combineBlocks';
import triggerEvent from './util/triggerEvent';

export default function useTrigger(): EventTrigger {
  const parentContext = useContext(DataLayerContext);

  return (event, blocks) => {
    const blocksAsArray = Array.isArray(blocks) ? blocks : [blocks];

    const context = combineBlocks([parentContext(), ...blocksAsArray]);

    triggerEvent(event, context);
  };
}
