import React, { ButtonHTMLAttributes, FC, MouseEvent, useRef } from 'react';

import createLinkBlock, { LinkBlockOptions } from '../blocks/createLinkBlock';
import EventTypes from '../EventTypes';
import useTrigger from '../useTrigger';

interface AnalyticsButtonProps extends ButtonHTMLAttributes<{}> {
  analytics?: Omit<LinkBlockOptions, 'href'>;
}

const AnalyticsButton: FC<AnalyticsButtonProps> = ({
  analytics = {},
  children,
  onClick,
  tabIndex = 0,
  ...remainingProps
}) => {
  const buttonRef = useRef<HTMLButtonElement>(null);

  const trigger = useTrigger();

  const handleButtonClick = (event: MouseEvent<HTMLButtonElement>) => {
    let text = analytics.text ?? '';
    if (!text && buttonRef.current?.textContent) {
      text = buttonRef.current.textContent;
    }

    trigger(EventTypes.Click, createLinkBlock({ ...analytics, text }));

    if (onClick) {
      onClick(event);
    }
  };

  return (
    <button
      {...remainingProps}
      onClick={handleButtonClick}
      ref={buttonRef}
      tabIndex={tabIndex}
    >
      {children}
    </button>
  );
};

export default AnalyticsButton;
