import React, {
  Children,
  cloneElement,
  FC,
  ReactElement,
  ReactNode,
} from 'react';

import { DataLayerContext } from './DataLayerContext';
import { AnalyticsBlockType } from './models';
import combineBlocks from './util/combineBlocks';

interface AnalyticsContextProps {
  blocks: AnalyticsBlockType | AnalyticsBlockType[];
  ssrOnly?: boolean;
}

function isDomElement(node: ReactNode): node is ReactElement {
  if (
    !!node &&
    typeof node === 'object' &&
    node.hasOwnProperty('type') &&
    typeof (node as ReactElement).type === 'string'
  ) {
    return true;
  }

  throw new Error(
    `Children of <AnalyticsContext> must be wrapped in a HTML element when "ssrOnly" is enabled: ${JSON.stringify(
      node
    )}`
  );
}

const AnalyticsContext: FC<AnalyticsContextProps> = ({
  blocks,
  children,
  ssrOnly = false,
}) => {
  return (
    <DataLayerContext.Consumer>
      {contextGenerator => {
        const parentContext = contextGenerator ? contextGenerator() : {};

        const combinedBlocks = combineBlocks(blocks, parentContext);

        const newContextProvider = () => ({
          ...parentContext,
          ...combinedBlocks,
        });

        return (
          <DataLayerContext.Provider value={newContextProvider}>
            {!ssrOnly
              ? children
              : Children.map(children, child =>
                  isDomElement(child)
                    ? cloneElement(child, {
                        'data-analytics': JSON.stringify(combinedBlocks),
                      })
                    : child
                )}
          </DataLayerContext.Provider>
        );
      }}
    </DataLayerContext.Consumer>
  );
};

export default AnalyticsContext;
