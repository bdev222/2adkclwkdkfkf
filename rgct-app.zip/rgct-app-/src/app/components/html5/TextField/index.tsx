import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import { uniqueId } from 'lodash';
import React, {
  ChangeEvent,
  FC,
  FocusEvent,
  InputHTMLAttributes,
  ReactNode,
  useState,
} from 'react';
import { useFormContext, ValidationOptions } from 'react-hook-form';

import Field from '../Field';
import { IconRequired } from '../Icons';
import styles from './styles.module.scss';

interface TextFieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  name: string;
  Icon?: ReactNode;
  validation?: ValidationOptions;
  variant?: 'outlined' | 'underlined';
}

const TextField: FC<TextFieldProps> = ({
  label,
  maxLength,
  name,
  onBlur,
  onChange,
  onFocus,
  placeholder,
  Icon,
  type,
  validation,
  variant = 'outlined',
  ...remainingProps
}) => {
  useStyles(styles);
  const { register, errors, getValues, setValue } = useFormContext();
  const [focused, setFocused] = useState(false);
  const value = getValues()[name];

  const handlePhoneInputChange = (event: ChangeEvent<HTMLInputElement>) => {
    const phone = event.currentTarget.value;
    const formattedPhone = phone
      .replace(/[^0-9]+/g, '')
      .replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3')
      .substring(0, 14);
    setValue(name, formattedPhone);
  };

  const handleInputBlur = (event: FocusEvent<HTMLInputElement>) => {
    setFocused(false);

    if (onBlur) {
      onBlur(event);
    }
  };

  const handleInputChange = (event: ChangeEvent<HTMLInputElement>) => {
    if (onChange) {
      onChange(event);
    }

    if (type === 'tel') {
      return handlePhoneInputChange(event);
    }

    if (type === 'number') {
      return setValue(name, event.currentTarget.value.replace(/[^0-9]/g, ''));
    }
  };

  const handleInputFocus = (event: FocusEvent<HTMLInputElement>) => {
    setFocused(true);

    if (onFocus) {
      onFocus(event);
    }
  };

  const labelId = uniqueId(`${name}-`);

  const isFocused =
    focused ||
    (variant === 'outlined' && placeholder) ||
    (value && value.length > 0);

  const hasError = !!errors[name];

  const error = errors[name];
  const errorMessage = !Array.isArray(error)
    ? error?.message
    : error[0].message;

  const placeholderMessage =
    variant === 'outlined'
      ? placeholder
      : !focused && label
      ? undefined
      : placeholder;

  return (
    <Field hasError={hasError}>
      <div className={styles.inputWrap}>
        {label && (
          <label
            className={cc([
              styles.label,
              {
                [styles.isFocused]: isFocused,
              },
            ])}
            htmlFor={labelId}
          >
            {label}
            {validation?.required && <IconRequired />}
          </label>
        )}
        <input
          {...remainingProps}
          className={cc([
            styles.input,
            {
              [styles.hasLabel]: label,
              [styles.isUnderlined]: variant === 'underlined',
              [styles.isOutlined]: variant === 'outlined',
              [styles.hasError]: !!errors[name],
            },
          ])}
          id={labelId}
          inputMode={type === 'number' ? 'numeric' : 'text'}
          maxLength={maxLength}
          name={name}
          onBlur={handleInputBlur}
          onChange={handleInputChange}
          onFocus={handleInputFocus}
          pattern={type === 'number' ? '[0-9]*' : undefined}
          placeholder={placeholderMessage}
          ref={validation ? register(validation) : register}
          type={type === 'number' ? 'text' : type}
        />
        {Icon && <span className={styles.icon}>{Icon}</span>}
      </div>
      {errorMessage && <span className={styles.error}>{errorMessage}</span>}
    </Field>
  );
};

export default TextField;
