export const defaultButton: string;
export const outlineButton: string;
export const textButton: string;
export const caret: string;
