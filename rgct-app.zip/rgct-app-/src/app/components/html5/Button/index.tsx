import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { ButtonHTMLAttributes, FC } from 'react';

import { IconArrow } from '../Icons';
import Link, { LinkProps } from '../Link';
import styles from './styles.module.scss';

interface ButtonLink extends LinkProps, ButtonBase {
  as: 'a' | 'link';
}

interface ButtonButton
  extends ButtonHTMLAttributes<HTMLButtonElement>,
    ButtonBase {
  as?: 'button';
  type?: 'button' | 'submit' | 'reset';
}

interface ButtonBase {
  isOutline?: boolean;
  isText?: boolean;
  showCaret?: boolean;
}

type ButtonProps = ButtonButton | ButtonLink;

function isLink(props: ButtonProps): props is ButtonLink {
  return props.as === 'a' || props.as === 'link';
}

const Button: FC<ButtonProps> = props => {
  const {
    as = 'button',
    className,
    children,
    isOutline = false,
    isText = false,
    showCaret = false,
    ...remainingProps
  } = props;

  useStyles(styles);

  const isDefault = !(isText || isOutline);

  const newProps = {
    className: cc([
      className,
      {
        [styles.defaultButton]: isDefault,
        [styles.outlineButton]: isOutline,
        [styles.textButton]: isText,
      },
    ]),
    ...remainingProps,
  };

  const content = (
    <span>
      {children}
      {showCaret && (
        <span className={styles.caret}>
          <IconArrow />
        </span>
      )}
    </span>
  );

  return isLink(props) ? (
    <Link {...newProps} as={props.as} to={props.to}>
      {content}
    </Link>
  ) : (
    <button {...newProps} type={props.type}>
      {content}
    </button>
  );
};

export default Button;
