import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { useHistory, useLocation } from 'react-router-dom';

import useJsdsContexts from '../../../util/useJsdsContexts';
import Link from '../Link';
import Label from './Label';
import styles from './styles.module.scss';

interface BackButtonProps {
  seriesId?: string;
  seriesName?: string;
}

const BackButton: FC<BackButtonProps> = ({ seriesId, seriesName }) => {
  useStyles(styles);

  const { t } = useTranslation('backButton');

  const history = useHistory();

  const location = useLocation();

  const { page } = useJsdsContexts();

  // If we don't store in state via useRef, `isFromOfferPage` changes
  // as soon as we click a link due the location changing.
  const { current: from } = useRef<string>(location.state?.from);

  const title = t(`common:${from === 'featuredOffers' ? from : 'allOffers'}`);

  const isFromOfferPage = from === 'allOffers' || from === 'featuredOffers';
  if (isFromOfferPage) {
    return (
      <button className={styles.button} onClick={history.goBack}>
        <Label eyebrow={t('backTo')} title={title} />
      </button>
    );
  }

  let pathname = `${page.meta.route.prefix}/deals-incentives/`;
  let search;

  if (seriesId) {
    pathname += `series/${seriesId}/`;
  } else {
    search = '?viewAllOffers=1';
  }

  return (
    <Link
      className={styles.button}
      to={{
        pathname,
        search,
        state: { from: 'offerDetail' },
      }}
    >
      <Label
        eyebrow={seriesName ? t('viewMore') : t('backTo')}
        title={seriesName ? t('vehicleOffers', { vehicle: seriesName }) : title}
      />
    </Link>
  );
};

export default BackButton;
