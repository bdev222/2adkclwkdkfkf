import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import { IconArrow } from '../../Icons';
import styles from './styles.module.scss';

interface LabelProps {
  eyebrow: string;
  title: string;
}

const Label: FC<LabelProps> = ({ eyebrow, title }) => {
  useStyles(styles);

  return (
    <span className={styles.label}>
      <IconArrow className={styles.svg} />
      <span>
        <span className={styles.eyebrow}>{eyebrow}</span>
        <span className={styles.title}>{title}</span>
      </span>
    </span>
  );
};

export default Label;
