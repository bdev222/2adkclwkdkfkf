export const label: string;
export const svg: string;
export const eyebrow: string;
export const title: string;
