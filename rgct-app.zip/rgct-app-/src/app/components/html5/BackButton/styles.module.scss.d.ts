export const button: string;
