import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import { chunk, uniqueId } from 'lodash';
import React, { FC, useMemo } from 'react';

import { RelatedOffer } from '../../../../functions/layout/transforms/util/getModule/models';
import AnalyticsComponent from '../../shared/Analytics/AnalyticsComponent';
import createSectionBlock from '../../shared/Analytics/blocks/createSectionBlock';
import Carousel from '../Carousel';
import OfferCard from '../OfferCard';
import styles from './styles.module.scss';

interface RelatedOfferModuleProps {
  offers: RelatedOffer[];
  title: string;
}

const RelatedOffersModule: FC<RelatedOfferModuleProps> = ({
  offers,
  title,
}) => {
  useStyles(styles);

  const slides = useMemo(() => {
    return chunk(offers, 3);
  }, [offers]);

  const id = useMemo(() => {
    return uniqueId('offer-carousel-');
  }, [offers]);

  return (
    <AnalyticsComponent blocks={createSectionBlock('related_offers_module')}>
      <section
        className={cc([
          styles.container,
          { [styles.hasOffers]: offers.length !== 0 },
        ])}
      >
        <h2 className={styles.heading}>{title}</h2>
        <div className={styles.nonCarouselOffers}>
          {offers.map(offer => (
            <OfferCard
              className={styles.offerCard}
              key={offer.id}
              offer={offer}
            />
          ))}
        </div>
        <div className={styles.carouselContainer}>
          <Carousel
            ariaControls={id}
            classNames={{
              nextClass: styles.next,
              previousClass: styles.prev,
              slidesClass: styles.slidesContainer,
            }}
            renderSlide={(slide: RelatedOffer[], index, activeSlide) => (
              <li className={styles.slide} role="button" key={index}>
                {slide.map(offer => (
                  <OfferCard
                    className={styles.offerCard}
                    key={offer.id}
                    offer={offer}
                    tabIndex={index === activeSlide ? 0 : -1}
                  />
                ))}
              </li>
            )}
            slides={slides}
          />
        </div>
      </section>
    </AnalyticsComponent>
  );
};

export default RelatedOffersModule;
