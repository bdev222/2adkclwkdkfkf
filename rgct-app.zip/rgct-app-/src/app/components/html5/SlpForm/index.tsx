import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, FormEvent, useRef, useState } from 'react';
import { FormContext, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

import getCampaignCode, {
  FormType,
  Location,
} from '../../../util/campaignCodes';
import getDeviceType from '../../../util/getDeviceType';
import getFormCode from '../../../util/getFormCode';
import useJsdsContexts from '../../../util/useJsdsContexts';
import AnalyticsContext from '../../shared/Analytics/AnalyticsContext';
import createCampaignCodeBlock from '../../shared/Analytics/blocks/createCampaignCodeBlock';
import createDealerBlock from '../../shared/Analytics/blocks/createDealerBlock';
import createKeyMetricsBlock from '../../shared/Analytics/blocks/createKeyMetricsBlock';
import createLinkBlock from '../../shared/Analytics/blocks/createLinkBlock';
import createSeriesBlock from '../../shared/Analytics/blocks/createSeriesBlock';
import createUserInputErrorBlock from '../../shared/Analytics/blocks/createUserInputErrorBlock';
import EventTypes from '../../shared/Analytics/EventTypes';
import useTrigger from '../../shared/Analytics/useTrigger';
import DealersContextProvider from '../DealersContext';
import { Dealer } from '../DealersContext/models';
import LoadingContent from '../LoadingContent';
import Form from './Form';
import {
  AnalyticsOptions,
  ClearSelectedDealer,
  FormValues,
  Offer,
  OnDealerSelect,
  OnSlpSuccess,
  Vehicle,
} from './models';
import formSchemas from './schemas';
import styles from './styles.module.scss';
import createOutgoingSlpForm from './util/createOutgoingSlpForm';
import setPreferredLanguage from './util/setPreferredLanguage';
import submitSlpForm from './util/submitSlpForm';

interface SlpFormProps {
  analytics?: AnalyticsOptions;
  location: Location;
  lockedDealer?: Dealer;
  offer?: Offer;
  onSuccess: OnSlpSuccess;
  preSelectedVehicle?: string;
  type: FormType;
  variation: 'modal' | 'module';
  vehicle?: Vehicle;
}

const SlpForm: FC<SlpFormProps> = ({
  analytics,
  location,
  lockedDealer,
  offer,
  onSuccess,
  preSelectedVehicle,
  type,
  variation,
  vehicle,
}) => {
  useStyles(styles);

  const { t } = useTranslation('slpForm');

  const trigger = useTrigger();

  const didFireStartMetric = useRef(false);

  const { page } = useJsdsContexts();

  const formProps = useForm<Partial<FormValues>>({
    defaultValues: {
      preferredLanguage: setPreferredLanguage(page),
      preferredTime: 'morning',
      vehicle: preSelectedVehicle,
    },
    mode: 'onBlur',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const [selectedDealer, setSelectedDealer] = useState<Dealer | undefined>(
    lockedDealer
  );

  const fields = formSchemas[type as keyof typeof formSchemas][variation];

  const formCode = getFormCode(type);

  const submitLabel =
    formCode === 'cad'
      ? t('contactDealerSubmit')
      : formCode === 'satd'
      ? t('scheduleTestDriveSubmit')
      : t('getQuote');

  const handleDealerSelect: OnDealerSelect = dealer => {
    setSelectedDealer(dealer);
  };

  const clearSelectedDealer: ClearSelectedDealer = () => {
    setSelectedDealer(undefined);
  };

  const handleFormSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const isValid = await formProps.triggerValidation();

    const blocks = [createLinkBlock({ text: submitLabel })];

    if (isValid && selectedDealer) {
      formProps.handleSubmit(async formValues => {
        const deviceType = getDeviceType();

        const campaignCode = getCampaignCode(
          deviceType,
          type,
          page.lang,
          location
        );

        const outgoingForm = createOutgoingSlpForm({
          campaignCode,
          deviceType,
          offer,
          values: formValues,
          vehicle,
        });

        blocks.push(
          createDealerBlock(selectedDealer),
          createCampaignCodeBlock(campaignCode)
        );

        if (!vehicle) {
          blocks.push(
            createSeriesBlock({
              seriesName: outgoingForm.vehicleModel,
              year: outgoingForm.vehicleYear,
            })
          );
        }

        setIsSubmitting(true);

        trigger(EventTypes.Click, blocks);

        const { data } = await submitSlpForm(outgoingForm);

        if (data.adfstatus.responseCode === 'ACCEPTED') {
          onSuccess(outgoingForm, selectedDealer);
        }

        setIsSubmitting(false);
      })(event);
    } else {
      const errorFields = Object.keys(formProps.errors);

      if (errorFields.length) {
        const keyMetrics = ['km-form_field_submit-error'];

        if (!didFireStartMetric.current) {
          keyMetrics.push(`km-${formCode}-start`);

          didFireStartMetric.current = true;
        }

        blocks.push(
          createKeyMetricsBlock(...keyMetrics),
          createUserInputErrorBlock(errorFields)
        );
      }

      trigger(EventTypes.Click, blocks);
    }
  };

  const getCampaignCodeBlock = () => {
    if (typeof window === 'undefined') {
      return {};
    }

    const deviceType = getDeviceType();
    const campaignCode = getCampaignCode(deviceType, type, page.lang, location);

    return createCampaignCodeBlock(campaignCode);
  };

  return (
    <AnalyticsContext
      blocks={[
        getCampaignCodeBlock,
        selectedDealer ? createDealerBlock(selectedDealer) : {},
      ]}
    >
      <DealersContextProvider>
        <FormContext {...formProps}>
          <LoadingContent
            containerClassName={styles.loaderContainer}
            isLoading={isSubmitting}
          >
            <Form
              analytics={analytics}
              clearSelectedDealer={clearSelectedDealer}
              didFireStartMetric={didFireStartMetric}
              fields={fields}
              formCode={formCode}
              hasOffer={!!offer}
              lockedDealer={lockedDealer}
              onDealerSelect={handleDealerSelect}
              onSubmit={handleFormSubmit}
              submitLabel={submitLabel}
              vehicle={vehicle}
            />
          </LoadingContent>
        </FormContext>
      </DealersContextProvider>
    </AnalyticsContext>
  );
};

export default SlpForm;
