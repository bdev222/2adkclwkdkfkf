import { OfferType } from '../../../../../../functions/layout/transforms/util/getOffers/models';
import { Offer } from '../../models';

function formatNumber(amount: string) {
  return parseFloat(amount).toLocaleString();
}

function getOfferInfo(offer: Offer) {
  switch (offer.type) {
    case OfferType.Apr: {
      const { duration, rate } = offer.apr;
      return `${formatNumber(rate)}% for ${formatNumber(duration)} Months`;
    }

    case OfferType.Cash: {
      const { cashAmount, label } = offer.cash;
      return `$${formatNumber(cashAmount)} ${label}`;
    }

    case OfferType.Lease: {
      const { dueAtSigning, duration, monthlyPayment } = offer.lease;

      return `$${formatNumber(monthlyPayment)} for ${formatNumber(
        duration
      )} Months, $${formatNumber(dueAtSigning)} Due at Signing`;
    }

    case OfferType.Misc: {
      return offer.misc.description;
    }

    case OfferType.Msrp: {
      const { rate } = offer.msrp;
      return `$${formatNumber(rate)} MSRP`;
    }
    default:
      return '';
  }
}

export default function createOfferSlpString(offer: Offer) {
  const { endDate, series, type } = offer;

  const offerSlpParts = [
    `Offer Type: ${type}`,
    `Vehicle: ${series[0].year} ${series[0].name[0]}`,
    `Offer Info: ${getOfferInfo(offer)}`,
    `Offer End Date: ${endDate.month}/${endDate.day}/${endDate.fullYear}`,
    `Offer URL: ${document.URL}`,
  ];

  return offerSlpParts.join(' | ');
}
