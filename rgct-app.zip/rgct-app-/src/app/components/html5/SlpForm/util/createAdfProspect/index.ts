import { OutgoingSlpForm } from '../../models.js';
import baseProspect from './prospectBase.json';

export default function createAdfProspect({
  campaignCode,
  comments,
  customerAddress,
  customerCity,
  customerEmail,
  customerFirstName,
  customerLastName,
  customerPhone,
  customerZipCode,
  dealerCode,
  deviceType,
  exteriorColor,
  interiorColor,
  mediaTag,
  offerId,
  omnitureId,
  preferredContact,
  vehicleModel,
  vehicleTrim,
  vehicleYear,
}: Partial<OutgoingSlpForm>) {
  const prospect = JSON.parse(JSON.stringify(baseProspect));

  prospect.requestdate = new Date().toISOString().replace('Z', '');

  prospect.vehicle.trim = vehicleTrim || '';

  prospect.vehicle.year = vehicleYear || 'N/A';

  prospect.vehicle.model = vehicleModel || 'N/A';

  if (interiorColor) {
    prospect.vehicle.colorcombination.interiorcolor = interiorColor;
  } else {
    delete prospect.vehicle.colorcombination.interiorcolor;
  }

  if (exteriorColor) {
    prospect.vehicle.colorcombination.exteriorcolor = exteriorColor;
  } else {
    delete prospect.vehicle.colorcombination.exteriorcolor;
  }

  if (
    !prospect.vehicle.colorcombination.exteriorcolor &&
    !prospect.vehicle.colorcombination.interiorcolor
  ) {
    delete prospect.vehicle.colorcombination;
  }

  if (customerFirstName) {
    prospect.customer.contact.name[0].value = customerFirstName;
  }

  if (customerLastName) {
    prospect.customer.contact.name[1].value = customerLastName;
  }

  if (customerEmail) {
    prospect.customer.contact.email.value = customerEmail;
    prospect.customer.contact.email.preferredcontact =
      preferredContact === 'email' ? '1' : '0';
  } else {
    delete prospect.customer.contact.email.value;
  }

  if (customerPhone) {
    prospect.customer.contact.phone.value = customerPhone;
    prospect.customer.contact.phone.preferredcontact =
      preferredContact === 'phone' ? '1' : '0';
  } else {
    delete prospect.customer.contact.phone;
  }

  if (customerAddress) {
    prospect.customer.contact.address.street = customerAddress;
  }

  if (customerCity) {
    prospect.customer.contact.address.city = customerCity;
  }

  if (customerZipCode) {
    prospect.customer.contact.address.postalcode = customerZipCode;
  }

  if (comments) {
    prospect.customer.comments = comments;
  } else {
    delete prospect.customer.comments;
  }

  if (dealerCode) {
    prospect.vendor.id.value = dealerCode;
    prospect.vendor.id.source = `TMS Dealer Code || ${dealerCode}`;
  }

  if (omnitureId) {
    prospect.provider.id[1].value = omnitureId;
  }

  if (mediaTag) {
    prospect.provider.id[3].value = mediaTag;
  }

  if (offerId) {
    prospect.provider.id[4].value = offerId;
  }

  if (deviceType) {
    prospect.provider.id.push({
      value: deviceType,
      source: 'Breakpoint',
    });

    prospect.provider.name = deviceType === 'desktop' ? 'Website' : 'Mobile';
  }

  if (campaignCode) {
    prospect.provider.service = campaignCode;
  }

  return {
    adf: { prospect },
  };
}
