import { JSDSContexts } from 'jsds-react';

import {
  PageContextMeta,
  SiteContext,
} from '../../../../../../functions/layout/models';

const setPreferredLanguage = (
  pageContext: JSDSContexts<PageContextMeta, SiteContext>['page']
) => {
  switch (pageContext.lang) {
    case 'en':
      return 'English';
    case 'es':
      return 'Spanish';
    default:
      return undefined;
  }
};

export default setPreferredLanguage;
