import Axios from 'axios';

import { OutgoingSlpForm } from '../../models';
import createAdfProspect from '../createAdfProspect';

interface SubmitLeadResponse {
  adfstatus: {
    responseCode: 'ACCEPTED' | 'REJECTED';
    responseDetails: string;
    elmsStatus: string;
  };
}

export default function submitSlpForm(formValues: Partial<OutgoingSlpForm>) {
  const adfProspect = createAdfProspect(formValues);

  return Axios.post<SubmitLeadResponse>('/submitlead', adfProspect);
}
