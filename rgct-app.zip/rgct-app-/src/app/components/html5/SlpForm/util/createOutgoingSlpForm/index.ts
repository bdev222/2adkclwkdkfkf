import { FormValues, Offer, OutgoingSlpForm, Vehicle } from '../../models';
import createOfferSlpString from '../createOfferSlpString';

interface TransformParams {
  campaignCode: string;
  deviceType: 'mobile' | 'desktop';
  offer?: Offer;
  values: Partial<FormValues>;
  vehicle?: Vehicle;
}

const MEDIA_TAG_REGEX = /(?:(?:^|.*;\s*)campaign\s*\=\s*([^;]*).*$)|^.*$/;
const OMNITURE_REGEX = /(?:(?:^|.*;\s*)xact\s*\=\s*([^;]*).*$)|^.*$/;

function getComments(
  comments?: string,
  offerSlp?: string,
  preferredDate?: string,
  preferredTime?: string
) {
  const formattedComments = [];

  if (comments) {
    formattedComments.push(comments);
  }

  if (offerSlp) {
    formattedComments.push(offerSlp);
  }

  if (preferredDate && preferredTime) {
    formattedComments.push(
      `Customer Requests to Schedule-A-Test-Drive on ${preferredDate} ${preferredTime}`
    );
  }

  return {
    comments: `${formattedComments.join(' | ')} ::REFERRING URL:: ${
      document.URL
    }`,
  };
}

function getVehicleModelAndYear(
  offer?: Offer,
  vehicle?: Vehicle,
  vehicleField = ''
) {
  const [year, seriesName] = vehicleField.split('|');

  const vehicleModel = seriesName
    ? seriesName
    : offer
    ? offer.series[0].name[0]
    : vehicle
    ? vehicle.seriesName
    : 'N/A';

  const vehicleYear = year
    ? year
    : offer
    ? offer.series[0].year
    : vehicle
    ? vehicle.year
    : 'N/A';

  return { vehicleModel, vehicleYear };
}

export default function createOutgoingSlpForm({
  campaignCode,
  deviceType,
  offer,
  values,
  vehicle,
}: TransformParams): Partial<OutgoingSlpForm> {
  const {
    address,
    city,
    comments,
    dealerCode,
    dealerSearchZip,
    dealerZip,
    email,
    firstName,
    lastName,
    phone,
    preferredContact,
    preferredDate,
    preferredLanguage,
    preferredTime,
    state,
    vehicle: vehicleField,
    zip,
  } = values;

  const offerSlp = offer ? createOfferSlpString(offer) : undefined;

  return {
    ...getComments(comments, offerSlp, preferredDate, preferredTime),
    ...getVehicleModelAndYear(offer, vehicle, vehicleField),
    campaignCode,
    customerAddress: address,
    customerCity: city,
    customerEmail: email,
    customerFirstName: firstName,
    customerLastName: lastName,
    customerPhone: phone,
    customerState: state,
    customerZipCode: zip || dealerSearchZip || dealerZip,
    dealerCode,
    deviceType,
    mediaTag: document.cookie.replace(MEDIA_TAG_REGEX, '$1'),
    offer: offerSlp,
    offerId: offer?.id,
    omnitureId: document.cookie.replace(OMNITURE_REGEX, '$1'),
    preferredContact,
    preferredDate,
    preferredLanguage,
    preferredTime,
    vehicleInterest: 'buy',
    vehicleMake: 'Toyota',
    vehicleStatus: 'new',
  };
}
