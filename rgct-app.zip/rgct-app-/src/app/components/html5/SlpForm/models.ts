import { MutableRefObject } from 'react';

import {
  Offer as OfferProps,
  OfferBase,
} from '../../../../functions/layout/transforms/util/getOffers/models';
import { FormType } from '../../../util/campaignCodes';
import EventTypes from '../../shared/Analytics/EventTypes';
import { Dealer } from '../DealersContext/models';

export interface AnalyticsOptions {
  event?: EventTypes;
  timeout?: number;
}

export type OnSlpSuccess = (
  formValues: Partial<OutgoingSlpForm>,
  dealer: Dealer
) => void;

export type OnDealerSelect = (dealer: Dealer) => void;

export type ClearSelectedDealer = () => void;

type SlpFormType = Exclude<FormType, 'payment-estimator'>;

type Variations = 'modal' | 'module';

export type FormSchemas = Record<SlpFormType, Record<Variations, Field[]>>;

export type FormRef = MutableRefObject<HTMLDivElement | null>;

export type ColumnField = FieldType<
  'column',
  {
    fields: Field[];
  }
>;

export type CommentField = FieldType<'comment'>;

export type ConditionalVehicleContainerField = FieldType<
  'conditionalVehicleContainer',
  {
    hasVehicle?: { fields: Field[] };
    hasNoVehicle: { fields: Field[] };
  }
>;

export type ContactField = FieldType<'contact'>;

export type DividerField = FieldType<'divider'>;

export type HeadingField = FieldType<
  'heading',
  {
    mobileOnly?: boolean;
    headingKey: string;
  }
>;

export type NameField = FieldType<'name'>;

export type PreferredDateTimeField = FieldType<'preferredDateTime'>;

export type RowField = FieldType<
  'row',
  {
    fields: Field[];
  }
>;

export type SelectDealerField = FieldType<'selectDealer'>;

export type SubHeadingField = FieldType<
  'subHeading',
  {
    desktopOnly?: boolean;
    headingKey: string;
    mobileOnly?: boolean;
  }
>;

export type SubmitField = FieldType<
  'submit',
  {
    alignment: 'left' | 'center';
  }
>;

export type VehicleField = FieldType<
  'vehicle',
  {
    isHalfWidth?: boolean;
  }
>;

export type Field =
  | ColumnField
  | CommentField
  | ConditionalVehicleContainerField
  | ContactField
  | DividerField
  | HeadingField
  | NameField
  | PreferredDateTimeField
  | RowField
  | SelectDealerField
  | SubHeadingField
  | SubmitField
  | VehicleField;

type FieldType<
  TField extends string,
  TData = undefined
> = TData extends undefined
  ? { field: TField }
  : { field: TField; data: TData };

export interface FieldsProps {
  clearSelectedDealer?: ClearSelectedDealer;
  formRef: FormRef;
  hasOffer: boolean;
  lockedDealer?: Dealer;
  onDealerSelect?: OnDealerSelect;
  preSelectedVehicle?: string;
  submitLabel: string;
  vehicle?: Vehicle;
}

export interface FormValues {
  address: string;
  city: string;
  comments: string;
  dealerCode: string;
  dealerSearchZip: string;
  dealerZip: string;
  email: string;
  firstName: string;
  fullName: string;
  lastName: string;
  phone: string;
  preferredContact: 'email' | 'phone';
  preferredDate: string;
  preferredLanguage: 'English' | 'Spanish';
  preferredTime: string;
  state: string;
  vehicle: string;
  zip: string;
}

export interface OutgoingSlpForm {
  campaignCode: string;
  comments: string;
  customerAddress: string;
  customerCity: string;
  customerEmail: string;
  customerFirstName: string;
  customerLastName: string;
  customerPhone: string;
  customerState: string;
  customerZipCode: string;
  dealerCode: string;
  deviceType: string;
  mediaTag: string;
  offer: string;
  offerId: string;
  omnitureId: string;
  preferredContact: 'email' | 'phone';
  preferredDate: string;
  preferredLanguage: string;
  preferredTime: string;
  vehicleInterest: 'buy';
  vehicleMake: 'Toyota';
  vehicleModel: string;
  vehicleStatus: 'new';
  vehicleYear: string;

  // still to do:
  exteriorColor?: string;
  interiorColor?: string;
  tmsSiteAttribute?: string;
  vehicleTrim?: string;
}

export type Offer = OfferBase & Pick<OfferProps, 'endDate' | 'series' | 'id'>;

export interface Vehicle {
  seriesId: string;
  seriesName: string;
  year: string;
}
