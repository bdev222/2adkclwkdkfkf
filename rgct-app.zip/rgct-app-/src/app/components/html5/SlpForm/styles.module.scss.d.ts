export const loaderContainer: string;
