import useStyles from 'isomorphic-style-loader/useStyles';
import React, {
  FC,
  FocusEvent,
  FormEvent,
  MutableRefObject,
  useRef,
} from 'react';

import AnalyticsComponent from '../../../shared/Analytics/AnalyticsComponent';
import createKeyMetricsBlock from '../../../shared/Analytics/blocks/createKeyMetricsBlock';
import createLinkBlock from '../../../shared/Analytics/blocks/createLinkBlock';
import EventTypes from '../../../shared/Analytics/EventTypes';
import useTrigger from '../../../shared/Analytics/useTrigger';
import { useDealersState } from '../../DealersContext';
import Fields from '../Fields';
import {
  AnalyticsOptions,
  ClearSelectedDealer,
  Field,
  FieldsProps,
  FormRef,
  OnDealerSelect,
  Vehicle,
} from '../models';
import styles from './styles.module.scss';

interface FormProps extends Omit<FieldsProps, 'formRef'> {
  analytics?: AnalyticsOptions;
  clearSelectedDealer: ClearSelectedDealer;
  didFireStartMetric: MutableRefObject<boolean>;
  fields: Field[];
  formCode: string;
  hasOffer: boolean;
  onDealerSelect: OnDealerSelect;
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
  submitLabel: string;
  vehicle?: Vehicle;
}

const Form: FC<FormProps> = ({
  analytics = {},
  clearSelectedDealer,
  didFireStartMetric,
  fields,
  formCode,
  hasOffer,
  lockedDealer,
  onDealerSelect,
  onSubmit,
  submitLabel,
  vehicle,
}) => {
  useStyles(styles);

  const trigger = useTrigger();

  const formRef: FormRef = useRef(null);

  const { isFetching } = useDealersState();
  const isFetchingRef = useRef(isFetching);
  isFetchingRef.current = isFetching;

  const createAnalyticsBlock = () => {
    const metrics = [`km-${formCode}-shown`];

    if (isFetchingRef.current) {
      metrics.push('km-dealers-search');
    }

    return createKeyMetricsBlock(...metrics);
  };

  const handleFormFocus = (event: FocusEvent<HTMLElement>) => {
    if (
      didFireStartMetric.current ||
      (event.target && event.target.hasAttribute('data-suppress-analytics'))
    ) {
      return;
    }

    const name = event.target.getAttribute('name') ?? '';

    trigger(EventTypes.Click, [
      createLinkBlock({ text: name }),
      createKeyMetricsBlock(`km-${formCode}-start`),
    ]);

    didFireStartMetric.current = true;
  };

  return (
    <AnalyticsComponent
      event={analytics.event}
      initialBlocks={createAnalyticsBlock}
      timeout={analytics.timeout}
    >
      <div ref={formRef}>
        <form
          className={styles.container}
          onFocus={handleFormFocus}
          onSubmit={onSubmit}
        >
          <Fields
            clearSelectedDealer={clearSelectedDealer}
            fields={[...fields]}
            formRef={formRef}
            hasOffer={hasOffer}
            lockedDealer={lockedDealer}
            onDealerSelect={onDealerSelect}
            submitLabel={submitLabel}
            vehicle={vehicle}
          />
        </form>
      </div>
    </AnalyticsComponent>
  );
};

export default Form;
