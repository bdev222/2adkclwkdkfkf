import { Field } from '../../../models';

const scheduleTestDriveModuleSchema: Field[] = [
  {
    field: 'heading',
    data: {
      headingKey: 'scheduleTestDrive',
    },
  },
  {
    field: 'conditionalVehicleContainer',
    data: {
      hasNoVehicle: {
        fields: [
          {
            field: 'row',
            data: {
              fields: [
                {
                  field: 'column',
                  data: {
                    fields: [
                      {
                        field: 'vehicle',
                        data: {},
                      },
                    ],
                  },
                },
                {
                  field: 'column',
                  data: {
                    fields: [],
                  },
                },
              ],
            },
          },
          {
            field: 'divider',
          },
        ],
      },
    },
  },
  {
    field: 'row',
    data: {
      fields: [
        {
          field: 'column',
          data: {
            fields: [
              {
                field: 'subHeading',
                data: {
                  headingKey: 'yourInformation',
                },
              },
              {
                field: 'name',
              },
              {
                field: 'contact',
              },
              {
                field: 'comment',
              },
              {
                field: 'preferredDateTime',
              },
            ],
          },
        },
        {
          field: 'column',
          data: {
            fields: [
              {
                field: 'selectDealer',
              },
            ],
          },
        },
      ],
    },
  },
  {
    field: 'submit',
    data: {
      alignment: 'center',
    },
  },
];

export default scheduleTestDriveModuleSchema;
