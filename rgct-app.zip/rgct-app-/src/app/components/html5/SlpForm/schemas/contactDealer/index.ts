import modal from './modal';
import module from './module';

export default {
  modal,
  module,
};
