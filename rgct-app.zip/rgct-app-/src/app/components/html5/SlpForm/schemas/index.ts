import { FormSchemas } from '../models';
import contactDealer from './contactDealer';
import requestQuote from './requestQuote';
import scheduleTestDrive from './scheduleTestDrive';

const formSchemas: FormSchemas = {
  'contact-dealer': contactDealer,
  'request-quote': requestQuote,
  'schedule-test-drive': scheduleTestDrive,
};

export default formSchemas;
