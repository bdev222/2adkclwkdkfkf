import { Field } from '../../../models';

const contactDealerModalSchema: Field[] = [
  {
    field: 'conditionalVehicleContainer',
    data: {
      hasNoVehicle: {
        fields: [
          {
            field: 'heading',
            data: {
              headingKey: 'contactDealer',
            },
          },
          {
            field: 'vehicle',
            data: {
              isHalfWidth: true,
            },
          },
          {
            field: 'subHeading',
            data: {
              headingKey: 'yourInformation',
            },
          },
        ],
      },
      hasVehicle: {
        fields: [
          {
            field: 'heading',
            data: {
              mobileOnly: true,
              headingKey: 'contactDealer',
            },
          },
          {
            field: 'subHeading',
            data: {
              mobileOnly: true,
              headingKey: 'yourInformation',
            },
          },
          {
            field: 'subHeading',
            data: {
              desktopOnly: true,
              headingKey: 'contactDealer',
            },
          },
        ],
      },
    },
  },
  {
    field: 'name',
  },
  {
    field: 'contact',
  },
  {
    field: 'comment',
  },
  {
    field: 'selectDealer',
  },
  {
    field: 'submit',
    data: {
      alignment: 'left',
    },
  },
];

export default contactDealerModalSchema;
