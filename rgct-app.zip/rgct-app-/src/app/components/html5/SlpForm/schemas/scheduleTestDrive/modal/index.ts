import { Field } from '../../../models';

const scheduleTestDriveModalSchema: Field[] = [
  {
    field: 'conditionalVehicleContainer',
    data: {
      hasNoVehicle: {
        fields: [
          {
            field: 'heading',
            data: {
              headingKey: 'scheduleTestDrive',
            },
          },
          {
            field: 'vehicle',
            data: {
              isHalfWidth: true,
            },
          },
          {
            field: 'subHeading',
            data: {
              headingKey: 'yourInformation',
            },
          },
        ],
      },
      hasVehicle: {
        fields: [
          {
            field: 'heading',
            data: {
              mobileOnly: true,
              headingKey: 'scheduleTestDrive',
            },
          },
          {
            field: 'subHeading',
            data: {
              mobileOnly: true,
              headingKey: 'yourInformation',
            },
          },
          {
            field: 'subHeading',
            data: {
              desktopOnly: true,
              headingKey: 'scheduleTestDrive',
            },
          },
        ],
      },
    },
  },
  {
    field: 'name',
  },
  {
    field: 'contact',
  },
  {
    field: 'comment',
  },
  {
    field: 'selectDealer',
  },
  {
    field: 'preferredDateTime',
  },
  {
    field: 'submit',
    data: {
      alignment: 'left',
    },
  },
];

export default scheduleTestDriveModalSchema;
