export const legend: string;
export const lockedDealerField: string;
export const dealer: string;
