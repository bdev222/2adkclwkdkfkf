import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import FieldGroup from '../../../FieldGroup';
import TextField from '../../../TextField';
import { ContactField } from '../../models';
import styles from './styles.module.scss';

type ContactProps = ContactField;

const EMAIL_REGEX = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

const US_PHONE_REGEX = /^(\+?1-?)?(\([2-9]([02-9]\d|1[02-9])\)|[2-9]([02-9]\d|1[02-9]))-?[2-9]([02-9]\d|1[02-9])-?\d{4}$/i;

const Contact: FC<ContactProps> = () => {
  useStyles(styles);
  const { t } = useTranslation('slpForm');
  const emailRequired = t('emailRequired');
  const emailValid = t('emailInvalid');
  const phoneInvalid = t('phoneInvalid');

  return (
    <fieldset>
      <legend className={styles.legend}>
        {t('email')} {t('phone')}
      </legend>
      <FieldGroup>
        <TextField
          label={t('email')}
          maxLength={50}
          name="email"
          type="email"
          validation={{
            required: emailRequired,
            pattern: { value: EMAIL_REGEX, message: emailValid },
          }}
        />
        <TextField
          label={t('phone')}
          name="phone"
          type="tel"
          validation={{
            validate: (value: string) => {
              if (value === '') {
                return;
              }
              const numbersOnly = value.replace(/[^0-9]+/g, '');
              return US_PHONE_REGEX.test(numbersOnly) ? true : phoneInvalid;
            },
          }}
        />
      </FieldGroup>
    </fieldset>
  );
};

export default Contact;
