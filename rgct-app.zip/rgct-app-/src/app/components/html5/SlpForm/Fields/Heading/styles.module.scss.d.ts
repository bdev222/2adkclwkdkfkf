export const heading: string;
export const isMobile: string;
