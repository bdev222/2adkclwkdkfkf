import dayjs from 'dayjs';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { createContext, FC } from 'react';
import DayPickerInput from 'react-day-picker/DayPickerInput';
import dayPickerStyles from 'react-day-picker/lib/style.css';
import { useFormContext } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

import FieldGroup from '../../../FieldGroup';
import SelectField from '../../../SelectField';
import { FieldsProps, FormRef, PreferredDateTimeField } from '../../models';
import CalendarInput from './CalendarInput';
import CalendarOverlay from './CalendarOverlay';
import styles from './styles.module.scss';

interface PreferredDateTimeProps extends PreferredDateTimeField, FieldsProps {}

export const DATE_FORMAT = 'MM/DD/YYYY';

export const FormRefContext = createContext<FormRef | undefined>(undefined);

const formatDate = (date: Date, format: string) => dayjs(date).format(format);

const PreferredDateTime: FC<PreferredDateTimeProps> = ({ formRef }) => {
  useStyles(styles, dayPickerStyles);

  const { clearError, setValue, watch } = useFormContext();

  const { t } = useTranslation('slpForm');

  const scheduleTimes = [
    { value: 'morning', label: t('morning') },
    { value: 'afternoon', label: t('afternoon') },
    { value: 'evening', label: t('evening') },
  ];

  const handleDayChange = (day: Date) => {
    const date = formatDate(day, DATE_FORMAT);
    clearError('preferredDate');
    setValue('preferredDate', date);
  };

  const preferredTimeRequired = t('preferredTimeRequired');

  return (
    <fieldset>
      <legend className={styles.legend}>{t('preferredTime')}</legend>
      <h3 data-type="field-header">{t('preferredDateAndTime')}</h3>
      <FieldGroup>
        <FormRefContext.Provider value={formRef}>
          <DayPickerInput
            classNames={{
              container: styles.datePickerInput,
              overlay: '',
              overlayWrapper: 'DayPickerInput-OverlayWrapper',
            }}
            component={CalendarInput}
            dayPickerProps={{
              disabledDays: {
                before: new Date(),
              },
              fromMonth: new Date(),
            }}
            format={DATE_FORMAT}
            formatDate={formatDate}
            onDayChange={handleDayChange}
            overlayComponent={CalendarOverlay}
            value={watch('preferredDate')}
          />
        </FormRefContext.Provider>
        <SelectField
          label={t('preferredTime')}
          name="preferredTime"
          options={scheduleTimes}
          validation={{ required: preferredTimeRequired }}
        />
      </FieldGroup>
    </fieldset>
  );
};

export default PreferredDateTime;
