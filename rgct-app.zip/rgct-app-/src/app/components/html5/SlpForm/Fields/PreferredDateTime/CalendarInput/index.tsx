import dayjs from 'dayjs';
import React, { ChangeEvent, FocusEvent, forwardRef } from 'react';
import { useFormContext } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

import TextField from '../../../../TextField';
import { DATE_FORMAT } from '..';

interface CalendarInputProps {
  onBlur: () => void;
  onChange: () => void;
  onClick: () => void;
  onFocus: () => void;
  onKeyDown: () => void;
  onKeyUp: () => void;
  placeholder?: string;
  value: string;
}

const CalendarInput = forwardRef<HTMLDivElement, CalendarInputProps>(
  ({ onBlur, ...remainingProps }, ref) => {
    const { setValue, watch } = useFormContext();

    const { t } = useTranslation('slpForm');

    const dateRequired = t('preferredDateRequired');
    const dateInvalid = t('preferredDateInvalid');

    const handleInputBlur = (event: FocusEvent<HTMLInputElement>) => {
      const overlayEl = document.getElementsByClassName(
        'DayPickerInput-OverlayWrapper'
      );

      // The thing we focused on to. We add activeElement as a fallback for IE11
      const target = event.relatedTarget ?? document.activeElement;

      const didClickOverlay =
        target instanceof HTMLElement && overlayEl[0]?.contains(target);

      if (!didClickOverlay) {
        const manualValue = dayjs(event.currentTarget.value);

        if (manualValue.isValid()) {
          setValue('preferredDate', dayjs(manualValue).format(DATE_FORMAT));
        }

        onBlur();
      }
    };

    const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
      const date = event.currentTarget.value;
      const formattedDate = date
        .replace(/[^0-9\/]+/g, '')
        .replace(/(\d{2})(\d{2})(\d{4})/, '$1/$2/$3');

      setValue('preferredDate', formattedDate);
    };

    return (
      <div ref={ref}>
        <TextField
          {...remainingProps}
          autoComplete="off"
          label={t('preferredDate')}
          name="preferredDate"
          onBlur={handleInputBlur}
          onChange={handleChange}
          placeholder={DATE_FORMAT}
          title={DATE_FORMAT}
          validation={{
            required: dateRequired,
            validate: (inputValue: string) => {
              const rawDate = dayjs(inputValue);
              return rawDate.isValid() && !rawDate.isBefore(dayjs(), 'days')
                ? true
                : dateInvalid;
            },
          }}
          value={watch('preferredDate')}
        />
      </div>
    );
  }
);

export default CalendarInput;
