import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import { FieldsProps, RowField } from '../../models';
import Fields from '..';
import styles from './styles.module.scss';

interface RowProps extends RowField, FieldsProps {}

const Row: FC<RowProps> = ({ data: { fields }, ...fieldsProps }) => {
  useStyles(styles);

  return (
    <div className={styles.row}>
      <Fields {...fieldsProps} fields={fields} />
    </div>
  );
};

export default Row;
