import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, {
  FC,
  MouseEvent,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react';
import { createPortal } from 'react-dom';

import { FormRefContext } from '..';
import styles from './styles.module.scss';

interface OverlayBounds {
  left: number;
  top: number;
}

interface CalendarOverlayProps {
  classNames: {
    container: string;
    overlay: string;
    overlayWrapper: string;
  };
  input: HTMLElement;
  month: Date;
  onBlur: () => void;
  onFocus: () => void;
  selectedDay?: Date;
}

const OVERLAY_OFFSET = 8;

const CalendarOverlay: FC<CalendarOverlayProps> = ({
  children,
  classNames,
  input,
}) => {
  useStyles(styles);

  const formRef = useContext(FormRefContext);

  if (!formRef) {
    throw new Error('FormRefContext Provider has not been defined!');
  }

  const rootRef = useRef<HTMLDivElement>(document.createElement('div'));
  const [didCreateRoot, setDidCreateRoot] = useState(false);

  useEffect(() => {
    formRef.current?.appendChild(rootRef.current); // NOSONAR
    setDidCreateRoot(true);

    return () => {
      formRef.current?.removeChild(rootRef.current); // NOSONAR
    };
  }, []);

  const [bounds, setBounds] = useState<OverlayBounds>();

  const overlayRef = useCallback((overlayEl: HTMLDivElement) => {
    if (!overlayEl || !formRef.current) {
      return;
    }

    const formBounds = formRef.current.getBoundingClientRect();
    const overlayBounds = overlayEl.getBoundingClientRect();
    const inputBounds = input.getBoundingClientRect();

    let overlayTop = inputBounds.top + inputBounds.height + OVERLAY_OFFSET;

    const windowHeight = window.innerHeight;
    const isOffscreen = overlayTop + overlayBounds.height > windowHeight;
    if (isOffscreen) {
      overlayTop = inputBounds.top - overlayBounds.height - OVERLAY_OFFSET;
    }

    setBounds({
      left: inputBounds.left - formBounds.left,
      top: overlayTop - formBounds.top,
    });
  }, []);

  const handleOverlayClick = (event: MouseEvent<HTMLDivElement>) => {
    event.stopPropagation();
  };

  return didCreateRoot
    ? createPortal(
        <div
          className={cc({
            [classNames.overlayWrapper]: true,
            [styles.container]: true,
            [styles.isVisible]: !!bounds,
          })}
          onClick={handleOverlayClick}
          ref={overlayRef}
          role="presentation"
          style={bounds}
        >
          {children}
        </div>,
        rootRef.current
      )
    : null;
};

export default CalendarOverlay;
