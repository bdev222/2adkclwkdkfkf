import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import { DividerField } from '../../models';
import styles from './styles.module.scss';

type DividerProps = DividerField;

const Divider: FC<DividerProps> = () => {
  useStyles(styles);

  return <hr className={styles.divider} />;
};

export default Divider;
