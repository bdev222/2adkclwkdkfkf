export const divider: string;
