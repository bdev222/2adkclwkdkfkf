import { getCookie } from '../../../../../../../util/getCookie';
import useJsdsContexts from '../../../../../../../util/useJsdsContexts';

export default function useInitialZip() {
  const { page, site } = useJsdsContexts();

  const isSameContext = getCookie('tda') === site.tdaConfig.code;

  const initialZip = isSameContext ? page.meta.zipCode.zip : undefined;

  // This only kicks in if we don't have a user-generated zip (ugzipcode) AND if
  // the geolocated zipcode is 67337.
  if (initialZip === '67337' && !page.meta.zipCode.confirmedZip) {
    const zipCodeAccuracy = getCookie('zipcode_accuracy');

    // If the accuracy is greater than 482803 meters (300 miles), then don't set
    // an initial zip.
    if (+`${zipCodeAccuracy}` > 482803) {
      return undefined;
    }
  }

  return initialZip;
}
