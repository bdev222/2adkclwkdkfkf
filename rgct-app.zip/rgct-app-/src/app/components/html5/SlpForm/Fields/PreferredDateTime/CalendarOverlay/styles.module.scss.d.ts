export const container: string;
export const isVisible: string;
