import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

import useJsdsContexts from '../../../../../../util/useJsdsContexts';
import { Option } from '../../../../SelectField/models';

export default function useVehicleOptions(selectedVehicle: string | undefined) {
  const [options, setOptions] = useState<Option[]>([]);
  const {
    site: { vehicleOptions },
  } = useJsdsContexts();
  const { t } = useTranslation('slpForm');

  useEffect(() => {
    const seriesSelectOptions = [
      { value: 'N/A|N/A', label: t('haventMadeUpMind') },
      ...vehicleOptions,
    ];

    if (!selectedVehicle) {
      seriesSelectOptions.unshift({ value: '', label: '' });
    }

    setOptions(seriesSelectOptions);
  }, [selectedVehicle, vehicleOptions]);

  return options;
}
