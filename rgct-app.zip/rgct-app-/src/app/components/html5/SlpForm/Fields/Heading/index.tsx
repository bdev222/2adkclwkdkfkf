import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import { HeadingField } from '../../models';
import styles from './styles.module.scss';

type HeadingProps = HeadingField;

const Heading: FC<HeadingProps> = ({ data: { headingKey, mobileOnly } }) => {
  useStyles(styles);

  const { t } = useTranslation('slpForm');

  return (
    <h2 className={cc([styles.heading, { [styles.isMobile]: mobileOnly }])}>
      {t(headingKey)}
    </h2>
  );
};

export default Heading;
