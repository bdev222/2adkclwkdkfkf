export const legend: string;
export const headingWrapper: string;
export const heading: string;
export const zipCodeInput: string;
export const showMore: string;
export const dealers: string;
