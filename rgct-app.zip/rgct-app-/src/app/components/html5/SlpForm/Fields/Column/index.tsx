import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import { ColumnField, FieldsProps } from '../../models';
import Fields from '..';
import styles from './styles.module.scss';

interface ColumnProps extends ColumnField, FieldsProps {}

const Column: FC<ColumnProps> = ({ data: { fields }, ...fieldsProps }) => {
  useStyles(styles);

  return (
    <div className={styles.column}>
      <Fields {...fieldsProps} fields={fields} />
    </div>
  );
};

export default Column;
