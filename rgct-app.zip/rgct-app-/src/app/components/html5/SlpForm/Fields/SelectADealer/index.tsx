import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useEffect, useState } from 'react';
import { useFormContext } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

import useJsdsContexts from '../../../../../util/useJsdsContexts';
import usePrevious from '../../../../../util/usePrevious';
import createLinkBlock from '../../../../shared/Analytics/blocks/createLinkBlock';
import EventTypes from '../../../../shared/Analytics/EventTypes';
import useTrigger from '../../../../shared/Analytics/useTrigger';
import Button from '../../../Button';
import DealerListing from '../../../DealerListing';
import { fetchDealersByZip, useDealers } from '../../../DealersContext';
import { Dealer, QueryType } from '../../../DealersContext/models';
import DealersZipField from '../../../DealersZipField';
import RadioField from '../../../RadioField';
import {
  ClearSelectedDealer,
  FormValues,
  OnDealerSelect,
  Vehicle,
} from '../../models';
import Pagination from './Pagination';
import styles from './styles.module.scss';
import useInitialZip from './util/useInitialZip';

interface SelectADealerProps {
  clearSelectedDealer?: ClearSelectedDealer;
  hasOffer: boolean;
  onDealerSelect?: OnDealerSelect;
  vehicle?: Vehicle;
}

type SelectADealerFormProps =
  | 'dealerCode'
  | 'dealerSearchZip'
  | 'dealerZip'
  | 'vehicle';

type SelectADealerValues = Pick<FormValues, SelectADealerFormProps>;

const SelectADealer: FC<SelectADealerProps> = ({
  clearSelectedDealer,
  hasOffer,
  onDealerSelect,
  vehicle,
}) => {
  useStyles(styles);

  const { t } = useTranslation('dealers');

  const { site } = useJsdsContexts();

  const trigger = useTrigger();

  const { register, setValue, watch } = useFormContext<SelectADealerValues>();

  const { dealerCode, vehicle: selectedVehicle } = watch([
    'dealerCode',
    'vehicle',
  ]);

  const [
    { dealers, hasMore, mode, pagination },
    dealersDispatch,
  ] = useDealers();

  // Whether the fetched dealers belong to a different TDA than the current page
  const [isCrossTda, setIsCrossTda] = useState(false);

  const initialZip = useInitialZip();

  const dealerSearchZip = watch('dealerSearchZip');

  const isMirai =
    vehicle?.seriesId === 'mirai' || /\|mirai$/.test(selectedVehicle ?? '');

  const prevIsMirai = usePrevious(isMirai);

  const queryType = isMirai
    ? QueryType.Mirai
    : site.tdaConfig.useDealerProximitySearch
    ? QueryType.Proximity
    : QueryType.Pma;

  useEffect(() => {
    if (initialZip) {
      setValue('dealerSearchZip', initialZip);

      fetchDealersByZip(dealersDispatch, initialZip, queryType);
    }
  }, [initialZip]);

  useEffect(() => {
    if (dealerSearchZip && isMirai !== prevIsMirai) {
      fetchDealersByZip(dealersDispatch, dealerSearchZip, queryType);
    }
  }, [dealerSearchZip, isMirai, prevIsMirai]);

  useEffect(() => {
    if (!dealers.length) {
      clearDealer();
    } else {
      if (!pagination) {
        selectDealer(dealers[0]);
      }
    }
  }, [dealers, pagination]);

  useEffect(() => {
    if (!dealers.length) {
      return;
    }

    if (!dealerCode) {
      selectDealer(dealers[0]);
    }

    setIsCrossTda(dealers[0].tda !== site.tdaConfig.code);
  }, [dealers, dealerCode, setValue]);

  const selectDealer = (dealer: Dealer) => {
    setValue('dealerCode', dealer.code);
    setValue('dealerZip', dealer.zip);

    if (onDealerSelect) {
      onDealerSelect(dealer);
    }
  };

  const clearDealer = () => {
    setValue('dealerCode', '');
    setValue('dealerZip', '');
    clearSelectedDealer?.(); // NOSONAR;
  };

  const handleZipChange = (zipCode: string) => {
    setValue('dealerSearchZip', zipCode);
  };

  const handleZipSubmit = (zipCode?: string) => {
    setValue('dealerSearchZip', zipCode || '');

    if (zipCode) {
      fetchDealersByZip(dealersDispatch, zipCode, queryType);
    }
  };

  const handlePaginateClick = (dir: 'next' | 'prev') => {
    const linkText = dir === 'next' ? dir : 'previous';
    trigger(EventTypes.Click, createLinkBlock({ text: linkText }));
    dealersDispatch({ type: 'paginate', payload: { dir } });
  };

  const handleShowMoreBtnClick = () => {
    trigger(EventTypes.Click, createLinkBlock({ text: 'view more dealers' }));
    dealersDispatch({ type: 'enablePaginationMode' });
  };

  const disclaimer =
    hasOffer && isCrossTda && dealers.length
      ? t('common:zipDisclaimer')
      : undefined;

  return (
    <fieldset>
      <legend className={styles.legend}>
        {t(isMirai ? 'selectAMiraiDealer' : 'selectADealer')}
      </legend>
      <div className={styles.headingWrapper}>
        <h3 className={styles.heading} data-type="field-header">
          {t(isMirai ? 'selectAMiraiDealer' : 'selectADealer')}
        </h3>
        <div className={styles.zipCodeInput}>
          <DealersZipField
            disclaimers={disclaimer ? [disclaimer] : undefined}
            initialZip={initialZip}
            name="dealerSearchZip"
            onChange={handleZipChange}
            onSubmit={handleZipSubmit}
          />
        </div>
      </div>
      {dealers.length > 0 && (
        <div className={styles.dealers}>
          {dealers.map(dealer => (
            <RadioField
              checked={dealerCode === dealer.code}
              key={dealer.code}
              onClick={() => selectDealer(dealer)}
              value={dealer.code}
            >
              <DealerListing dealer={dealer} />
            </RadioField>
          ))}
          {hasMore && mode !== 'paginate' && (
            <Button
              className={styles.showMore}
              isText
              onClick={handleShowMoreBtnClick}
              showCaret
              type="button"
            >
              {t('viewMoreDealers')}
            </Button>
          )}
          {pagination && pagination.totalPages > 1 && (
            <Pagination
              {...pagination}
              onNextClick={() => handlePaginateClick('next')}
              onPrevClick={() => handlePaginateClick('prev')}
            />
          )}
        </div>
      )}
      <input type="hidden" name="dealerCode" ref={register} />
      <input type="hidden" name="dealerZip" ref={register} />
    </fieldset>
  );
};

export default SelectADealer;
