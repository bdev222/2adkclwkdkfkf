import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useEffect } from 'react';
import { useFormContext } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

import FieldGroup from '../../../FieldGroup';
import TextField from '../../../TextField';
import { FormValues, NameField } from '../../models';
import styles from './styles.module.scss';

type NameFormProps = 'firstName' | 'lastName' | 'fullName';

type NameValues = Pick<FormValues, NameFormProps>;

type NameProps = NameField;

const Name: FC<NameProps> = () => {
  useStyles(styles);

  const { t } = useTranslation('slpForm');

  const { setValue, watch } = useFormContext<NameValues>();

  const { firstName, lastName } = watch(['firstName', 'lastName']);

  useEffect(() => {
    setValue('fullName', `${firstName} ${lastName}`.trim());
  }, [firstName, lastName]);

  const firstNameRequired = t('firstNameRequired');
  const lastNameRequired = t('lastNameRequired');

  return (
    <fieldset>
      <legend className={styles.legend}>
        {t('firstName')} {t('lastName')}
      </legend>
      <FieldGroup>
        <TextField
          label={`${t('firstName')}`}
          maxLength={50}
          name="firstName"
          validation={{ required: firstNameRequired }}
        />
        <TextField
          label={`${t('lastName')}`}
          maxLength={50}
          name="lastName"
          validation={{ required: lastNameRequired }}
        />
      </FieldGroup>
    </fieldset>
  );
};

export default Name;
