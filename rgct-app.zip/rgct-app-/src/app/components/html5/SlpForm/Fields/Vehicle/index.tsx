import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useEffect, useRef } from 'react';
import { useFormContext } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

import SelectField from '../../../SelectField';
import { FormValues, VehicleField } from '../../models';
import styles from './styles.module.scss';
import useVehicleOptions from './util/useVehicleOptions';

type VehicleValues = Pick<FormValues, 'vehicle'>;

const Vehicle: FC<VehicleField> = ({ data: { isHalfWidth = false } }) => {
  useStyles(styles);

  const { t } = useTranslation('slpForm');

  const { setValue, watch } = useFormContext<VehicleValues>();

  const preSelectedVehicle = useRef(watch('vehicle'));

  const options = useVehicleOptions(preSelectedVehicle.current);

  useEffect(() => {
    if (options.length && preSelectedVehicle.current) {
      setValue('vehicle', preSelectedVehicle.current);
    }
  }, [options]);

  const vehicleRequired = t('vehicleRequired');

  return (
    <fieldset
      className={cc({
        [styles.isHalfWidth]: isHalfWidth,
      })}
    >
      <legend className={styles.legend}>{t('selectAVehicle')}</legend>
      <h3 data-type="field-header">{t('selectAVehicle')}</h3>
      <SelectField
        label={t('selectVehicle')}
        name="vehicle"
        options={options}
        validation={{ required: vehicleRequired }}
      />
    </fieldset>
  );
};

export default Vehicle;
