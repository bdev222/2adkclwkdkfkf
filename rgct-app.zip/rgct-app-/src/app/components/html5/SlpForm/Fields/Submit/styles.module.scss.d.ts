export const submitButton: string;
export const legalCopy: string;
export const container: string;
export const isCentered: string;
