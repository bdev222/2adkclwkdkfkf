import React, { FC } from 'react';

import { ConditionalVehicleContainerField, FieldsProps } from '../../models';
import Fields from '..';

interface ConditionalVehicleContainerProps
  extends ConditionalVehicleContainerField,
    FieldsProps {}

const ConditionalVehicleContainer: FC<ConditionalVehicleContainerProps> = ({
  data,
  ...fieldsProps
}) => {
  const fields = fieldsProps.vehicle
    ? data.hasVehicle?.fields
    : data.hasNoVehicle.fields;

  return fields ? <Fields {...fieldsProps} fields={fields} /> : null;
};

export default ConditionalVehicleContainer;
