export const column: string;
