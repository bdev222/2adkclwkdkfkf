import React, { FC } from 'react';

import { Field, FieldsProps as IFieldsProps } from '../models';
import Column from './Column';
import Comment from './Comment';
import ConditionalVehicleContainer from './ConditionalVehicleContainer';
import Contact from './Contact';
import Divider from './Divider';
import Heading from './Heading';
import LockedDealer from './LockedDealer';
import Name from './Name';
import PreferredDateTime from './PreferredDateTime';
import Row from './Row';
import SelectADealer from './SelectADealer';
import SubHeading from './SubHeading';
import Submit from './Submit';
import Vehicle from './Vehicle';

interface FieldsProps extends IFieldsProps {
  fields: Field[];
}

const Fields: FC<FieldsProps> = ({ fields, ...remainingProps }) => {
  return (
    <>
      {fields.map((field, index) => {
        switch (field.field) {
          case 'column':
            return (
              <Column {...field} {...remainingProps} key={`column-${index}`} />
            );
          case 'comment':
            return <Comment {...field} key={`comment-${index}`} />;
          case 'conditionalVehicleContainer':
            return (
              <ConditionalVehicleContainer
                {...field}
                {...remainingProps}
                key={`conditionalVehicleContainer-${index}`}
              />
            );
          case 'contact':
            return <Contact {...field} key={`contact-${index}`} />;
          case 'divider':
            return <Divider {...field} key={`divider-${index}`} />;
          case 'heading':
            return <Heading {...field} key={`heading-${index}`} />;
          case 'name':
            return <Name {...field} key={`name-${index}`} />;
          case 'preferredDateTime':
            return (
              <PreferredDateTime
                {...field}
                {...remainingProps}
                key={`preferredDateTime-${index}`}
              />
            );
          case 'row':
            return <Row {...field} {...remainingProps} key={`row-${index}`} />;
          case 'selectDealer':
            return remainingProps.lockedDealer ? (
              <LockedDealer
                dealer={remainingProps.lockedDealer}
                key={`lockedDealer-${index}`}
              />
            ) : (
              <SelectADealer
                clearSelectedDealer={remainingProps.clearSelectedDealer}
                hasOffer={remainingProps.hasOffer}
                key={`selectDealer-${index}`}
                onDealerSelect={remainingProps.onDealerSelect}
                vehicle={remainingProps.vehicle}
              />
            );
          case 'subHeading':
            return <SubHeading {...field} key={`subHeading-${index}`} />;
          case 'submit':
            return (
              <Submit
                {...field}
                key={`submit-${index}`}
                submitLabel={remainingProps.submitLabel}
              />
            );
          case 'vehicle':
            return <Vehicle {...field} key={`vehicle-${index}`} />;
          default:
            return null;
        }
      })}
    </>
  );
};

export default Fields;
