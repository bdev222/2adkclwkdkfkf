export const legend: string;
export const isHalfWidth: string;
