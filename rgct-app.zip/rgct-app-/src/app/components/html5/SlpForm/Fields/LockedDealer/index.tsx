import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useEffect } from 'react';
import { useFormContext } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

import DealerListing from '../../../DealerListing';
import { Dealer } from '../../../DealersContext/models';
import { FormValues } from '../../models';
import styles from './styles.module.scss';

interface LockedDealerProps {
  dealer: Dealer;
}

type LockedDealerValues = Pick<FormValues, 'dealerCode' | 'dealerZip'>;

const LockedDealer: FC<LockedDealerProps> = ({ dealer }) => {
  useStyles(styles);

  const { t } = useTranslation('dealers');

  const { register, setValue } = useFormContext<LockedDealerValues>();

  useEffect(() => {
    setValue('dealerCode', dealer.code);
    setValue('dealerZip', dealer.zip);
  }, []);

  return (
    <fieldset className={styles.lockedDealerField}>
      <legend className={styles.legend}>{t('selectedDealer')}</legend>
      <h3>{t('selectedDealer')}</h3>
      <DealerListing className={styles.dealer} dealer={dealer} />
      <input type="hidden" name="dealerCode" ref={register} />
      <input type="hidden" name="dealerZip" ref={register} />
    </fieldset>
  );
};

export default LockedDealer;
