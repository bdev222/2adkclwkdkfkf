export const legend: string;
