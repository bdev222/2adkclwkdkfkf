export const row: string;
