export const paginateButton: string;
export const pagination: string;
export const isDisabled: string;
