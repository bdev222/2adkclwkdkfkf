import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import { IconArrow } from '../../../../Icons';
import styles from './styles.module.scss';

interface PaginationProps {
  currentPage: number;
  onNextClick: () => void;
  onPrevClick: () => void;
  totalPages: number;
}

const Pagination: FC<PaginationProps> = ({
  currentPage,
  onNextClick,
  onPrevClick,
  totalPages,
}) => {
  useStyles(styles);

  const { t } = useTranslation('dealers');

  return (
    <div className={styles.pagination}>
      <button
        className={cc([
          styles.paginateButton,
          { [styles.isDisabled]: currentPage === 1 },
        ])}
        data-dir="prev"
        onClick={onPrevClick}
        type="button"
      >
        <IconArrow />
        {t('previous')}
      </button>
      <span>{`${currentPage}/${totalPages}`}</span>
      <button
        className={cc([
          styles.paginateButton,
          { [styles.isDisabled]: currentPage === totalPages },
        ])}
        data-dir="next"
        onClick={onNextClick}
        type="button"
      >
        {t('next')}
        <IconArrow />
      </button>
    </div>
  );
};

export default Pagination;
