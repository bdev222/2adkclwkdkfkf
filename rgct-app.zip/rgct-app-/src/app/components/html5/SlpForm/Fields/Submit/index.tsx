import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, MouseEvent } from 'react';
import { useTranslation } from 'react-i18next';

import createLinkBlock from '../../../../shared/Analytics/blocks/createLinkBlock';
import EventTypes from '../../../../shared/Analytics/EventTypes';
import useTrigger from '../../../../shared/Analytics/useTrigger';
import Button from '../../../Button';
import { SubmitField } from '../../models';
import styles from './styles.module.scss';

interface SubmitProps extends SubmitField {
  submitLabel: string;
}

const Submit: FC<SubmitProps> = ({ data: { alignment }, submitLabel }) => {
  useStyles(styles);

  const { t } = useTranslation('slpForm');

  const trigger = useTrigger();

  const handleLegalCopyClick = ({ target }: MouseEvent<HTMLElement>) => {
    if (
      target instanceof HTMLAnchorElement &&
      target.hasAttribute('data-disclaimer')
    ) {
      trigger(
        EventTypes.Click,
        createLinkBlock({ href: target.href, text: target.textContent ?? '' })
      );
    }
  };

  return (
    <div
      className={cc([
        styles.container,
        {
          [styles.isCentered]: alignment === 'center',
        },
      ])}
    >
      <Button
        className={styles.submitButton}
        data-suppress-analytics
        type="submit"
      >
        {submitLabel}
      </Button>
      <small
        className={styles.legalCopy}
        dangerouslySetInnerHTML={{
          __html: t('ccpaDisclaimer', { submitLabel }),
        }}
        onClick={handleLegalCopyClick}
        role="presentation"
      />
    </div>
  );
};

export default Submit;
