export const isDesktop: string;
export const isMobile: string;
