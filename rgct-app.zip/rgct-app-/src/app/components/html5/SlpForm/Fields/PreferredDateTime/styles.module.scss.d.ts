export const legend: string;
export const datePickerInput: string;
