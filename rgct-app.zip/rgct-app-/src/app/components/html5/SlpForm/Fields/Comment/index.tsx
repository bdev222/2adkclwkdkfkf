import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useState } from 'react';
import { useTranslation } from 'react-i18next';

import Button from '../../../Button';
import TextareaField from '../../../TextareaField';
import { CommentField } from '../../models';
import styles from './styles.module.scss';

type CommentProps = CommentField;

const Comment: FC<CommentProps> = () => {
  useStyles(styles);

  const { t } = useTranslation('slpForm');

  const [showComments, setShowComments] = useState(false);

  return showComments ? (
    <TextareaField autoFocus label={t('comments')} name="comments" />
  ) : (
    <Button
      aria-expanded={false}
      className={styles.button}
      data-suppress-analytics
      isText
      onClick={() => setShowComments(true)}
      type="button"
    >
      + {t('addComments')}
    </Button>
  );
};

export default Comment;
