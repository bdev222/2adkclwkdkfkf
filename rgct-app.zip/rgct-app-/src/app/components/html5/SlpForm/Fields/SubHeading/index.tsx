import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import { SubHeadingField } from '../../models';
import styles from './styles.module.scss';

type SubHeadingProps = SubHeadingField;

const SubHeading: FC<SubHeadingProps> = ({
  data: { desktopOnly, headingKey, mobileOnly },
}) => {
  useStyles(styles);

  const { t } = useTranslation('slpForm');

  return (
    <h3
      className={cc({
        [styles.isDesktop]: desktopOnly,
        [styles.isMobile]: mobileOnly,
      })}
      data-type="field-header"
    >
      {t(headingKey)}
    </h3>
  );
};

export default SubHeading;
