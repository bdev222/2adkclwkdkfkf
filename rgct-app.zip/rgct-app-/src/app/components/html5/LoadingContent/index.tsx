import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useEffect, useState } from 'react';

import usePrevious from '../../../util/usePrevious';
import { IconLoad } from '../Icons';
import styles from './styles.module.scss';

interface LoadingContentProps {
  containerClassName?: string;
  isLoading: boolean;
  loaderClassName?: string;
}

const LoadingContent: FC<LoadingContentProps> = ({
  children,
  containerClassName,
  isLoading,
  loaderClassName,
}) => {
  useStyles(styles);

  const prevIsVisible = usePrevious(isLoading);

  const [isAnimating, setIsAnimating] = useState(isLoading);

  useEffect(() => {
    if (prevIsVisible !== undefined && prevIsVisible !== isLoading) {
      setIsAnimating(true);
    }
  }, [isLoading, prevIsVisible]);

  const handleAnimationEnd = () => {
    setIsAnimating(false);
  };

  return (
    <div className={cc([styles.container, containerClassName])}>
      {children && (
        <div
          className={cc({
            [styles.isLoading]: isLoading,
            [styles.loadingEnd]: isLoading,
            [styles.loadingStart]: prevIsVisible !== undefined && !isLoading,
          })}
        >
          {children}
        </div>
      )}
      {(isLoading || isAnimating) && (
        <div
          className={cc([
            styles.loader,
            loaderClassName,
            {
              [styles.fadeIn]: isLoading,
              [styles.fadeOut]: !isLoading,
            },
          ])}
          onAnimationEnd={handleAnimationEnd}
        >
          <IconLoad />
        </div>
      )}
    </div>
  );
};

export default LoadingContent;
