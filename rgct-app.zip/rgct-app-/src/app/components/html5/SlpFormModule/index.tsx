import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useState } from 'react';

import { FormType, Location } from '../../../util/campaignCodes';
import getFormCode from '../../../util/getFormCode';
import AnalyticsContext from '../../shared/Analytics/AnalyticsContext';
import createSectionBlock from '../../shared/Analytics/blocks/createSectionBlock';
import { Dealer } from '../DealersContext/models';
import FormConfirmation from '../FormConfirmation';
import { BackgroundImages } from '../FormConfirmation/models';
import SlpForm from '../SlpForm';
import { OnSlpSuccess, OutgoingSlpForm } from '../SlpForm/models';
import { Offer, Vehicle } from './models';
import styles from './styles.module.scss';

interface FormSuccessProps {
  dealer: Dealer;
  formValues: Partial<OutgoingSlpForm>;
}

interface SlpFormModuleProps {
  backgroundImages?: BackgroundImages;
  formId: FormType;
  location: Location;
  offer?: Offer;
  preSelectedVehicle?: string;
  vehicle?: Vehicle;
}

const SlpFormModule: FC<SlpFormModuleProps> = ({
  backgroundImages,
  formId,
  location,
  offer,
  preSelectedVehicle,
  vehicle,
}) => {
  useStyles(styles);

  const [formSuccessProps, setFormSuccessProps] = useState<FormSuccessProps>();

  const handleSlpSuccess: OnSlpSuccess = (values, dealer) => {
    setFormSuccessProps({
      dealer,
      formValues: values,
    });
  };

  const formCode = getFormCode(formId);

  return (
    <section className={styles.container}>
      {!formSuccessProps ? (
        <AnalyticsContext
          blocks={createSectionBlock(`${formCode}_form_module`)}
        >
          <SlpForm
            type={formId}
            location={location}
            offer={offer}
            onSuccess={handleSlpSuccess}
            preSelectedVehicle={preSelectedVehicle}
            variation="module"
            vehicle={vehicle}
          />
        </AnalyticsContext>
      ) : (
        <AnalyticsContext
          blocks={createSectionBlock(`${formCode}_confirmation_module`)}
        >
          <FormConfirmation
            {...formSuccessProps}
            analytics={{
              timeout: 100,
            }}
            backgroundImages={backgroundImages}
            formCode={formCode}
            offer={offer}
            vehicle={vehicle}
          />
        </AnalyticsContext>
      )}
    </section>
  );
};

export default SlpFormModule;
