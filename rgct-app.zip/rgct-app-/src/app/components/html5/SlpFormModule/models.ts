import type {
  Offer as OfferProps,
  OfferBase,
} from '../../../../functions/layout/transforms/util/getOffers/models';

export interface Vehicle {
  color: string;
  description?: string;
  image: string;
  seriesId: string;
  seriesName: string;
  trimCode?: string;
  trimId?: string;
  trimLabel?: string;
  year: string;
}

type OfferCardProps =
  | 'bonus'
  | 'disclaimers'
  | 'endDate'
  | 'id'
  | 'includedTrims'
  | 'primaryLabel'
  | 'ribbon'
  | 'series'
  | 'seriesOrCardTitle';

export type Offer = OfferBase & Pick<OfferProps, OfferCardProps>;
