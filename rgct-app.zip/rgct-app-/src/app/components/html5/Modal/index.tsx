import FocusTrap from 'focus-trap-react';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, MouseEvent, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { Transition } from 'react-spring/renderprops';

import { disableScroll, enableScroll } from '../../../util/scrollHelpers';
import AnalyticsButton from '../../shared/Analytics/AnalyticsButton';
import { IconClose } from '../Icons';
import ModalProvider from './ModalProvider';
import styles from './styles.module.scss';

function getPortalRoot() {
  const portalRoot = document.getElementById('modal-root');

  if (!portalRoot) {
    throw new Error('Could not find #modal-root in the DOM');
  }

  return portalRoot;
}

export interface ModalProps {
  closeModal: () => void;
  isOpen: boolean;
  openModal: () => void;
}

const Modal: FC<ModalProps> = ({ children, ...modalProps }) => {
  const { closeModal, isOpen } = modalProps;

  useStyles(styles);

  const modalRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      disableScroll();

      document.body.addEventListener('keydown', handleBodyKeyDown);
    } else {
      enableScroll();

      document.body.removeEventListener('keydown', handleBodyKeyDown);
    }

    return () => {
      if (isOpen) {
        enableScroll();
      }

      document.body.removeEventListener('keydown', handleBodyKeyDown);
    };
  }, [isOpen]);

  const handleBodyKeyDown = (event: KeyboardEvent) => {
    if (event.key === 'Escape') {
      closeModal();
    }
  };

  const handleOverlayClick = (event: MouseEvent<HTMLDivElement>) => {
    if (
      event.target &&
      (event.target instanceof HTMLElement ||
        event.target instanceof SVGElement) &&
      modalRef.current &&
      modalRef.current.contains(event.target)
    ) {
      return;
    }

    closeModal();
  };

  return isOpen
    ? createPortal(
        <Transition
          enter={{ opacity: 1 }}
          from={{ opacity: 0 }}
          items={isOpen}
          leave={{ opacity: 0 }}
        >
          {show =>
            show &&
            (props => (
              <ModalProvider {...modalProps}>
                <div
                  className={styles.container}
                  onClick={handleOverlayClick}
                  role="presentation"
                  style={props}
                >
                  <FocusTrap
                    focusTrapOptions={{
                      clickOutsideDeactivates: true,
                      initialFocus: false,
                    }}
                  >
                    <div className={styles.modal} ref={modalRef}>
                      <div className={styles.content}>{children}</div>
                      <AnalyticsButton
                        analytics={{ text: 'Close' }}
                        onClick={closeModal}
                        className={styles.closeButton}
                      >
                        <IconClose />
                      </AnalyticsButton>
                    </div>
                  </FocusTrap>
                </div>
              </ModalProvider>
            ))
          }
        </Transition>,
        getPortalRoot()
      )
    : null;
};

export default Modal;
