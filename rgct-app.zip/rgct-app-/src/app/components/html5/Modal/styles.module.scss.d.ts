export const closeButton: string;
export const container: string;
export const modal: string;
export const content: string;
