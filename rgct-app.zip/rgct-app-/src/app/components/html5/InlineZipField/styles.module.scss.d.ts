export const container: string;
export const field: string;
export const input: string;
export const zipValue: string;
export const placeholder: string;
export const hasError: string;
export const zipDisclaimers: string;
export const zipDisclaimer: string;
