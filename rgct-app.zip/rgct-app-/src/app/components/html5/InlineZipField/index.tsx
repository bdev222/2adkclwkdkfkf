import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { ChangeEvent, FC, FocusEvent, useState } from 'react';
import { useFormContext } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

import usePrevious from '../../../util/usePrevious';
import createLinkBlock from '../../shared/Analytics/blocks/createLinkBlock';
import EventTypes from '../../shared/Analytics/EventTypes';
import useTrigger from '../../shared/Analytics/useTrigger';
import { IconSearch } from '../Icons';
import TextField from '../TextField';
import styles from './styles.module.scss';

export interface InlineZipFieldProps {
  className?: string;
  disclaimers?: string[];
  initialZip?: string;
  name: string;
  onBlur?: (value: string, previousZip?: string) => void;
  onChange?: (newZip: string) => void;
  onSubmit: (value?: string) => void;
}

const InlineZipField: FC<InlineZipFieldProps> = ({
  className,
  disclaimers,
  initialZip,
  name,
  onBlur,
  onChange,
  onSubmit,
}) => {
  useStyles(styles);

  const [zipCode, setZipCode] = useState(initialZip);

  const prevZipCode = usePrevious(zipCode);

  const { t } = useTranslation('slpForm');

  const { errors } = useFormContext();

  const placeholderText = t('common:zipCode');

  const zipRequired = t('zipRequired');

  const trigger = useTrigger();

  const handleInputBlur = (event: FocusEvent<HTMLInputElement>) => {
    onBlur?.(event.currentTarget.value, prevZipCode); // NOSONAR
  };

  const handleInputChange = (event: ChangeEvent<HTMLInputElement>) => {
    const newZip = event.currentTarget.value.replace(/[^0-9]/g, '');

    onChange?.(newZip); // NOSONAR

    if (newZip.length === 5) {
      setZipCode(newZip);

      onSubmit?.(newZip); // NOSONAR
    }
  };

  const handleInputFocus = (event: FocusEvent<HTMLInputElement>) => {
    trigger(EventTypes.Click, createLinkBlock({ text: 'zipcode' }));
  };

  return (
    <div className={cc([styles.container, className])}>
      <div className={styles.field}>
        <TextField
          aria-label={placeholderText}
          className={styles.input}
          data-suppress-analytics
          defaultValue={zipCode}
          inputMode="numeric"
          label={placeholderText}
          maxLength={5}
          name={name}
          onBlur={handleInputBlur}
          onChange={handleInputChange}
          onFocus={handleInputFocus}
          pattern="[0-9]*"
          placeholder={placeholderText}
          Icon={<IconSearch />}
          type="text"
          variant="underlined"
          validation={{
            minLength: { message: zipRequired, value: 5 },
            required: zipRequired,
          }}
        />
      </div>
      {!errors[name] && disclaimers?.length ? (
        <div className={styles.zipDisclaimers}>
          {disclaimers.map(disclaimer => (
            <p className={styles.zipDisclaimer} key={disclaimer}>
              {disclaimer}
            </p>
          ))}
        </div>
      ) : null}
    </div>
  );
};

export default InlineZipField;
