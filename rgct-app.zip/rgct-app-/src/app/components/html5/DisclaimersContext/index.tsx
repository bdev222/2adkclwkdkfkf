import React, { createContext, FC, useContext, useState } from 'react';

interface Disclaimer {
  code: string;
  description: string;
}

interface DisclaimerWithIndex extends Disclaimer {
  index: number;
}

type DisclaimersMap = Map<string, DisclaimerWithIndex>;

interface DisclaimerStore {
  disclaimers: DisclaimersMap;
  setDisclaimers: (disclaimers: DisclaimersMap) => void;
}

export const DisclaimersContext = createContext<DisclaimerStore | undefined>(
  undefined
);

export const useDisclaimersContext = () => {
  const disclaimersContext = useContext(DisclaimersContext);

  if (!disclaimersContext) {
    throw new Error(
      'useDisclaimersContext must be used within a DisclaimersContextProvider'
    );
  }

  const { disclaimers, setDisclaimers: setState } = disclaimersContext;

  const setDisclaimers = (nextDisclaimers: Disclaimer[]) => {
    nextDisclaimers.forEach((disclaimer, index) => {
      if (!disclaimers.has(disclaimer.code)) {
        disclaimers.set(disclaimer.code, {
          ...disclaimer,
          index: index + 1,
        });
      }
    });

    setState(new Map(disclaimers));
  };

  const unsetDisclaimers = () => {
    disclaimersContext.setDisclaimers(new Map());
  };

  const getDisclaimerByCode = (code: string) => {
    return disclaimersContext.disclaimers.get(code);
  };

  const getDisclaimers = () => {
    return disclaimersContext.disclaimers;
  };

  return {
    getDisclaimers,
    getDisclaimerByCode,
    setDisclaimers,
    unsetDisclaimers,
  };
};

const DisclaimersContextProvider: FC = ({ children }) => {
  const [disclaimers, setDisclaimers] = useState<DisclaimersMap>(new Map());

  return (
    <DisclaimersContext.Provider value={{ disclaimers, setDisclaimers }}>
      {children}
    </DisclaimersContext.Provider>
  );
};

export default DisclaimersContextProvider;
