import {
  Offer as OfferProps,
  OfferBase,
} from '../../../../functions/layout/transforms/util/getOffers/models';
import EventTypes from '../../shared/Analytics/EventTypes';
import { Dealer } from '../DealersContext/models';
import { OutgoingSlpForm } from '../SlpForm/models';

export interface FormConfirmationProps {
  analytics?: AnalyticsOptions;
  backgroundImages?: BackgroundImages;
  dealer: Dealer;
  formCode: string;
  formValues: Partial<OutgoingSlpForm>;
  offer?: Offer;
  vehicle?: Vehicle;
}

interface AnalyticsOptions {
  event?: EventTypes;
  timeout?: number;
}

export interface BackgroundImages {
  desktop: string;
  mobile: string;
}

export interface Vehicle {
  color: string;
  description?: string;
  image: string;
  seriesId: string;
  seriesName: string;
  trimCode?: string;
  trimId?: string;
  trimLabel?: string;
  year: string;
}

type OfferCardProps =
  | 'bonus'
  | 'disclaimers'
  | 'endDate'
  | 'id'
  | 'includedTrim'
  | 'primaryLabel'
  | 'ribbon'
  | 'series'
  | 'seriesOrCardTitle';

export type Offer = OfferBase & Pick<OfferProps, OfferCardProps>;
