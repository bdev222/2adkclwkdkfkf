import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, ReactNode, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import scrollIntoView from 'scroll-into-view-if-needed';

import appendTrackingParams from '../../../util/appendTrackingParams';
import useJsdsContexts from '../../../util/useJsdsContexts';
import AnalyticsComponent from '../../shared/Analytics/AnalyticsComponent';
import createCampaignCodeBlock from '../../shared/Analytics/blocks/createCampaignCodeBlock';
import createDealerBlock from '../../shared/Analytics/blocks/createDealerBlock';
import createKeyMetricsBlock from '../../shared/Analytics/blocks/createKeyMetricsBlock';
import createOfferBlock from '../../shared/Analytics/blocks/createOfferBlock';
import createSeriesBlock from '../../shared/Analytics/blocks/createSeriesBlock';
import Button from '../Button';
import DealerListing from '../DealerListing';
import { IconPin } from '../Icons';
import OfferBanner from '../OfferBanner';
import DealerLink from './DealerLink';
import Hero from './Hero';
import { FormConfirmationProps as BaseFormConfirmationProps } from './models';
import styles from './styles.module.scss';

interface FormConfirmationProps extends BaseFormConfirmationProps {
  renderFooter?: ReactNode;
}

const FormConfirmation: FC<FormConfirmationProps> = ({
  analytics = {},
  backgroundImages,
  dealer,
  formCode,
  formValues: {
    campaignCode,
    customerEmail,
    preferredDate,
    preferredTime,
    vehicleModel,
    vehicleYear,
  },
  offer,
  renderFooter,
  vehicle,
}) => {
  useStyles(styles);

  const { t } = useTranslation(['slpForm', 'dealers', 'offer']);

  const { page, site } = useJsdsContexts();

  const headerRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    if (headerRef.current) {
      scrollIntoView(headerRef.current, {
        behavior: 'smooth',
        scrollMode: 'if-needed',
      });
    }
  }, []);

  let ctaUrl = `${page.meta.route.prefix}/deals-incentives/`;
  if (vehicle) {
    ctaUrl += `series/${vehicle.seriesId}/`;
  }

  return (
    <AnalyticsComponent
      blocks={[
        offer ? createOfferBlock(offer) : {},
        createDealerBlock(dealer),
        createSeriesBlock({ seriesName: vehicleModel, year: vehicleYear }),
      ]}
      event={analytics.event}
      initialBlocks={[
        createKeyMetricsBlock(`km-${formCode}-complete`),
        campaignCode ? createCampaignCodeBlock(campaignCode) : {},
      ]}
      timeout={analytics.timeout}
    >
      <div className={styles.container}>
        <header className={styles.header} ref={headerRef}>
          <h2 className={styles.heading}>{t('common:thankYou')}</h2>
          {!!preferredDate && !!preferredTime ? (
            <>
              <p>{t('dealerTestDriveScheduled', { dealer: dealer.name })}</p>
              <div className={styles.scheduledTime}>
                <span>{preferredDate}</span>
                <span>{t(preferredTime)}</span>
              </div>
            </>
          ) : (
            <DealerLink
              className={styles.dealerContactYouText}
              dealer={dealer}
            />
          )}
          {customerEmail && (
            <p
              className={styles.emailConfirmationSentText}
              dangerouslySetInnerHTML={{
                __html: t('emailConfirmationSent', { email: customerEmail }),
              }}
            />
          )}
        </header>
        {backgroundImages && vehicle && (
          <Hero backgroundImages={backgroundImages} vehicle={vehicle} />
        )}
        <div className={styles.banner}>
          {offer && (
            <div className={styles.offer}>
              <OfferBanner
                ctaComponent={
                  <Button as="a" to={ctaUrl}>
                    {t('offer:viewMoreOffers')}
                  </Button>
                }
                offer={offer}
                showShareButton
              />
            </div>
          )}
          <div className={styles.selectedDealer}>
            <h3 className={styles.dealerHeading}>
              {t('dealers:selectedDealer')}
            </h3>
            <div className={styles.dealerDetails}>
              <IconPin />
              <DealerListing dealer={dealer} />
              <div className={styles.dealerCtas}>
                <Button
                  analytics={{ metrics: 'km-dealer-visit_site' }}
                  as="a"
                  target="_blank"
                  title={`${t('slpForm:visitDealer')} ${t('common:newWindow')}`}
                  to={appendTrackingParams(
                    dealer.url,
                    page.meta.route.canvas,
                    site.tdaConfig.code
                  )}
                >
                  {t('slpForm:visitDealer')}
                </Button>
                <Button
                  analytics={{ metrics: 'km-dealer-contact-call' }}
                  as="a"
                  to={`tel:${dealer.phone}`}
                  isOutline
                >
                  {dealer.phone}
                </Button>
              </div>
            </div>
          </div>
        </div>
        {renderFooter}
      </div>
    </AnalyticsComponent>
  );
};

export default FormConfirmation;
