import React, { FC, MouseEvent } from 'react';
import { useTranslation } from 'react-i18next';

import createLinkBlock from '../../../shared/Analytics/blocks/createLinkBlock';
import EventTypes from '../../../shared/Analytics/EventTypes';
import useTrigger from '../../../shared/Analytics/useTrigger';
import { Dealer } from '../../DealersContext/models';

interface DealerLinkProps {
  className?: string;
  dealer: Dealer;
}

const DealerLink: FC<DealerLinkProps> = ({ className, dealer }) => {
  const { t } = useTranslation('slpForm');

  const trigger = useTrigger();

  const handleDealerContainerClick = (event: MouseEvent<HTMLDivElement>) => {
    if (
      event.target instanceof HTMLAnchorElement &&
      event.target.hasAttribute('data-dealer-link')
    ) {
      trigger(
        EventTypes.Click,
        createLinkBlock({
          href: event.target.href,
          metrics: 'km-dealer-visit_site',
          text: event.target.textContent ?? '',
        })
      );
    }
  };

  return (
    <p
      className={className}
      dangerouslySetInnerHTML={{
        __html: t('dealerContactYou', {
          dealerLink: `<a href="${
            dealer.url
          }" target="_blank" rel="noopener" title="${dealer.name} ${t(
            'common:newWindow'
          )}" data-dealer-link>${dealer.name}</a>`,
        }),
      }}
      onClick={handleDealerContainerClick}
      role="presentation"
    />
  );
};

export default DealerLink;
