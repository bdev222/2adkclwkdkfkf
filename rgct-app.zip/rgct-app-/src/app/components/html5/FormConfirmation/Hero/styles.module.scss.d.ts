export const background: string;
export const content: string;
export const heroImage: string;
