import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import LazyImage from '../../LazyImage';
import { BackgroundImages, Vehicle } from '../models';
import styles from './styles.module.scss';

interface HeroProps {
  backgroundImages: BackgroundImages;
  vehicle: Vehicle;
}

const Hero: FC<HeroProps> = ({ backgroundImages, vehicle }) => {
  useStyles(styles);

  return (
    <>
      <div className={styles.background}>
        <picture>
          <source srcSet={backgroundImages.mobile} media="(max-width: 767px)" />
          <LazyImage
            alt=""
            placeholderStyles={{ height: '100%', width: '100%' }}
            role="presentation"
            src={backgroundImages.desktop}
          />
        </picture>
      </div>
      <div className={styles.content}>
        <div className={styles.heroImage}>
          <LazyImage src={vehicle.image} alt={vehicle.description} />
          <p>{vehicle.description}</p>
        </div>
      </div>
    </>
  );
};

export default Hero;
