import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import styles from './styles.module.scss';

const FieldGroup: FC = ({ children }) => {
  useStyles(styles);

  return <div className={styles.container}>{children}</div>;
};

export default FieldGroup;
