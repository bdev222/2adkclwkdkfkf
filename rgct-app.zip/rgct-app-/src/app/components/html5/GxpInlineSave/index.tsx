import React, { FC, MouseEvent, useEffect } from 'react';

import { getCookie } from '../../../util/getCookie';
import useJsdsContexts from '../../../util/useJsdsContexts';
import getGxpSaveItem from './getGxpSaveItem';
import { Offer } from './models';

interface GxpInlineSaveProps {
  className?: string;
  offer: Offer;
}

const GxpInlineSave: FC<GxpInlineSaveProps> = ({ className, offer }) => {
  const {
    page: {
      meta: { route },
    },
    site: { tdaConfig },
  } = useJsdsContexts();

  useEffect(() => {
    const zipCodeTda = getCookie('tda'); // The TDA represented by their zip code
    const dealerCode = getCookie('tcom-dealer-code');

    if (!dealerCode || zipCodeTda !== tdaConfig.code) {
      return;
    }

    let tries = 0;

    const renderInlineSaves = () => {
      if (
        window.DGDataHub &&
        typeof window.DGDataHub.renderInlineSaves === 'function'
      ) {
        const gxpSaveItem = getGxpSaveItem(offer, dealerCode, route.prefix);

        window.DGDataHub.renderInlineSaves(gxpSaveItem);

        return;
      }

      tries += 1;

      if (tries <= 5) {
        setTimeout(renderInlineSaves, 1000);
      }
    };

    renderInlineSaves();
  }, [offer, route, tdaConfig]);

  const handleSaveClick = (event: MouseEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
  };

  return (
    <div className={className} onClick={handleSaveClick} role="presentation">
      <div className="dg-encircle" id={`dg-inline-saves-offer-${offer.id}`} />
    </div>
  );
};

export default GxpInlineSave;
