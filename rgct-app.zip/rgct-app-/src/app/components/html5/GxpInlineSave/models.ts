import {
  Offer as OfferProps,
  OfferBase,
} from '../../../../functions/layout/transforms/util/getOffers/models';

type GxpOfferProps =
  | 'bonus'
  | 'cardImage'
  | 'disclaimers'
  | 'endDate'
  | 'id'
  | 'includedTrims'
  | 'series';

export type Offer = OfferBase & Pick<OfferProps, GxpOfferProps>;
