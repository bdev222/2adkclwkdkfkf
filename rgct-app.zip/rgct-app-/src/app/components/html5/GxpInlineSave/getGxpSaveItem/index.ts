import { OfferType } from '../../../../../functions/layout/transforms/util/getOffers/models';
import { Offer } from '../models';

interface GxpInlineSave {
  [key: string]: GxpSaveItem;
}

interface GxpSaveItem {
  additionalDisclaimers: string;
  brand: 'Toyota';
  cash?: number;
  dealerCd: string;
  disclaimers: string[];
  dueAtSigning?: number;
  endTime: number;
  extraCashAmount: number;
  imageHref: string;
  marketingNames: string;
  marketingSeries: string;
  modelTrims: string[];
  monthlyPayment?: number;
  offerId: string;
  offerType: string;
  percent?: number;
  term?: number;
  type: 'offer';
  viewSimilarOffersHref: string;
  year: number;
}

function getImageHref(offer: Offer) {
  const firstTrim = offer.includedTrims?.[0];
  const seriesId = offer.series[0].id[0];
  const year = offer.series[0].year;

  if (!firstTrim || !seriesId || !year) {
    return '';
  }

  return `https://www.toyota.com/responsive/images/jellies/${year}/${seriesId}/${firstTrim.code}.png`;
}

export default function getGxpSaveItem(
  offer: Offer,
  dealerCode: string,
  routePrefix: string
): GxpInlineSave | void {
  if (
    offer.type !== OfferType.Apr &&
    offer.type !== OfferType.Cash &&
    offer.type !== OfferType.Lease
  ) {
    return;
  }

  const seriesId = offer.series[0].id[0];
  const seriesName = offer.series[0].name[0];

  const gxpOfferToSave: GxpSaveItem = {
    additionalDisclaimers: '', // todo: get additional disclaimers
    brand: 'Toyota',
    dealerCd: dealerCode,
    disclaimers: offer.disclaimers || [],
    endTime: new Date(
      `${offer.endDate.month}/${offer.endDate.day}/${offer.endDate.year}`
    ).getTime(),
    extraCashAmount:
      !!offer.bonus && !!offer.bonus.amount
        ? parseFloat(offer.bonus.amount)
        : 0,
    imageHref: getImageHref(offer),
    marketingNames: seriesName,
    marketingSeries: seriesName,
    modelTrims: [], // todo: get Trims
    offerId: offer.id,
    offerType: offer.type.toLowerCase(),
    type: 'offer',
    viewSimilarOffersHref: `https://www.toyota.com${routePrefix}/deals-incentives/series/${seriesId}/`,
    year: parseInt(offer.series[0].year, 10),
  };

  if (offer.type === OfferType.Lease) {
    const { dueAtSigning, duration, monthlyPayment } = offer.lease;

    gxpOfferToSave.dueAtSigning = parseFloat(dueAtSigning);
    gxpOfferToSave.monthlyPayment = parseFloat(monthlyPayment);
    gxpOfferToSave.term = parseFloat(duration);
  } else if (offer.type === OfferType.Cash) {
    const { cashAmount } = offer.cash;

    gxpOfferToSave.cash = parseFloat(cashAmount);
  } else if (offer.type === OfferType.Apr) {
    const { duration, rate } = offer.apr;

    gxpOfferToSave.percent = parseFloat(rate);
    gxpOfferToSave.term = parseFloat(duration);
  }

  return {
    [`dg-inline-saves-offer-${offer.id}`]: gxpOfferToSave,
  };
}
