export const container: string;
export const name: string;
export const distance: string;
export const address: string;
export const openUntil: string;
