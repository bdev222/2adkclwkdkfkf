export interface AvailableHours {
  closeTime: string;
  openTime: string;
  status: 'too early' | 'open';
}

export interface NextAvailableHours {
  nextOpenDay: string;
  nextOpenTime: string;
  status: 'closed';
}

export interface UnavailableHours {
  status: 'unavailable';
}

export type HoursType = AvailableHours | NextAvailableHours | UnavailableHours;

export interface FormattedTime {
  displayTime: string;
  hour: number;
}

export interface Hours {
  closeTime: FormattedTime;
  day: string;
  dayIndex: number;
  openTime: FormattedTime;
}
