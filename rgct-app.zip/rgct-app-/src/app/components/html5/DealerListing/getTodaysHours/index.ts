import { Dealer, HoursOfOperation } from '../../DealersContext/models';
import { FormattedTime, Hours, HoursType, UnavailableHours } from './models';

const DAYS_OF_WEEK = [
  'Sunday',
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
];

const FAILED_RESPONSE: UnavailableHours = {
  status: 'unavailable',
};

function formatTime(time: number): FormattedTime {
  const hour = Math.floor(time / 60);
  const minutes = time % 60;

  const period = hour > 12 ? 'PM' : 'AM';
  const displayHour = period === 'AM' ? hour : hour - 12;

  let displayTime = `${displayHour}`;
  if (minutes !== 0) {
    const displayMinutes = minutes < 10 ? `0${minutes}` : minutes;
    displayTime += `:${displayMinutes}`;
  }

  displayTime += ` ${period}`;

  return {
    hour,
    displayTime,
  };
}

function findFirstAvailableHours(date: Date, hours: HoursOfOperation) {
  let indexCounter = 1;

  function getAvailableHours(dayIndex: number): Hours {
    const day = DAYS_OF_WEEK[dayIndex];

    function tryNextDay() {
      if (indexCounter === 7) {
        throw new Error('Unable to get available hours');
      }

      indexCounter += 1;

      const nextDayIndex = (dayIndex + 1) % 7;

      return getAvailableHours(nextDayIndex);
    }

    const foundHours = hours.daysOfWeek.find(
      ({ dayOfWeekCode }) => dayOfWeekCode === day
    );

    if (
      !foundHours ||
      !foundHours.availabilityEndTimeMeasure ||
      !foundHours.availabilityStartTimeMeasure
    ) {
      return tryNextDay();
    }

    const {
      availabilityStartTimeMeasure: openTime,
      availabilityEndTimeMeasure: closeTime,
    } = foundHours;

    const openHour = formatTime(openTime.value);
    const closeHour = formatTime(closeTime.value);

    // If we found available hours and it's today, it also needs to be open
    if (date.getDay() === dayIndex && date.getHours() >= closeHour.hour) {
      return tryNextDay();
    }

    return {
      closeTime: closeHour,
      day,
      dayIndex,
      openTime: openHour,
    };
  }

  return getAvailableHours(date.getDay());
}

export default function getFirstAvailableHours(
  hours?: Dealer['hours']
): HoursType {
  if (!hours) {
    return FAILED_RESPONSE;
  }

  const generalHours = hours.find(hour => hour.hoursTypeCode === 'General');

  if (!generalHours) {
    return FAILED_RESPONSE;
  }

  const today = new Date();

  try {
    const {
      closeTime: closeHour,
      day,
      dayIndex,
      openTime: openHour,
    } = findFirstAvailableHours(today, generalHours);

    // If it's the same day as today, it's open
    if (dayIndex === today.getDay()) {
      const isOpen = today.getHours() >= openHour.hour;

      return {
        status: isOpen ? 'open' : 'too early',
        closeTime: closeHour.displayTime,
        openTime: openHour.displayTime,
      };
    }

    return {
      nextOpenDay: day,
      nextOpenTime: openHour.displayTime,
      status: 'closed',
    };
  } catch (error) {
    console.log('Unable to get todays hours', error);
    return FAILED_RESPONSE;
  }
}
