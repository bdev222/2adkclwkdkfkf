import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useMemo } from 'react';
import { useTranslation } from 'react-i18next';

import makeDealerDistance from '../../../util/makeDealerDistance';
import { Dealer } from '../DealersContext/models';
import getFirstAvailableHours from './getTodaysHours';
import styles from './styles.module.scss';

interface DealerListingProps {
  className?: string;
  dealer: Dealer;
}

const DealerListing: FC<DealerListingProps> = ({ className, dealer }) => {
  useStyles(styles);

  const { t } = useTranslation('dealers');

  const todaysHours = useMemo(() => getFirstAvailableHours(dealer.hours), []);

  const openUntil =
    todaysHours.status === 'unavailable'
      ? t('hoursUnavailable')
      : todaysHours.status === 'too early'
      ? t('notYetOpen', todaysHours)
      : todaysHours.status === 'open'
      ? t('openUntil', todaysHours)
      : todaysHours.status === 'closed'
      ? t('closed', todaysHours)
      : '';

  return (
    <div className={cc([styles.container, className])}>
      <h5 className={styles.name}>{dealer.name}</h5>
      {dealer.distance && (
        <span className={styles.distance}>
          ({t('milesAway', makeDealerDistance(dealer))})
        </span>
      )}
      <address
        className={styles.address}
      >{`${dealer.address}, ${dealer.city}, ${dealer.state} ${dealer.zip}`}</address>
      <span className={styles.openUntil}>{openUntil}</span>
    </div>
  );
};

export default DealerListing;
