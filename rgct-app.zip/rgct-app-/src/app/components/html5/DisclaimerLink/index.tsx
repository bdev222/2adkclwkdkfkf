import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import { useDisclaimersContext } from '../DisclaimersContext';
import styles from './styles.module.scss';

interface DisclaimerLinkProps {
  code: string;
}

const DisclaimerLink: FC<DisclaimerLinkProps> = ({ code }) => {
  useStyles(styles);

  const { getDisclaimerByCode } = useDisclaimersContext();

  const disclaimer = getDisclaimerByCode(code);

  return disclaimer ? (
    <a
      className={styles.link}
      href={`#disclaimer-${disclaimer.code}`}
      role="button"
    >
      <sup>{disclaimer.index}</sup>
    </a>
  ) : null;
};

export default DisclaimerLink;
