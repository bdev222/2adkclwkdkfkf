import { OfferDetailFields } from '../../../../functions/layout/transforms/offerDetail/models';

export {
  BackgroundImages,
  CtaType,
  Hero,
  NextStepCtas,
  OfferDetail,
} from '../../../../functions/layout/transforms/offerDetail/models';
export { Module } from '../../../../functions/layout/transforms/util/getModule/models';
export { Badge as Badges } from '../../../../functions/layout/transforms/util/getOffers/models';

export type IBullets = OfferDetailFields['offer']['bullets'];

export interface OfferDetailProps extends OfferDetailFields {
  fireInitialKeyMetric?: boolean;
}
