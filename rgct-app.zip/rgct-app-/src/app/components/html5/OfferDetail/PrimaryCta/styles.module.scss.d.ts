export const primaryCtaButton: string;
