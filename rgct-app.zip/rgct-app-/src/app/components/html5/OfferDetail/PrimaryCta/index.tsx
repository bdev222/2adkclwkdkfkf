import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import Cta from '../../../../components/html5/Cta';
import { Vehicle } from '../../../../components/html5/Cta/models';
import { Location } from '../../../../util/campaignCodes';
import ImInterestedCta from '../ImInterestedCta';
import { BackgroundImages, CtaType, OfferDetail } from '../models';
import styles from './styles.module.scss';

interface PrimaryCtaProps {
  backgroundImages: BackgroundImages;
  cta: CtaType;
  offer: OfferDetail;
  vehicle?: Vehicle;
}

const PrimaryCta: FC<PrimaryCtaProps> = ({
  backgroundImages,
  cta,
  offer,
  vehicle,
}) => {
  useStyles(styles);

  const { t } = useTranslation('ctas');

  const ctaLabel =
    cta.type === 'links'
      ? ['certified-used', 'parts-&-services', 'rent-a-car', 'safety'].includes(
          cta.primaryCta.id
        )
        ? t('common:learnMore')
        : t(cta.primaryCta.id)
      : '';

  return cta.type === 'links' ? (
    <Cta
      backgroundImages={backgroundImages}
      className={styles.primaryCtaButton}
      id={cta.primaryCta.id}
      location={Location.ModalOfferDetailTop}
      name={ctaLabel}
      offer={offer}
      vehicle={vehicle}
    >
      <span>{ctaLabel}</span>
    </Cta>
  ) : (
    <ImInterestedCta className={styles.primaryCtaButton} />
  );
};

export default PrimaryCta;
