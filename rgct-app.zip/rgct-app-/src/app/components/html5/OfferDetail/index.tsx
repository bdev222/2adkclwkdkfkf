import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';

import OfferBanner from '../../../components/html5/OfferBanner';
import AnalyticsContext from '../../../components/shared/Analytics/AnalyticsContext';
import createOfferBlock from '../../../components/shared/Analytics/blocks/createOfferBlock';
import createSectionBlock from '../../../components/shared/Analytics/blocks/createSectionBlock';
import createSeriesBlock from '../../../components/shared/Analytics/blocks/createSeriesBlock';
import { Devices } from '../../../models';
import { Ctas } from '../../../renderings/html/OfferDetail/models';
import useDealerInventoryCtaExperience from '../../../util/useDealerInventoryCtaExperience';
import useJsdsContexts from '../../../util/useJsdsContexts';
import createKeyMetricsBlock from '../../shared/Analytics/blocks/createKeyMetricsBlock';
import EventTypes from '../../shared/Analytics/EventTypes';
import useTrigger from '../../shared/Analytics/useTrigger';
import Badge from './Badge';
import Bullets from './Bullets';
import Hero from './Hero';
import { OfferDetailProps } from './models';
import Module from './Module';
import NextStepCtas from './NextStepCtas';
import PrimaryCta from './PrimaryCta';
import SecondaryCtas from './SecondaryCtas';
import styles from './styles.module.scss';
import { transformCtas } from './util/transformCtas';

const OfferDetail: FC<OfferDetailProps> = ({
  backgroundImages,
  ctas,
  fireInitialKeyMetric,
  hero,
  modules,
  nextSteps,
  offer,
  seriesId,
  seriesName,
  trim,
  year,
}) => {
  useStyles(styles);

  const { site } = useJsdsContexts();

  const trigger = useTrigger();

  const { t } = useTranslation(['offerDetail', 'ctas']);

  const experience = useDealerInventoryCtaExperience();

  const {
    badges,
    bullets,
    description,
    disclaimers,
    includedTrim,
    primaryLabel,
  } = offer;

  const vehicle =
    seriesId && seriesName && year
      ? {
          color: '',
          image: hero.image,
          seriesId,
          seriesName,
          trimLabel: includedTrim ?? '',
          year,
          ...trim,
        }
      : undefined;

  const analyticsBlock = useMemo(
    () => ({
      ...createOfferBlock(offer),
      ...createSectionBlock('offer_overview'),
      ...(vehicle ? createSeriesBlock(vehicle) : {}),
    }),
    []
  );

  useEffect(() => {
    if (fireInitialKeyMetric) {
      trigger(EventTypes.KmPageLoad, [
        analyticsBlock,
        createKeyMetricsBlock('km-offers-detail'),
      ]);
    }
  }, [fireInitialKeyMetric, site]);

  // Temporary removal of PE CTA for Mirai
  if (vehicle && vehicle.seriesId === 'mirai') {
    Object.entries(ctas).forEach(entry => {
      const [, value] = entry;
      if (value.type === 'links') {
        // If the primary CTA is estimate payment, replace it with the first
        // Secondary CTA
        if (value.primaryCta.id === 'estimate-payment') {
          value.primaryCta = value.secondaryCtas[0];
          value.secondaryCtas.splice(0, 1);
        }
        // If Secondary CTA's contain estimate payment, remove it
        const foundIndex = value.secondaryCtas.findIndex(
          cta => cta.id === 'estimate-payment'
        );
        if (foundIndex > -1) {
          value.secondaryCtas.splice(foundIndex, 1);
        }
      }
      if (value.type === 'modal') {
        const foundIndex = value.links.findIndex(
          cta => cta.id === 'estimate-payment'
        );
        if (foundIndex > -1) {
          value.links.splice(foundIndex, 1);
        }
      }
    });
  }

  const transformedCtas: Ctas = useMemo(() => {
    if (experience && experience === 'experienceB') {
      return transformCtas(ctas);
    }

    return ctas;
  }, [ctas, experience]);

  return (
    <AnalyticsContext blocks={analyticsBlock}>
      <Hero
        backgroundImages={backgroundImages}
        badges={badges}
        hero={hero}
        seriesId={seriesId}
        seriesName={seriesName}
      />
      <div className={styles.container}>
        <div className={styles.offerContentContainer}>
          <div className={styles.banner}>
            <OfferBanner
              ctaComponent={
                <AnalyticsContext
                  blocks={createSectionBlock('offers_next_step')}
                >
                  {[Devices.Desktop, Devices.Mobile].map(device => (
                    <div
                      className={styles.ctaContainer}
                      data-device={device}
                      key={device}
                    >
                      <PrimaryCta
                        cta={transformedCtas[device]}
                        backgroundImages={backgroundImages}
                        offer={offer}
                        vehicle={vehicle}
                      />
                    </div>
                  ))}
                </AnalyticsContext>
              }
              offer={offer}
            />
          </div>
          <div className={styles.details}>
            <div className={styles.info}>
              {description && (
                <p className={styles.description}>{description}</p>
              )}
              <Bullets bullets={bullets} primaryLabel={primaryLabel} />
              {badges.length > 2 && (
                <div className={styles.threeBadges}>
                  {badges.map((badge, index) => (
                    <Badge badge={badge} key={index} />
                  ))}
                </div>
              )}
              {badges.length > 0 && (
                <div className={styles.mobileBadges}>
                  {badges.map((badge, index) => (
                    <Badge badge={badge} key={index} />
                  ))}
                </div>
              )}
              <div className={styles.ctaContainer} data-device={Devices.Mobile}>
                <SecondaryCtas
                  backgroundImages={backgroundImages}
                  ctas={transformedCtas.mobile}
                  offer={offer}
                  vehicle={vehicle}
                />
              </div>
              <div className={styles.disclaimers}>
                <p>{t('termsAndConditions')}</p>
                {disclaimers.map((disclaimer, index) => (
                  <p key={index}>{disclaimer}</p>
                ))}
              </div>
            </div>
            <div className={styles.ctaContainer} data-device={Devices.Desktop}>
              <SecondaryCtas
                backgroundImages={backgroundImages}
                ctas={transformedCtas.desktop}
                offer={offer}
                vehicle={vehicle}
              />
            </div>
          </div>
        </div>
      </div>
      {[Devices.Desktop, Devices.Mobile].map(device =>
        modules[device].map((module, index) => (
          <div
            className={styles.moduleContainer}
            data-device={device}
            data-module-id={module.id}
            key={`${device}-module-${index}`}
          >
            <Module module={module} offer={offer} vehicle={vehicle} />
          </div>
        ))
      )}
      <NextStepCtas
        backgroundImages={backgroundImages}
        ctas={nextSteps}
        offer={offer}
        vehicle={vehicle}
      />
    </AnalyticsContext>
  );
};

export default OfferDetail;
