import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import LazyImage from '../../../../components/html5/LazyImage';
import Link from '../../../../components/html5/Link';
import { Badges as IBadge } from '../models';

interface BadgeProps {
  badge: IBadge;
}

const Badge: FC<BadgeProps> = ({ badge }) => {
  const { t } = useTranslation();

  const badgeImage = <LazyImage alt={badge.alt} src={badge.src} />;

  return badge.href ? (
    <Link
      as="a"
      rel="noopener"
      target="_blank"
      title={`${badge.alt} ${t('newWindow')}`}
      to={badge.href}
    >
      {badgeImage}
    </Link>
  ) : (
    badgeImage
  );
};

export default Badge;
