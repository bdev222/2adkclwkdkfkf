export const ctaButton: string;
