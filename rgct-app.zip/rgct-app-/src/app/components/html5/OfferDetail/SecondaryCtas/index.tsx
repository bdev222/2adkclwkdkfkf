import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import Cta from '../../../../components/html5/Cta';
import {
  BackgroundImages,
  Vehicle,
} from '../../../../components/html5/Cta/models';
import ShareButton from '../../../../components/html5/ShareButton';
import AnalyticsContext from '../../../../components/shared/Analytics/AnalyticsContext';
import createSectionBlock from '../../../../components/shared/Analytics/blocks/createSectionBlock';
import { Location } from '../../../../util/campaignCodes';
import { CtaType, OfferDetail } from '../models';
import styles from './styles.module.scss';

interface SecondaryCtasProps {
  backgroundImages: BackgroundImages;
  ctas: CtaType;
  offer: OfferDetail;
  vehicle?: Vehicle;
}

const SecondaryCtas: FC<SecondaryCtasProps> = ({
  backgroundImages,
  ctas,
  offer,
  vehicle,
}) => {
  useStyles(styles);

  const { t } = useTranslation('ctas');

  return (
    <AnalyticsContext blocks={createSectionBlock('offers_next_step')}>
      {ctas.type === 'links' &&
        ctas.secondaryCtas.map((cta, index) => {
          const ctaLabel = t(cta.id);

          return (
            <Cta
              backgroundImages={backgroundImages}
              className={styles.ctaButton}
              id={cta.id}
              key={index}
              location={Location.ModalOfferDetailTop}
              name={ctaLabel}
              offer={offer}
              vehicle={vehicle}
            >
              <span>{ctaLabel}</span>
            </Cta>
          );
        })}
      <ShareButton />
    </AnalyticsContext>
  );
};

export default SecondaryCtas;
