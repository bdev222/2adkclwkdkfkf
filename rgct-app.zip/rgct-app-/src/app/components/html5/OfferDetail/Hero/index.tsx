import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import BackButton from '../../../../components/html5/BackButton';
import LazyImage from '../../../../components/html5/LazyImage';
import Badge from '../Badge';
import { BackgroundImages, Badges, Hero as IHero } from '../models';
import styles from './styles.module.scss';

interface HeroProps {
  backgroundImages: BackgroundImages;
  badges: Badges[];
  hero: IHero;
  seriesId?: string;
  seriesName?: string;
}

const Hero: FC<HeroProps> = ({
  backgroundImages,
  badges,
  hero,
  seriesId,
  seriesName,
}) => {
  useStyles(styles);

  return (
    <div className={styles.container}>
      <div className={styles.hero}>
        <div className={styles.background}>
          <picture>
            <source
              srcSet={backgroundImages.mobile}
              media="(max-width: 767px)"
            />
            <LazyImage
              alt=""
              height={285}
              role="presentation"
              src={backgroundImages.desktop}
              width={1440}
            />
          </picture>
        </div>
        <div className={styles.content}>
          <div className={styles.leftActions}>
            <BackButton seriesId={seriesId} seriesName={seriesName} />
          </div>
          <div className={styles.heroImage}>
            <LazyImage src={hero.image} alt={hero.description} />
          </div>
          <div className={styles.rightActions}>
            <div
              className={cc([
                {
                  [styles.badges]: badges.length <= 2,
                  [styles.badges3]: badges.length > 2,
                },
              ])}
            >
              {badges.map((badge, index) => (
                <Badge badge={badge} key={index} />
              ))}
            </div>
          </div>
        </div>
      </div>
      {hero.description && (
        <p className={styles.jellyDescription}>{hero.description}</p>
      )}
    </div>
  );
};

export default Hero;
