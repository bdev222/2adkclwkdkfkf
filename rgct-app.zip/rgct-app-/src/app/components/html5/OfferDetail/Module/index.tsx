import React, { FC } from 'react';

import { Vehicle } from '../../../../components/html5/Cta/models';
import SlpFormModule from '../../../../components/html5/SlpFormModule';
import { Location } from '../../../../util/campaignCodes';
import FindADealerModule from '../../FindADealerModule';
import RelatedOffersModule from '../../RelatedOffersModule';
import { Module as OfferDetailModule, OfferDetail } from '../models';

interface ModuleProps {
  module: OfferDetailModule;
  offer: OfferDetail;
  vehicle?: Vehicle;
}

const Module: FC<ModuleProps> = ({ module, offer, vehicle }) => {
  switch (module.id) {
    case 'contact-dealer':
    case 'request-quote':
    case 'schedule-test-drive':
      return (
        <SlpFormModule
          formId={module.id}
          location={Location.ModuleOfferDetail}
          offer={offer}
          vehicle={vehicle}
        />
      );
    case 'find-dealer':
      return (
        <FindADealerModule location={Location.ModuleFindADealerOfferDetail} />
      );
    case 'related-offers':
      return (
        <RelatedOffersModule
          offers={module.meta.offers}
          title={module.meta.title}
        />
      );
    default:
      return null;
  }
};

export default Module;
