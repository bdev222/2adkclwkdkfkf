import React, { FC } from 'react';

import Button from '../../../../components/html5/Button';

interface ImInterestedCtaProps {
  className?: string;
}

const ImInterestedCta: FC<ImInterestedCtaProps> = ({ className }) => {
  return <Button className={className}>I'm interested</Button>;
};

export default ImInterestedCta;
