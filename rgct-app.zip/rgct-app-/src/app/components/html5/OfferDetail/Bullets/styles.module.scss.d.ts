export const texts: string;
export const textItem: string;
export const links: string;
export const link: string;
export const linkItem: string;
