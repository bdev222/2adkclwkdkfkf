import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import { IconArrow } from '../../Icons';
import Link from '../../Link';
import { IBullets } from '../models';
import styles from './styles.module.scss';

interface BulletsProps {
  bullets: IBullets;
  primaryLabel: string;
}

const Bullets: FC<BulletsProps> = ({
  bullets: { links, texts },
  primaryLabel,
}) => {
  useStyles(styles);

  const { t } = useTranslation();

  const hasTextBullets = texts.length > 0;

  const hasLinkBullets = links.length > 0;

  return (
    <>
      {hasTextBullets && (
        <ul className={styles.texts} aria-label="Disclaimers">
          {texts.map((bullet, index) => (
            <li className={styles.textItem} key={index}>
              {bullet.text}
            </li>
          ))}
        </ul>
      )}
      {hasLinkBullets && (
        <ul
          className={styles.links}
          aria-label={`Links to benefits of ${primaryLabel} deal`}
        >
          {links.map((link, index) => (
            <li className={styles.linkItem} key={index}>
              <Link
                as="a"
                className={styles.link}
                rel="noreferrer"
                target="_blank"
                title={`${link.text} ${t('newWindow')}`}
                to={link.link}
              >
                {link.text}
                <IconArrow />
              </Link>
            </li>
          ))}
        </ul>
      )}
    </>
  );
};

export default Bullets;
