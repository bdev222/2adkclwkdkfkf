import { TFunction } from 'i18next';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import Cta, { CtaIdDealers } from '../../../../components/html5/Cta';
import { Vehicle } from '../../../../components/html5/Cta/models';
import { IconArrow } from '../../../../components/html5/Icons';
import AnalyticsContext from '../../../../components/shared/Analytics/AnalyticsContext';
import createSectionBlock from '../../../../components/shared/Analytics/blocks/createSectionBlock';
import { Devices } from '../../../../models';
import { Location } from '../../../../util/campaignCodes';
import { BackgroundImages, NextStepCtas as Ctas, OfferDetail } from '../models';
import styles from './styles.module.scss';

interface NextStepCtaProps {
  backgroundImages: BackgroundImages;
  ctas: Ctas;
  offer: OfferDetail;
  vehicle?: Vehicle;
}

function getCtaContent(t: TFunction, id: string) {
  switch (id) {
    case 'request-quote':
      return {
        copy: t('requestQuoteCopy'),
        ctaLabel: t('request-quote'),
        headline: t('lookingForAQuote'),
      };
    case 'estimate-payment':
      return {
        copy: t('estimatePaymentCopy'),
        ctaLabel: t('estimate-payment'),
        headline: t('yourPotentialPayment'),
      };
    case 'find-dealer':
      return {
        copy: t('findDealerCopy'),
        ctaLabel: t('find-dealer'),
        headline: t('wheresYourNearestDealer'),
      };
    case 'view-inventory':
      return {
        copy: t('viewInventoryCopy'),
        ctaLabel: t('view-inventory'),
        headline: t('whatsInStock'),
      };
    case CtaIdDealers.VisitDealer:
      return {
        copy: t('visitDealerCopy'),
        ctaLabel: t('visitLocalDealer'),
        headline: t('exploreNearbyToyotaDealer'),
      };
    case 'trade-in-value':
      return {
        copy: t('tradeInValueCopy'),
        ctaLabel: t('findYourKbb'),
        headline: t('whatsMyTradeInValue'),
      };
    case 'schedule-test-drive':
      return {
        copy: t('scheduleTestDriveCopy'),
        ctaLabel: t('schedule-test-drive'),
        headline: t('getBehindTheWheel'),
      };
    case 'contact-dealer':
      return {
        copy: t('contactDealerCopy'),
        ctaLabel: t('contact-dealer'),
        headline: t('contact-dealer'),
      };
    case 'build-&-price':
      return {
        copy: t('buildPriceCopy'),
        ctaLabel: t('build-&-price'),
        headline: t('buildYourOwn'),
      };
    case CtaIdDealers.CallDealer:
      return {
        copy: t('callDealerCopy'),
        ctaLabel: t('call-dealer'),
        headline: t('callYourLocalDealer'),
      };
    case 'what-fits-my-budget':
      return {
        copy: t('whatFitsMyBudgetCopy'),
        ctaLabel: t('whatFitsMyBudgetKnow'),
        headline: t('what-fits-my-budget'),
      };
    default:
      throw new Error(`Unrecognized CTA id: "${id}"`);
  }
}

const NextStepCtas: FC<NextStepCtaProps> = ({
  backgroundImages,
  ctas,
  offer,
  vehicle,
}) => {
  useStyles(styles);

  const { t } = useTranslation('ctas');

  return (
    <AnalyticsContext blocks={createSectionBlock('offers_next_step')}>
      <div className={styles.container}>
        {[Devices.Desktop, Devices.Mobile].map(device => {
          const ctasByDevice = ctas[device];

          return ctasByDevice ? (
            <ul className={styles.ctas} data-device={device} key={device}>
              {ctasByDevice.map((cta, index) => {
                const { copy, ctaLabel, headline } = getCtaContent(t, cta.id);

                return (
                  <li className={styles.item} key={`${cta.id}-${index}`}>
                    <div className={styles.itemContent}>
                      <strong className={styles.headline}>{headline}</strong>
                      <p className={styles.copy}>{copy}</p>
                      <Cta
                        analytics={{ text: ctaLabel }}
                        backgroundImages={backgroundImages}
                        className={styles.ctaLabel}
                        id={cta.id}
                        location={Location.ModalOfferDetailBottom}
                        name={ctaLabel}
                        offer={offer}
                        vehicle={vehicle}
                      >
                        <span className={styles.ctaLabel}>{ctaLabel}</span>
                      </Cta>
                      <IconArrow />
                    </div>
                  </li>
                );
              })}
            </ul>
          ) : null;
        })}
      </div>
    </AnalyticsContext>
  );
};

export default NextStepCtas;
