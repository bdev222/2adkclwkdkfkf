export const ctaLabel: string;
export const container: string;
export const ctas: string;
export const item: string;
export const itemContent: string;
export const headline: string;
export const copy: string;
