import { Devices } from '../../../../models';
import { Ctas } from '../../../../renderings/html/OfferDetail/models';

export const transformCtas = (ctas: Ctas) => {
  [Devices.Desktop, Devices.Mobile].forEach(device => {
    const cta = ctas[device];

    if (cta.type === 'links') {
      const { primaryCta, secondaryCtas } = cta;

      if (primaryCta.id === 'view-inventory') {
        primaryCta.id = 'view-dealer-inventory';
      }

      const viewInventoryIndex = secondaryCtas.findIndex(
        secondaryCta => secondaryCta.id === 'view-inventory'
      );

      if (viewInventoryIndex >= 0) {
        secondaryCtas[viewInventoryIndex].id = 'view-dealer-inventory';
      }
    }
  });

  return ctas;
};
