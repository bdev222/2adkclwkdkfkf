export { Bonus } from '../../../../functions/layout/transforms/util/getOffers/models';
