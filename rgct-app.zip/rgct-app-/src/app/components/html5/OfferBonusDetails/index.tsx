import React, { FC } from 'react';

import { Bonus } from './models';

interface BonusDetailsProps {
  bonus: Bonus;
  bonusCopyOverride?: string;
  className?: string;
}

const OfferBonusDetails: FC<BonusDetailsProps> = ({
  bonus,
  bonusCopyOverride,
  className,
}) => {
  const bonusLabel = bonusCopyOverride ?? bonus.copy;

  return (
    <div className={className}>
      {bonus.amount && bonus.label && (
        <p>
          <strong>{`+ $${parseInt(bonus.amount, 10).toLocaleString()} ${
            bonus.label
          }`}</strong>
        </p>
      )}
      {bonusLabel && <p>{bonusLabel}</p>}
    </div>
  );
};

export default OfferBonusDetails;
