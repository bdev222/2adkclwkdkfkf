import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import LazyImage from '../../LazyImage';
import styles from './styles.module.scss';

interface CardImageProps {
  alt: string;
  src: string;
}

const CardImage: FC<CardImageProps> = ({ alt, src }) => {
  useStyles(styles);

  return (
    <div className={styles.container}>
      <LazyImage
        alt={alt}
        className={styles.offerCardImage}
        placeholderStyles={{ height: 92 }}
        src={src}
      />
    </div>
  );
};

export default CardImage;
