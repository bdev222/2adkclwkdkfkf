export const container: string;
export const offerCardImage: string;
