import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import useJsdsContexts from '../../../util/useJsdsContexts';
import AnalyticsContext from '../../shared/Analytics/AnalyticsContext';
import createOfferBlock from '../../shared/Analytics/blocks/createOfferBlock';
import createSeriesBlock from '../../shared/Analytics/blocks/createSeriesBlock';
import GxpInlineSave from '../GxpInlineSave';
import Link from '../Link';
import CardImage from './CardImage';
import { FinancialsContent } from './FinancialsContent';
import { OfferCard as IOfferCard } from './models';
import styles from './styles.module.scss';

interface OfferCardProps {
  className?: string;
  offer: IOfferCard;
  tabIndex?: number;
}

const OfferCard: FC<OfferCardProps> = ({ className, offer, tabIndex }) => {
  const {
    bonusTag,
    cardImage,
    description,
    endDate,
    id,
    includedTrim,
    offerTitle,
    primaryLabel,
    ribbon,
    secondaryLabel,
    series,
    seriesOrCardTitle,
    trimLabel,
    type,
  } = offer;

  useStyles(styles);

  const { t } = useTranslation('offer');

  const {
    page: {
      meta: { route },
    },
  } = useJsdsContexts();

  // The parent component should already contain a seriesBlock, but if we know
  // what trim the offer applies to, then override that block with one that
  // contains the trim (seriesGrade) information.
  const seriesBlockWithTrim = includedTrim
    ? createSeriesBlock({
        seriesName: series[0].name[0],
        trimLabel: includedTrim,
        year: series[0].year,
      })
    : {};

  return (
    <AnalyticsContext blocks={[createOfferBlock(offer), seriesBlockWithTrim]}>
      <Link
        analytics={{ text: 'view_details' }}
        className={cc([styles.container, className])}
        tabIndex={tabIndex}
        to={{
          pathname: `${route.prefix}/deals-incentives/${id}/`,
          state: { from: route.canvas },
        }}
      >
        <span className={styles.gxp}>
          <GxpInlineSave offer={offer} />
        </span>
        <div
          className={cc([
            styles.ribbonAndLabels,
            { [styles.isColumn]: secondaryLabel },
          ])}
        >
          <span
            className={cc([
              styles.ribbon,
              { [styles.isHiddenMobile]: !secondaryLabel },
            ])}
          >
            {ribbon}
          </span>
          <span className={styles.offerLabelsContainer}>
            <span className={styles.offerLabels}>
              <span className={styles.primaryLabel} data-type={type}>
                {primaryLabel}
                {secondaryLabel ? (
                  <span className={styles.secondaryLabel}>
                    {secondaryLabel}
                  </span>
                ) : (
                  <span className={styles.inlineMobileRibbon}>{ribbon}</span>
                )}
              </span>
            </span>
          </span>
        </div>
        <div className={styles.content}>
          <div className={styles.subHeading}>
            <p
              className={cc([
                styles.seriesOrCardTitle,
                { [styles.hasImage]: cardImage },
              ])}
            >
              {seriesOrCardTitle}
            </p>

            {offerTitle && <p className={styles.offerHeading}>{offerTitle}</p>}
          </div>
          {cardImage && <CardImage alt={cardImage.alt} src={cardImage.src} />}
          <FinancialsContent offer={offer} />
        </div>
        <div className={styles.bonusDescriptionTrimContainer}>
          {bonusTag && <p className={styles.bonusTag}>{bonusTag}</p>}
          {trimLabel && <p className={styles.trim}>{trimLabel}</p>}
          {description && <p className={styles.description}>{description}</p>}
        </div>
        <footer className={styles.footer}>
          <span className={styles.viewDetails}>{t('viewDetails')}</span>
          <span className={styles.endDate}>{t('expiration', endDate)}</span>
        </footer>
      </Link>
    </AnalyticsContext>
  );
};

export default OfferCard;
