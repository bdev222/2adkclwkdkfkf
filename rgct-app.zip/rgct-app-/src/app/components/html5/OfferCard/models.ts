import {
  Offer,
  OfferBase,
} from '../../../../functions/layout/transforms/util/getOffers/models';

export { OfferType } from '../../../../functions/layout/transforms/util/getOffers/models';

type OfferCardProps =
  | 'bonusTag'
  | 'cardImage'
  | 'description'
  | 'disclaimers'
  | 'endDate'
  | 'id'
  | 'includedTrim'
  | 'offerTitle'
  | 'primaryLabel'
  | 'ribbon'
  | 'secondaryLabel'
  | 'series'
  | 'seriesOrCardTitle'
  | 'trimLabel';

export type OfferCard = OfferBase & Pick<Offer, OfferCardProps>;
