import { Dispatch } from 'react';

import { ActionType } from '../../../models';

export interface DealersState {
  allDealers: Dealer[];
  dealers: Dealer[];
  didFetchDealers: boolean;
  hasMore: boolean;
  isFetching: boolean;
  mode: 'expand' | 'paginate';
  pagination?: PaginationSettings;
  queryTerm: string;
  queryType: string;
}

export type DealersDispatch = Dispatch<DealersActions>;

export type DealersActions =
  | EnablePaginationModeAction
  | FetchErrorAction
  | FetchStartAction
  | FetchSuccessAction
  | PaginateAction
  | ShowMoreAction;

type EnablePaginationModeAction = ActionType<'enablePaginationMode'>;

type FetchStartAction = ActionType<
  'fetchStart',
  {
    query: string;
    type: string;
  }
>;

type FetchSuccessAction = ActionType<'fetchSuccess', Dealer[]>;

type FetchErrorAction = ActionType<'fetchError'>;

type PaginateAction = ActionType<'paginate', { dir: 'next' | 'prev' }>;

type ShowMoreAction = ActionType<'showMore'>;

interface PaginationSettings {
  currentPage: number;
  totalPages: number;
}

export interface FetchDealersParams {
  [param: string]: boolean | number | string;
}

export enum QueryType {
  'Dealer' = 'dealername',
  'Mirai' = 'mirai',
  'Pma' = 'pma',
  'Proximity' = 'proximity',
}

export interface Dealer {
  address: string;
  brand: string;
  city: string;
  code: string;
  distance?: string; // undefined on dealerName searches
  hours: HoursOfOperation[];
  isGxp: boolean;
  isMirai: boolean;
  isPma: boolean;
  lat: number;
  long: number;
  metro: string;
  name: string;
  phone: string;
  serviceUrl: string;
  state: string;
  tda: string;
  url: string;
  zip: string;
}

export interface DealersWithMetaData {
  dealerId: string;
  details: DealerLocatorDetail;
  meta: DealerMetaData;
}

export interface DisResponse {
  dealerLocator: Array<{
    dealerLocatorDetail: DealerLocatorDetail[];
  }>;
  dealerMetaData: Array<{
    dealerMetaDataHeader: {
      dealerParty: {
        partyID: {
          value: string;
        };
      };
    };
    dealerMetaDataDetail: DealerMetaData[];
  }>;
}

interface DealerLocatorDetail {
  dealerParty: {
    partyID: {
      value: string;
    };
    relationshipTypeCode: {
      value: string;
    };
    specifiedOrganization: {
      companyName: {
        value: string;
      };
      divisionCode: {
        name: string;
        value: string;
      };
      postalAddress: {
        cityName: {
          value: string;
        };
        stateOrProvinceCountrySubDivisionID: {
          value: string;
        };
        postcode: {
          value: string;
        };
      };
      primaryContact: PrimaryContact[];
    };
  };
  hoursOfOperation: HoursOfOperation[];
  proximityMeasureGroup: {
    proximityMeasure: {
      value: number;
    };
  };
}

interface DealerMetaData {
  additionalService: AdditionalService[];
  organization: Organization[];
  program: Program[];
}

export interface UriCommunication {
  channelCode: {
    value: string;
  };
  uriid: {
    value: string;
  };
}

export interface AdditionalService {
  code: {
    value: string;
  };
  name: {
    value: string;
  };
  participationIndicator: boolean;
}

export interface PrimaryContact {
  typeCode: {
    value: string;
  };
  uricommunication?: UriCommunication[];
}

export interface Program {
  code: {
    value: string;
  };
}

export interface Organization {
  organizationType: {
    value: string;
  };
  party: Array<{
    specifiedOrganization: {
      companyCode: {
        value: string;
      };
    };
  }>;
}

export interface HoursOfOperation {
  daysOfWeek: Array<{
    availabilityEndTimeMeasure?: {
      unitCode: string;
      value: number;
    };
    availabilityStartTimeMeasure?: {
      unitCode: string;
      value: number;
    };
    dayOfWeekCode: string;
  }>;
  hoursTypeCode: string;
}
