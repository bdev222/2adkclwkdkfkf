import Axios from 'axios';

import { FetchDealersParams } from '../../models';
import transformDealers from '../transformDealers';

export default async function fetchDealers(params: FetchDealersParams) {
  const { data } = await Axios.get(
    `${process.env.DISREST_SERVICE}/disrest/getDealers`,
    {
      headers: { 'x-api-key': `${process.env.DISREST_API_KEY}` },
      params,
    }
  );

  return transformDealers(data.showDealerLocatorDataArea);
}
