import { FetchDealersParams, QueryType } from '../../models';

export default function getParams(
  queryType: QueryType = QueryType.Pma,
  additionalParams: FetchDealersParams
) {
  const params: FetchDealersParams = {
    brandId: 1,
    excludeAttributeKey: 'ServiceCenterOnly',
    resultsFormat: 'json',
    searchMode: 'pmaProximityLayered',
    ...additionalParams,
  };

  if (queryType === QueryType.Proximity) {
    params.searchMode = 'proximityOnly';
  } else if (queryType === QueryType.Mirai) {
    params.attributeKey = 'MiraiSales';
    params.proximityMode = 'radius';
    params.radiusMiles = 3000;
  }

  return params;
}
