import isZipCodeString from '../../../../../util/isZipCodeString';
import { FetchDealersParams, QueryType } from '../../models';
import getParams from '../getParams';
import isCityStateQuery from '../isCityStateQuery';

export default function parseQuery(
  query: string,
  forceZipCodeProximity: boolean
): [string, FetchDealersParams] {
  let type = 'dealership';

  const input = query.trim().toLowerCase();

  if (isZipCodeString(input)) {
    const queryType = forceZipCodeProximity
      ? QueryType.Proximity
      : QueryType.Pma;

    type = 'zip';

    return [type, getParams(queryType, { zipcode: input })];
  }

  const cityState = isCityStateQuery(input);
  if (cityState) {
    type = 'city, state';

    return [
      type,
      getParams(QueryType.Proximity, {
        city: cityState[0],
        state: cityState[1],
      }),
    ];
  }

  // Assume it is a dealer name search
  return [
    type,
    getParams(QueryType.Dealer, {
      dealerName: input,
      searchMode: 'filterOnly',
    }),
  ];
}
