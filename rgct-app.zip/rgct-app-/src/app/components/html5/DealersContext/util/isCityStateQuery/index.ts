type IsCityStateQuery = [string, string] | false;

const TWO_LETTER_STATE_REGEX = /\s[a-zA-Z]{2}$/;

const STATES = [
  'alabama',
  'alaska',
  'american samoa',
  'arizona',
  'arkansas',
  'california',
  'colorado',
  'connecticut',
  'delaware',
  'district of columbia',
  'federated states of micronesia',
  'florida',
  'georgia',
  'guam',
  'hawaii',
  'idaho',
  'illinois',
  'indiana',
  'iowa',
  'kansas',
  'kentucky',
  'louisiana',
  'maine',
  'marshall islands',
  'maryland',
  'massachusetts',
  'michigan',
  'minnesota',
  'mississippi',
  'missouri',
  'montana',
  'nebraska',
  'nevada',
  'new hampshire',
  'new jersey',
  'new mexico',
  'new york',
  'north carolina',
  'north dakota',
  'northern mariana islands',
  'ohio',
  'oklahoma',
  'oregon',
  'palau',
  'pennsylvania',
  'puerto rico',
  'rhode island',
  'south carolina',
  'south dakota',
  'tennessee',
  'texas',
  'utah',
  'vermont',
  'virgin islands',
  'virginia',
  'washington',
  'washington dc',
  'west virginia',
  'wisconsin',
  'wyoming',
];

export default function isCityStateQuery(query: string): IsCityStateQuery {
  let city;
  let state;

  // If ends in space and any two characters
  const twoLetterStateMatches = query.match(TWO_LETTER_STATE_REGEX);
  if (twoLetterStateMatches) {
    state = twoLetterStateMatches[0].trim();
    city = query.replace(state, '').replace(',', '').trim();

    return [city, state];
  }

  // If there's a comma, assume the second part is the state
  if (query.includes(',')) {
    [city, state] = query.split(',');

    return [city.trim(), state.trim()];
  }

  // Look for text from the STATES array
  const foundState = STATES.find(currentState => query.includes(currentState));
  if (foundState) {
    city = query.replace(foundState, '').trim();

    return [city, foundState];
  }

  return false;
}
