import { Dealer } from '../../models';

export default function organizeDealers(dealers: Dealer[]) {
  const pmaDealers: Dealer[] = [];
  const nonPmaDealers: Dealer[] = [];

  for (const dealer of dealers) {
    if (dealer.isPma) {
      pmaDealers.push(dealer);
    } else {
      nonPmaDealers.push(dealer);
    }
  }

  const allDealers = [...pmaDealers, ...nonPmaDealers];

  const pmaDealersCount = pmaDealers.length;

  return { allDealers, pmaDealersCount };
}
