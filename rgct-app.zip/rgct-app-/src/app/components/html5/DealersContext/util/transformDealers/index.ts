import { get } from 'lodash';

import {
  AdditionalService,
  DealersWithMetaData,
  DisResponse,
  Organization,
  PrimaryContact,
  Program,
} from '../../models';

const PHONE_REGEX = /^(\d{3})(\d{3})(\d{4})$/;

function isParticipantType(
  additionalService: AdditionalService[],
  type: string
) {
  return additionalService.some(({ code, participationIndicator }) => {
    return code.value === type && participationIndicator;
  });
}

function isPmaParticipant(programs: Program[]) {
  return programs.some(program => program.code.value === 'PMA');
}

function findContactByType(
  contacts: PrimaryContact[],
  value: string
): PrimaryContact | undefined {
  return contacts.find(contact => contact.typeCode.value === value);
}

function getWebsite(contact: PrimaryContact): string {
  const communication = contact.uricommunication?.find(({ channelCode }) => {
    return channelCode.value === 'Website';
  });

  if (communication) {
    return communication.uriid.value;
  }

  return '';
}

function getTdaCode(organizations: Organization[]) {
  let tdaCode = '';

  const organization = organizations.find(({ organizationType }) => {
    return organizationType.value === 'TDA';
  });

  if (organization) {
    tdaCode = organization.party[0].specifiedOrganization.companyCode.value;
  }

  return tdaCode;
}

function formatPhoneNumber(phone = '') {
  const matches = phone.replace(/\D/g, '').match(PHONE_REGEX);

  if (matches) {
    return `(${matches[1]}) ${matches[2]}-${matches[3]}`;
  }

  return '';
}

function appendMetaDataToDealers(
  disResponse: DisResponse
): DealersWithMetaData[] {
  return disResponse.dealerLocator[0].dealerLocatorDetail.map(detail => {
    const dealerId = detail.dealerParty.partyID.value;

    const meta = disResponse.dealerMetaData.find(metaData => {
      return (
        metaData.dealerMetaDataHeader.dealerParty.partyID.value === dealerId
      );
    });

    if (!meta) {
      throw new Error(`No dealerMetaData found for ${dealerId}`);
    }

    return {
      dealerId,
      details: detail,
      meta: meta.dealerMetaDataDetail[0],
    };
  });
}

export default function transformDealers(dealersResponse: DisResponse) {
  try {
    const dealers = appendMetaDataToDealers(dealersResponse);

    return dealers.map(({ dealerId, details, meta }) => {
      const {
        dealerParty: {
          relationshipTypeCode: relationship,
          specifiedOrganization: organization,
        },
        proximityMeasureGroup: proximity,
      } = details;

      const mainContact = findContactByType(
        organization.primaryContact,
        'Main Dealer'
      );

      const serviceContact = findContactByType(
        organization.primaryContact,
        'Service'
      );

      return {
        address: get(organization, 'postalAddress.lineOne.value', ''),
        brand: relationship.value.toLowerCase(),
        city: get(organization, 'postalAddress.cityName.value', ''),
        code: dealerId,
        distance: get(
          proximity,
          'proximityMeasure.value',
          ''
        ).toLocaleString('en-EN', { maximumFractionDigits: 2 }),
        hours: details.hoursOfOperation,
        isGxp: isParticipantType(meta.additionalService, 'RTI'),
        isMirai: isParticipantType(meta.additionalService, 'MiraiSales'),
        isPma: isPmaParticipant(meta.program),
        lat: get(proximity, 'geographicalCoordinate.latitudeMeasure.value'),
        long: get(proximity, 'geographicalCoordinate.longitudeMeasure.value'),
        metro: organization.divisionCode.name,
        name: get(organization, 'companyName.value', ''),
        phone: formatPhoneNumber(
          get(
            organization,
            'primaryContact[0].telephoneCommunication[0].completeNumber.value'
          )
        ),
        serviceUrl: serviceContact ? getWebsite(serviceContact) : '',
        state: get(
          organization,
          'postalAddress.stateOrProvinceCountrySubDivisionID.value',
          ''
        ),
        tda: getTdaCode(meta.organization),
        url: mainContact ? getWebsite(mainContact) : '',
        zip: get(organization, 'postalAddress.postcode.value', ''),
      };
    });
  } catch (error) {
    console.log(`Unable to transform dealers: "${error.message}"`);

    return [];
  }
}
