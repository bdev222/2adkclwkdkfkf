import React, { createContext, FC, useContext, useReducer } from 'react';

import {
  DealersActions,
  DealersDispatch,
  DealersState,
  QueryType,
} from './models';
import fetchDealers from './util/fetchDealers';
import getParams from './util/getParams';
import organizeDealers from './util/organizeDealers';
import parseQuery from './util/parseQuery';

const PAGE_SIZE = 5;

const DealersStateContext = createContext<DealersState | undefined>(undefined);
DealersStateContext.displayName = 'DealersStateContext';

const DealersDispatchContext = createContext<DealersDispatch | undefined>(
  undefined
);
DealersDispatchContext.displayName = 'DealersDispatchContext';

const initialState: DealersState = {
  allDealers: [],
  dealers: [],
  didFetchDealers: false,
  hasMore: false,
  isFetching: false,
  mode: 'expand',
  queryTerm: '',
  queryType: '',
};

function dealersReducer(
  state: DealersState,
  action: DealersActions
): DealersState {
  switch (action.type) {
    case 'enablePaginationMode': {
      const { allDealers } = state;

      return {
        ...state,
        dealers: allDealers.slice(0, PAGE_SIZE),
        mode: 'paginate',
        pagination: {
          currentPage: 1,
          totalPages: Math.ceil(allDealers.length / PAGE_SIZE),
        },
      };
    }
    case 'fetchStart': {
      return {
        ...initialState,
        isFetching: true,
        queryTerm: action.payload.query,
        queryType: action.payload.type,
      };
    }
    case 'fetchSuccess': {
      const { allDealers, pmaDealersCount } = organizeDealers(action.payload);

      const shownDealers = pmaDealersCount !== 0 ? pmaDealersCount : PAGE_SIZE;

      return {
        ...state,
        allDealers,
        dealers: allDealers.slice(0, shownDealers),
        didFetchDealers: true,
        hasMore: shownDealers < allDealers.length,
        isFetching: true,
      };
    }
    case 'fetchError': {
      return {
        ...state,
        ...initialState,
        didFetchDealers: true,
        queryTerm: state.queryTerm,
        queryType: state.queryType,
      };
    }
    case 'paginate': {
      const { dir } = action.payload;

      const { allDealers, pagination } = state;

      // Bail out early if we don't have a valid pagination action
      if (
        !pagination ||
        (dir === 'prev' && pagination.currentPage === 1) ||
        (dir === 'next' && pagination.currentPage === pagination.totalPages)
      ) {
        return state;
      }

      const newPage = pagination.currentPage + (dir === 'next' ? 1 : -1);

      const endIndex = newPage * PAGE_SIZE;

      return {
        ...state,
        dealers: allDealers.slice(endIndex - PAGE_SIZE, endIndex),
        pagination: {
          ...pagination,
          currentPage: newPage,
        },
      };
    }
    case 'showMore': {
      const { allDealers, dealers } = state;

      let newCount =
        dealers.length < PAGE_SIZE ? PAGE_SIZE : dealers.length + PAGE_SIZE;

      if (newCount > allDealers.length) {
        newCount = allDealers.length;
      }

      return {
        ...state,
        dealers: allDealers.slice(0, newCount),
        hasMore: newCount < allDealers.length,
      };
    }
    default:
      return state;
  }
}

export async function fetchDealersByQuery(
  dispatch: DealersDispatch,
  query: string,
  forceZipCodeProximity = false
) {
  const [type, params] = parseQuery(query, forceZipCodeProximity);

  dispatch({
    type: 'fetchStart',
    payload: { query, type },
  });

  const dealers = await fetchDealers(params).catch(error => {
    dispatch({ type: 'fetchError' });

    console.error(`Error fetching dealers by query "${query}":`, error);
  });

  if (dealers) {
    dispatch({ type: 'fetchSuccess', payload: dealers });
  }
}

export async function fetchDealersByZip(
  dispatch: DealersDispatch,
  zipCode: string,
  queryType: QueryType = QueryType.Pma
) {
  dispatch({
    type: 'fetchStart',
    payload: {
      query: zipCode,
      type: 'zip',
    },
  });

  const params = getParams(queryType, { zipcode: zipCode });

  const dealers = await fetchDealers(params).catch(error => {
    dispatch({ type: 'fetchError' });

    console.error(`Error fetching dealers by zip "${zipCode}":`, error);
  });

  if (dealers) {
    dispatch({ type: 'fetchSuccess', payload: dealers });

    // If we're searching by proximity instead of PMAs, we will want to directly
    // switch to pagination mode
    if (queryType === QueryType.Proximity) {
      dispatch({ type: 'enablePaginationMode' });
    }
  }
}

export function useDealersState() {
  const stateContext = useContext(DealersStateContext);

  if (stateContext === undefined) {
    throw new Error(
      'useDealersState must be used within a DealersContextProvider'
    );
  }

  return stateContext;
}

export function useDealersDispatch() {
  const dispatchContext = useContext(DealersDispatchContext);

  if (dispatchContext === undefined) {
    throw new Error(
      'useDealersDispatch must be used within a DealersContextProvider'
    );
  }

  return dispatchContext;
}

export function useDealers(): [DealersState, DealersDispatch] {
  return [useDealersState(), useDealersDispatch()];
}

const DealersContextProvider: FC = ({ children }) => {
  const [state, dispatch] = useReducer(dealersReducer, initialState);

  return (
    <DealersStateContext.Provider value={state}>
      <DealersDispatchContext.Provider value={dispatch}>
        {children}
      </DealersDispatchContext.Provider>
    </DealersStateContext.Provider>
  );
};

export default DealersContextProvider;
