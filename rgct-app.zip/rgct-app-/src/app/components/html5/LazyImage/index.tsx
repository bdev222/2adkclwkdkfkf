import React, { CSSProperties, FC, ImgHTMLAttributes } from 'react';
import { useInView } from 'react-intersection-observer';

interface LazyImageProps extends ImgHTMLAttributes<HTMLImageElement> {
  placeholderStyles?: CSSProperties;
}

const LazyImage: FC<LazyImageProps> = ({
  className,
  placeholderStyles = {},
  ...rest
}) => {
  const [ref, inView] = useInView({ triggerOnce: true });

  return inView ? (
    <img className={className} {...rest} />
  ) : (
    <div
      className={className}
      ref={ref}
      style={{
        display: 'inline-block',
        ...placeholderStyles,
      }}
    />
  );
};

export default LazyImage;
