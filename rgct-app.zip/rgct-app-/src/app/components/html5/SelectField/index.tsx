import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import { uniqueId } from 'lodash';
import React, { FC, useState } from 'react';
import { useFormContext, ValidationOptions } from 'react-hook-form';

import Field from '../Field';
import { IconRequired } from '../Icons';
import { Option } from './models';
import styles from './styles.module.scss';

interface SelectFieldProps {
  className?: string;
  label?: string;
  name: string;
  options: Option[];
  validation?: ValidationOptions;
}

const SelectField: FC<SelectFieldProps> = ({
  className,
  label,
  name,
  options,
  validation,
}) => {
  useStyles(styles);
  const { errors, register, watch } = useFormContext();

  const value = watch(name);

  const [focused, setFocused] = useState(false);

  const selectOptions = options.map(option => (
    <option key={option.value} value={option.value} aria-selected={false}>
      {option.label}
    </option>
  ));

  const labelId = uniqueId(`${name}-`);

  const error = errors[name];
  const errorMessage = !Array.isArray(error)
    ? error?.message
    : error[0].message;

  return (
    <Field hasError={!!errors[name]}>
      <div className={styles.wrap}>
        <label
          className={cc([
            styles.label,
            {
              [styles.isFocused]: focused || !!value,
              [styles.isHidden]: !label,
            },
          ])}
          htmlFor={labelId}
        >
          {label || labelId}
          {validation?.required && <IconRequired />}
        </label>

        <select
          className={cc([
            className,
            styles.select,
            { [styles.hasError]: !!errors[name] },
          ])}
          id={labelId}
          name={name}
          onBlur={() => setFocused(false)}
          onFocus={() => setFocused(true)}
          ref={validation ? register(validation) : register}
        >
          {selectOptions}
        </select>
      </div>
      {errorMessage && <span className={styles.error}>{errorMessage}</span>}
    </Field>
  );
};

export default SelectField;
