export interface Option {
  label: string;
  value: string;
}
