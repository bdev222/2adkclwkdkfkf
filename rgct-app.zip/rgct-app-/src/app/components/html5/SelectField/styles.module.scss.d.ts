export const label: string;
export const isFocused: string;
export const isHidden: string;
export const select: string;
export const hasError: string;
export const hover: string;
export const wrap: string;
export const error: string;
