import useStyles from 'isomorphic-style-loader/useStyles';
import React, { AnchorHTMLAttributes, FC, MouseEvent, useRef } from 'react';
import {
  Link as RouterLink,
  LinkProps as RouterLinkProps,
} from 'react-router-dom';

import createLinkBlock, {
  LinkBlockOptions,
} from '../../shared/Analytics/blocks/createLinkBlock';
import EventTypes from '../../shared/Analytics/EventTypes';
import useTrigger from '../../shared/Analytics/useTrigger';
import styles from './styles.module.scss';

export interface LinkProps extends AnchorHTMLAttributes<{}> {
  analytics?: Omit<LinkBlockOptions, 'href'>;
  as?: 'a' | 'link';
  to: RouterLinkProps['to'];
}

const shouldPreventLinkClick = (() => {
  if (typeof window !== 'undefined') {
    return window.location.search.includes('__dataLayerPreventClicks__');
  }

  return false;
})();

const Link: FC<LinkProps> = ({
  analytics = {},
  as = 'link',
  children,
  onClick,
  to,
  ...remainingProps
}) => {
  useStyles(styles);

  const trigger = useTrigger();

  const anchorRef = useRef<HTMLAnchorElement>(null);

  const handleLinkClick = (event: MouseEvent<HTMLAnchorElement>) => {
    if (shouldPreventLinkClick || to === '#') {
      event.preventDefault();
    }

    let linkText = analytics.text ?? '';

    if (!linkText && anchorRef.current?.textContent) {
      linkText = anchorRef.current.textContent;
    }

    trigger(
      EventTypes.Click,
      createLinkBlock({ ...analytics, href: to, text: linkText })
    );

    if (onClick) {
      onClick(event);
    }
  };

  return as === 'a' ? (
    <a
      className={styles.link}
      href={to.toString()}
      onClick={handleLinkClick}
      ref={anchorRef}
      {...remainingProps}
    >
      {children}
    </a>
  ) : (
    <RouterLink
      className={styles.link}
      innerRef={anchorRef}
      onClick={handleLinkClick}
      to={to}
      {...remainingProps}
    >
      {children}
    </RouterLink>
  );
};

export default Link;
