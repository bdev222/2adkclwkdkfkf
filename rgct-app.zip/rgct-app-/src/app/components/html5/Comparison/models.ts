import { Vehicle as CtaVehicle } from '../Cta/models';

export interface CompetitorVehicle {
  makeModelTrim: string;
  src: string;
}

export interface Comparison {
  competitor: string;
  toyota: string;
}

export interface CompareDetail {
  compareFeatures: Comparison[];
  competitorVehicle: CompetitorVehicle;
  title: string;
  toyotaVehicle: CtaVehicle;
}
