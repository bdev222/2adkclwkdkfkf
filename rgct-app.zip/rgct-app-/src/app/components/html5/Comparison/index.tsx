import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useState } from 'react';
import { useTranslation } from 'react-i18next';

import { OutgoingCta } from '../../../../functions/layout/transforms/customLandingPage/models';
import createSectionBlock from '../../../components/shared/Analytics/blocks/createSectionBlock';
import createSeriesBlock from '../../../components/shared/Analytics/blocks/createSeriesBlock';
import { Location } from '../../../util/campaignCodes';
import AnalyticsComponent from '../../shared/Analytics/AnalyticsComponent';
import Cta from '../Cta';
import Details from './Details';
import Images from './Images';
import { CompareDetail } from './models';
import Nav from './Nav';
import SeriesNames from './SeriesNames';
import styles from './styles.module.scss';

interface ComparisonProps {
  headline: string;
  comparisons: CompareDetail[];
  ctas: OutgoingCta[];
  sectionBlockName: string;
}

const Comparison: FC<ComparisonProps> = ({
  comparisons,
  ctas,
  headline,
  sectionBlockName,
}) => {
  useStyles(styles);

  const { t } = useTranslation('ctas');

  const [activeIndex, setActiveIndex] = useState(0);

  const { image: toyotaImage, seriesName, trimLabel, year } = comparisons[
    activeIndex
  ].toyotaVehicle;

  const { makeModelTrim, src: competitorImage } = comparisons[
    activeIndex
  ].competitorVehicle;

  const makeModelToyota = t('common:vehicleTitleYmstToyota', {
    make: 'Toyota',
    series: seriesName,
    trim: trimLabel,
    year,
  });

  return (
    <AnalyticsComponent
      blocks={[
        createSectionBlock(sectionBlockName),
        createSeriesBlock(comparisons[0].toyotaVehicle),
      ]}
    >
      <section className={styles.container}>
        <h2
          className={styles.heading}
          dangerouslySetInnerHTML={{ __html: headline }}
        />
        <Nav
          activeIndex={activeIndex}
          comparisons={comparisons}
          onComparisonChange={setActiveIndex}
        />
        <div className={styles.compareContentContainer}>
          <Images
            competitorImage={{ alt: makeModelTrim, src: competitorImage }}
            toyotaImage={{
              alt: `${seriesName}-${trimLabel}`,
              src: toyotaImage,
            }}
          />
          <SeriesNames
            competitorName={makeModelTrim}
            toyotaName={makeModelToyota}
          />
          <Details comparisons={comparisons[activeIndex].compareFeatures} />
        </div>
        <footer className={styles.ctaContainer}>
          {ctas.map(({ id, isPrimary }) => {
            const ctaText = t(id, {
              context: 'series',
              seriesName,
              trimLabel,
            });

            return (
              <Cta
                analytics={{
                  text: ctaText,
                  typeTitle: comparisons[activeIndex].title,
                }}
                key={id}
                className={cc([
                  styles.compareCta,
                  {
                    [styles.ctaPrimary]: isPrimary,
                    [styles.ctaSecondary]: !isPrimary,
                  },
                ])}
                id={id}
                location={Location.ModalOther}
                name={t(id)}
                vehicle={comparisons[activeIndex].toyotaVehicle}
              >
                <span>{ctaText}</span>
              </Cta>
            );
          })}
        </footer>
      </section>
    </AnalyticsComponent>
  );
};

export default Comparison;
