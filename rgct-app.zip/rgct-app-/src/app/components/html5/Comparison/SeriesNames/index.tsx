import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import styles from './styles.module.scss';

interface SeriesNames {
  competitorName: string;
  toyotaName: string;
}

const SeriesNames: FC<SeriesNames> = ({ competitorName, toyotaName }) => {
  useStyles(styles);

  return (
    <div className={styles.container}>
      <div className={cc([styles.headline, styles.headlineToyota])}>
        <span dangerouslySetInnerHTML={{ __html: toyotaName }} />
      </div>
      <div className={cc([styles.headline, styles.headlineCompetitor])}>
        <span dangerouslySetInnerHTML={{ __html: competitorName }} />
      </div>
    </div>
  );
};

export default SeriesNames;
