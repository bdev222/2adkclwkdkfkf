export const container: string;
export const headline: string;
export const headlineToyota: string;
export const headlineCompetitor: string;
