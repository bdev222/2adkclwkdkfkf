import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, KeyboardEvent } from 'react';

import createLinkBlock from '../../../shared/Analytics/blocks/createLinkBlock';
import createListItemBlock from '../../../shared/Analytics/blocks/createListItemBlock';
import EventTypes from '../../../shared/Analytics/EventTypes';
import useTrigger from '../../../shared/Analytics/useTrigger';
import { CompareDetail } from '../models';
import styles from './styles.module.scss';

interface NavProps {
  activeIndex: number;
  comparisons: CompareDetail[];
  onComparisonChange: (index: number) => void;
}

const Nav: FC<NavProps> = ({
  activeIndex,
  comparisons,
  onComparisonChange,
}) => {
  useStyles(styles);

  const trigger = useTrigger();

  const handleKeyDown = (event: KeyboardEvent, index: number) => {
    if (event.key === 'Enter') {
      handleComparisonChange(index);
    }
  };

  const handleComparisonChange = (index: number) => {
    trigger(EventTypes.Click, [
      createLinkBlock({ text: comparisons[index].title }),
      createListItemBlock(index + 1),
    ]);

    onComparisonChange(index);
  };

  return (
    <nav className={styles.scrollContainer}>
      <ul className={styles.container}>
        {comparisons.map(({ title }, index) => (
          <li
            className={styles.headingContainer}
            key={`${title}-${activeIndex}-${index}`}
            onClick={() => handleComparisonChange(index)}
            role="button"
            onKeyDown={event => handleKeyDown(event, index)}
          >
            <div
              className={cc([
                styles.heading,
                { [styles.isActive]: index === activeIndex },
              ])}
              dangerouslySetInnerHTML={{ __html: title }}
              tabIndex={0}
            />
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default Nav;
