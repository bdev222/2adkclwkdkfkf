export const scrollContainer: string;
export const container: string;
export const headingContainer: string;
export const heading: string;
export const isActive: string;
