export const container: string;
export const compareContent: string;
export const jelly: string;
export const jellyInner: string;
export const jellyImg: string;
export const vs: string;
