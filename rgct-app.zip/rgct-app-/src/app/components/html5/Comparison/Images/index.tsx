import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import styles from './styles.module.scss';

interface Image {
  alt: string;
  src: string;
}

interface ImageProps {
  competitorImage: Image;
  toyotaImage: Image;
}

const Images: FC<ImageProps> = ({ competitorImage, toyotaImage }) => {
  useStyles(styles);

  return (
    <div className={styles.container}>
      <div className={styles.compareContent}>
        <div className={styles.jelly}>
          <div className={styles.jellyInner}>
            <img
              alt={toyotaImage.alt}
              className={styles.jellyImg}
              src={toyotaImage.src}
            />
          </div>
        </div>
      </div>
      <div className={styles.vs} />
      <div className={styles.compareContent}>
        <div className={styles.jelly}>
          <div className={styles.jellyInner}>
            <img
              alt={competitorImage.alt}
              className={styles.jellyImg}
              src={competitorImage.src}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Images;
