export const container: string;
export const compareCta: string;
export const ctaSecondary: string;
export const ctaPrimary: string;
export const heading: string;
export const compareContentContainer: string;
export const ctaContainer: string;
