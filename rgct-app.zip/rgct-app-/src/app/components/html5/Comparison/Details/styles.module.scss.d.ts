export const container: string;
export const bullet: string;
export const bulletDetailContainer: string;
export const toyotaBullets: string;
export const competitorBullets: string;
export const bulletIcon: string;
export const toyotaIcon: string;
export const competitorIcon: string;
