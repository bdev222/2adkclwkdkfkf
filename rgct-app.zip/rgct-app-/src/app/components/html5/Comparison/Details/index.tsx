import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import { IconBulletCheckMark, IconBulletX } from '../../Icons/index';
import { Comparison } from '../models';
import styles from './styles.module.scss';

interface DetailsProps {
  comparisons: Comparison[];
}

const Details: FC<DetailsProps> = ({ comparisons }) => {
  useStyles(styles);

  return (
    <ul className={styles.container}>
      {comparisons.map((feature, index) => (
        <li className={styles.bullet} key={`${feature.toyota}-${index}`}>
          <span
            className={cc([styles.bulletDetailContainer, styles.toyotaBullets])}
          >
            <IconBulletCheckMark
              className={cc([styles.bulletIcon, styles.toyotaIcon])}
            />
            <span dangerouslySetInnerHTML={{ __html: feature.toyota }} />
          </span>
          <span
            className={cc([
              styles.bulletDetailContainer,
              styles.competitorBullets,
            ])}
          >
            <IconBulletX
              className={cc([styles.bulletIcon, styles.competitorIcon])}
            />
            <span
              dangerouslySetInnerHTML={{
                __html: feature.competitor,
              }}
            />
          </span>
        </li>
      ))}
    </ul>
  );
};

export default Details;
