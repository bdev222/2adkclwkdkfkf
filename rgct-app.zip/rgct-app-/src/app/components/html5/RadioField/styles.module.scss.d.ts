export const radioItem: string;
export const radio: string;
export const input: string;
export const label: string;
export const labelText: string;
