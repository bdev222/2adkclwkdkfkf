import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, InputHTMLAttributes } from 'react';
import { useFormContext } from 'react-hook-form';

import Field from '../Field';
import styles from './styles.module.scss';

interface RadioFieldProps extends InputHTMLAttributes<HTMLInputElement> {
  value: string;
}

const RadioField: FC<RadioFieldProps> = ({
  checked,
  children,
  name,
  value,
  ...inputProps
}) => {
  useStyles(styles);

  const { getValues, register } = useFormContext();

  const isChecked = checked
    ? checked
    : name !== undefined
    ? getValues()[name] === value
    : undefined;

  return (
    <Field>
      <div className={styles.radioItem}>
        <label className={styles.label}>
          <span>
            <input
              aria-checked={isChecked}
              checked={isChecked}
              className={styles.input}
              name={name}
              ref={register}
              type="radio"
              value={value}
              {...inputProps}
            />
            <span className={styles.radio} />
          </span>
          <span className={styles.labelText}>{children}</span>
        </label>
      </div>
    </Field>
  );
};

export default RadioField;
