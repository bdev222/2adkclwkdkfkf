import useStyles from 'isomorphic-style-loader/useStyles';
import React from 'react';
import { useTranslation } from 'react-i18next';

import useNativeShare from '../../../util/useNativeShare';
import AnalyticsButton from '../../shared/Analytics/AnalyticsButton';
import { IconShare } from '../Icons';
import styles from './styles.module.scss';

const ShareButton = () => {
  useStyles(styles);

  const { t } = useTranslation();

  const { canShare, handleShare } = useNativeShare();

  const text = t('shareThisOffer');

  return canShare ? (
    <AnalyticsButton
      analytics={{ text }}
      className={styles.shareButton}
      onClick={handleShare}
    >
      <IconShare />
      {text}
    </AnalyticsButton>
  ) : null;
};

export default ShareButton;
