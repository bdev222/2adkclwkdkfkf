export const shareButton: string;
