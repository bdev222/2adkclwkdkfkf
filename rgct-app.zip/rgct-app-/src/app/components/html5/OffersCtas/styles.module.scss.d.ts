export const cta: string;
export const container: string;
export const ctas: string;
export const desktop: string;
export const maxCtas: string;
export const mobile: string;
