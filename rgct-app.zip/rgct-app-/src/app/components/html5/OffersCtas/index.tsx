import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import { Devices } from '../../../models';
import { Location } from '../../../util/campaignCodes';
import useDealerInventoryCtaExperience from '../../../util/useDealerInventoryCtaExperience';
import AnalyticsContext from '../../shared/Analytics/AnalyticsContext';
import createSectionBlock from '../../shared/Analytics/blocks/createSectionBlock';
import createSeriesBlock from '../../shared/Analytics/blocks/createSeriesBlock';
import Cta from '../Cta';
import { BackgroundImages, Vehicle } from '../Cta/models';
import styles from './styles.module.scss';

const MAX_CTAS = 4;

interface Cta {
  id: string;
  name: string;
}

interface OffersCtasProps {
  backgroundImages?: BackgroundImages;
  ctas: Record<'desktop' | 'mobile', Cta[]>;
  location: Location;
  vehicle?: Vehicle;
}

const OffersCtas: FC<OffersCtasProps> = ({
  backgroundImages,
  ctas,
  location,
  vehicle,
}) => {
  useStyles(styles);

  const { t } = useTranslation('ctas');

  const experience = useDealerInventoryCtaExperience();
  const isInventoryCtaTest = experience === 'experienceB';

  // Temporary removal of PE CTA for Mirai
  const isMirai = vehicle && vehicle.seriesId === 'mirai';

  return (
    <AnalyticsContext
      blocks={[
        createSectionBlock('offers_next_step'),
        vehicle ? createSeriesBlock(vehicle) : {},
      ]}
    >
      <div className={styles.container}>
        {[Devices.Desktop, Devices.Mobile].map(device => (
          <div
            className={cc([
              styles.ctas,
              styles[device],
              { [styles.maxCtas]: ctas[device].length === MAX_CTAS },
            ])}
            key={device}
          >
            {ctas[device].map((deviceCta, index) => {
              const ctaId =
                isInventoryCtaTest && deviceCta.id === 'view-inventory'
                  ? 'view-dealer-inventory'
                  : deviceCta.id;

              const ctaLabel = t(ctaId);
              const shouldShowCta = !(isMirai && ctaId === 'estimate-payment');

              return shouldShowCta ? (
                <Cta
                  backgroundImages={backgroundImages}
                  className={styles.cta}
                  id={ctaId}
                  location={location}
                  key={`${ctaId}-${index}`}
                  name={ctaLabel}
                  vehicle={vehicle}
                >
                  <span>{ctaLabel}</span>
                </Cta>
              ) : null;
            })}
          </div>
        ))}
      </div>
    </AnalyticsContext>
  );
};
export default OffersCtas;
