import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import { clamp } from 'lodash';
import React, {
  FC,
  ReactNode,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { useDrag } from 'react-use-gesture';

import useSlider from '../../../util/useSlider';
import SliderControlDots from './SliderControlDots';
import SliderControlIcon from './SliderControlIcon';
import styles from './styles.module.scss';

interface CarouselProps {
  ariaControls: string;
  ariaLabels?: { next: string; prev: string };
  classNames?: {
    nextClass?: string;
    previousClass?: string;
    slidesClass?: string;
  };
  initialSlide?: number;
  onCarouselDotClick?: (index: number) => void;
  onCarouselIconClick?: (
    dir: 'prev' | 'next',
    targetSlideIndex: number
  ) => void;
  onSlideChange?: (index: number) => void;
  renderFooter?: ReactNode;
  renderSlide: (slide: any, index: number, activeSlide: number) => ReactNode;
  shouldLoop?: boolean;
  showSliderDots?: boolean;
  slides: any[];
}

const Carousel: FC<CarouselProps> = ({
  ariaControls,
  ariaLabels,
  classNames,
  initialSlide = 0,
  onCarouselDotClick,
  onCarouselIconClick,
  onSlideChange,
  renderFooter = null,
  renderSlide,
  shouldLoop = true,
  showSliderDots = true,
  slides,
}) => {
  useStyles(styles);

  // If shouldLoop, transformSlides = [lastSlide, ...slides, firstSlide]
  const formattedSlides = useMemo(
    () =>
      slides.length > 1 && shouldLoop
        ? [slides[slides.length - 1], ...slides, slides[0]]
        : slides,
    [slides]
  );

  const containerRef = useRef<HTMLDivElement | null>(null);

  const {
    activeSlide,
    containerWidth,
    didMount,
    goNext,
    goPrev,
    goToSlide,
    slider,
  } = useSlider(formattedSlides, {
    containerRef,
    getWidth: windowWidth => windowWidth,
    initialSlide: shouldLoop ? initialSlide + 1 : initialSlide,
    shouldLoop,
  });

  const [offset, setOffset] = useState(0);

  const [isLooping, setIsLooping] = useState(false);

  let actualActiveSlideIndex = activeSlide;

  if (shouldLoop) {
    actualActiveSlideIndex = clamp(activeSlide - 1, 0, slides.length - 1);
  }

  useEffect(() => {
    if (onSlideChange) {
      onSlideChange(actualActiveSlideIndex);
    }
  }, [activeSlide]);

  useEffect(() => {
    setIsLooping(false);
  }, [isLooping]);

  const dragProps = useDrag(({ down, movement: [deltaX], last }) => {
    if (containerWidth >= 768) {
      return;
    }

    // Dragging
    if (down && slider.offset !== null) {
      setOffset(slider.offset + deltaX);
    }

    // Drag end
    if (last) {
      if (deltaX < -20 && (shouldLoop || activeSlide !== slider.lastSlide)) {
        goNext();
      } else if (deltaX > 20 && (shouldLoop || activeSlide !== 0)) {
        goPrev();
      }
      setOffset(0);
    }
  });

  const handleCarouselIconClick = (dir: 'next' | 'prev') => {
    let targetSlideIndex =
      dir === 'next' ? actualActiveSlideIndex + 1 : actualActiveSlideIndex - 1;

    if (dir === 'next' && actualActiveSlideIndex === slides.length - 1) {
      targetSlideIndex = 0;
    }

    if (dir === 'prev' && actualActiveSlideIndex === 0) {
      targetSlideIndex = slides.length - 1;
    }

    if (onCarouselIconClick) {
      onCarouselIconClick(dir, targetSlideIndex);
    }

    dir === 'next' ? goNext() : goPrev();
  };

  const handleCarouselDotClick = (index: number) => {
    if (onCarouselDotClick) {
      onCarouselDotClick(index);
    }
    goToSlide(shouldLoop ? index + 1 : index);
  };

  const handleTransitionEnd = () => {
    if (!shouldLoop) {
      return;
    }

    if (activeSlide === 0) {
      setIsLooping(true);
      goToSlide(slides.length);
    } else if (activeSlide === formattedSlides.length - 1) {
      setIsLooping(true);
      goToSlide(1);
    }
  };

  return (
    <section className={cc([styles.slider, { [styles.didMount]: didMount }])}>
      <div className={styles.controlsAndSlidesContainer}>
        {slides.length > 1 &&
          ['prev', 'next'].map(dir => {
            const iconClass =
              dir === 'prev'
                ? classNames?.previousClass
                : classNames?.nextClass;

            const ariaLabel = ariaLabels
              ? dir === 'prev'
                ? ariaLabels.prev
                : ariaLabels.next
              : undefined;

            return (
              <SliderControlIcon
                key={dir}
                ariaControls={ariaControls}
                activeSlide={activeSlide}
                className={cc([
                  iconClass,
                  {
                    [styles.prev]: dir === 'prev',
                    [styles.next]: dir === 'next',
                    [styles.hide]:
                      shouldLoop === false
                        ? activeSlide === 0 && dir === 'prev'
                        : activeSlide === slides.length - 1 && dir === 'next',
                  },
                ])}
                ariaLabel={ariaLabel}
                dir={dir}
                onControlClick={handleCarouselIconClick}
              />
            );
          })}
        <div
          className={cc([classNames?.slidesClass, styles.slidesContainer])}
          ref={containerRef}
        >
          <ul
            {...dragProps()}
            className={cc([
              styles.slides,
              { [styles.isDragging]: offset, [styles.isLooping]: isLooping },
            ])}
            style={{
              transform: `translateX(${offset ? offset : slider.offset}px)`,
              width: `${slider.maxWidth * formattedSlides.length}px`,
            }}
            onTransitionEnd={handleTransitionEnd}
          >
            {formattedSlides.map((slide, index) =>
              renderSlide(slide, index, activeSlide)
            )}
          </ul>
        </div>
      </div>

      <footer>
        {slides.length > 1 && showSliderDots && (
          <SliderControlDots
            activeSlide={actualActiveSlideIndex}
            onDotClick={handleCarouselDotClick}
            slides={slides}
          />
        )}
        {renderFooter}
      </footer>
    </section>
  );
};

export default Carousel;
