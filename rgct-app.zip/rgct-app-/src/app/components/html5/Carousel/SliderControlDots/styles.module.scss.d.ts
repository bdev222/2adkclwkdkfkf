export const container: string;
export const isActive: string;
