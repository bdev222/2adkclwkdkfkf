import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import createLinkBlock from '../../../shared/Analytics/blocks/createLinkBlock';
import createListItemBlock from '../../../shared/Analytics/blocks/createListItemBlock';
import EventTypes from '../../../shared/Analytics/EventTypes';
import useTrigger from '../../../shared/Analytics/useTrigger';
import styles from './styles.module.scss';

interface SliderControlDotsProps {
  activeSlide: number;
  onDotClick: (slideIndex: number) => void;
  slides: unknown[];
}

const SliderControlDots: FC<SliderControlDotsProps> = ({
  activeSlide,
  onDotClick,
  slides,
}) => {
  useStyles(styles);
  const trigger = useTrigger();

  function handleClick(index: number) {
    trigger(EventTypes.Click, [
      createLinkBlock({ text: 'pagination' }),
      createListItemBlock(index + 1),
    ]);
    onDotClick(index);
  }

  return (
    <ul className={styles.container}>
      {slides.map((slide, index) => (
        <li key={index}>
          <button
            onClick={() => handleClick(index)}
            className={cc({ [styles.isActive]: activeSlide === index })}
          >
            <span>{index}</span>
          </button>
        </li>
      ))}
    </ul>
  );
};

export default SliderControlDots;
