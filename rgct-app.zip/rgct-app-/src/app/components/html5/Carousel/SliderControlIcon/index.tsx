import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import createLinkBlock from '../../../shared/Analytics/blocks/createLinkBlock';
import createListItemBlock from '../../../shared/Analytics/blocks/createListItemBlock';
import EventTypes from '../../../shared/Analytics/EventTypes';
import useTrigger from '../../../shared/Analytics/useTrigger';
import { IconArrow } from '../../Icons';
import styles from './styles.module.scss';

interface SliderControlIconProps {
  ariaControls: string;
  activeSlide: number;
  className?: string;
  ariaLabel?: string;
  dir: string;
  onControlClick: (dir: string) => void;
}

const SliderControlIcon: FC<SliderControlIconProps> = ({
  ariaControls,
  activeSlide,
  className,
  ariaLabel,
  dir,
  onControlClick,
}) => {
  useStyles(styles);

  const trigger = useTrigger();

  const { t } = useTranslation('icons');

  function handleButtonClick() {
    const linkText = dir === 'prev' ? 'left_arrow' : 'right_arrow';
    trigger(EventTypes.Click, [
      createLinkBlock({ text: linkText }),
      createListItemBlock(activeSlide + 1),
    ]);
    onControlClick(dir);
  }

  return (
    <button
      aria-controls={ariaControls}
      aria-label={`${t('arrow')} - ${ariaLabel}`}
      className={cc([
        styles.controlButton,
        className,
        {
          [styles.prev]: dir === 'prev',
        },
      ])}
      onClick={handleButtonClick}
      title={`${t('arrow')} - ${ariaLabel}`}
    >
      <IconArrow />
    </button>
  );
};

export default SliderControlIcon;
