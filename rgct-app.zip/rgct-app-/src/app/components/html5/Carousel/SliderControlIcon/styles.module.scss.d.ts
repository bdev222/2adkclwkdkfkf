export const controlButton: string;
export const prev: string;
