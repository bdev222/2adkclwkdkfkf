import {
  Offer as OfferProps,
  OfferBase,
} from '../../../../functions/layout/transforms/util/getOffers/models';

export type Offer = OfferBase & Pick<OfferProps, 'bonus'>;
