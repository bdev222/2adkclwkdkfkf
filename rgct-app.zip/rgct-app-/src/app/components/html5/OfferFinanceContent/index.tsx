import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import BonusDetails from '../OfferBonusDetails';
import { Offer } from './models';
import styles from './styles.module.scss';

interface OfferFinanceContentProps {
  offer: Offer;
}

const OfferFinanceContent: FC<OfferFinanceContentProps> = ({ offer }) => {
  useStyles(styles);

  const { t } = useTranslation();

  return (
    <div className={styles.container}>
      {(() => {
        switch (offer.type) {
          case 'apr':
            return (
              <ul>
                <li>
                  {offer.apr.rate}%<span>{t('aprAbbr')}.</span>
                </li>
                <li>
                  {offer.apr.duration}
                  <span>{t('monthsAbbr')}</span>
                </li>
              </ul>
            );
          case 'cash':
            return (
              <ul>
                <li>
                  ${parseInt(offer.cash.cashAmount, 10).toLocaleString()}
                  <span>{offer.cash.label}</span>
                </li>
              </ul>
            );
          case 'lease':
            return (
              <ul>
                <li>
                  ${parseInt(offer.lease.monthlyPayment, 10).toLocaleString()}
                  <span>/ {t('monthAbbr')}</span>
                </li>
                <li>
                  {offer.lease.duration}
                  <span>{t('monthsAbbr')}</span>
                </li>
                <li>
                  ${parseInt(offer.lease.dueAtSigning, 10).toLocaleString()}
                  <span>{t('dueAtSigning')}</span>
                </li>
              </ul>
            );
          default:
            return null;
        }
      })()}
      {offer.bonus && <BonusDetails bonus={offer.bonus} />}
    </div>
  );
};

export default OfferFinanceContent;
