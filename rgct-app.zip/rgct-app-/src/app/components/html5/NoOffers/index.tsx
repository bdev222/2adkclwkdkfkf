import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import Cta from '../../../components/html5/Cta';
import {
  BackgroundImages,
  Vehicle,
} from '../../../components/html5/Cta/models';
import AnalyticsContext from '../../../components/shared/Analytics/AnalyticsContext';
import createPaymentEstimatorBlock from '../../../components/shared/Analytics/blocks/createPaymentEstimatorBlock';
import createSectionBlock from '../../../components/shared/Analytics/blocks/createSectionBlock';
import { Location } from '../../../util/campaignCodes';
import Estimate from './Estimate';
import { Estimates } from './models';
import styles from './styles.module.scss';

interface NoOffersProps {
  backgroundImages?: BackgroundImages;
  estimates: Estimates;
  seriesName: string;
  vehicle: Vehicle;
}

const NoOffers: FC<NoOffersProps> = ({
  backgroundImages,
  estimates,
  seriesName,
  vehicle,
}) => {
  useStyles(styles);

  const { t } = useTranslation();

  const ctaLabel = t('contactDealer');

  return (
    <AnalyticsContext blocks={[createSectionBlock('offers_pe')]}>
      <div className={styles.wrapper}>
        <div className={styles.contactDealer}>
          <Cta
            id="contact-dealer"
            location={Location.ModalAllOffers}
            backgroundImages={backgroundImages}
            name={ctaLabel}
            vehicle={vehicle}
          >
            <span>{ctaLabel}</span>
          </Cta>
          <p>{t('contactDealerForOffers')}</p>
        </div>
        <h4 className={styles.heading}>
          {t('currentEstimates', { seriesName })}
        </h4>
        <div className={styles.estimatesContainer}>
          <AnalyticsContext
            blocks={createPaymentEstimatorBlock(
              { buyOrLease: 'Lease' },
              vehicle
            )}
          >
            <Estimate
              amount={estimates.lease.amount}
              className={styles.leaseEstimate}
              estimatorUrl={estimates.lease.estimatorUrl}
              seriesName={seriesName}
              type="lease"
            />
          </AnalyticsContext>
          <AnalyticsContext
            blocks={createPaymentEstimatorBlock({ buyOrLease: 'Buy' }, vehicle)}
          >
            <Estimate
              amount={estimates.finance.amount}
              className={styles.financeEstimate}
              estimatorUrl={estimates.finance.estimatorUrl}
              seriesName={seriesName}
              type="finance"
            />
          </AnalyticsContext>
        </div>
      </div>
    </AnalyticsContext>
  );
};
export default NoOffers;
