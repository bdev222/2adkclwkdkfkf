export const contactDealer: string;
export const leaseEstimate: string;
export const financeEstimate: string;
export const heading: string;
export const wrapper: string;
export const estimatesContainer: string;
