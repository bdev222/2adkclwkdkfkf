export const copy: string;
export const amount: string;
