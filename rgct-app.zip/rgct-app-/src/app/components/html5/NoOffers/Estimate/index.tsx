import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import Link from '../../Link';
import styles from './styles.module.scss';

interface EstimateProps {
  amount: number;
  className?: string;
  estimatorUrl: string;
  seriesName: string;
  type: 'lease' | 'finance';
}

const Estimate: FC<EstimateProps> = ({
  amount,
  className,
  estimatorUrl,
  seriesName,
  type,
}) => {
  useStyles(styles);

  const { t } = useTranslation();

  const typeText = t(type);

  const title = `${t('estimateDetailsTitle', {
    series: seriesName,
    type: typeText,
  })} ${t('newWindow')}`;

  return amount > 0 ? (
    <div className={className} data-type={type}>
      <p
        className={styles.copy}
        dangerouslySetInnerHTML={{
          __html: t('estimateCopy', {
            series: seriesName,
            type: typeText,
          }),
        }}
      />
      <p className={styles.amount}>
        <strong>${amount.toLocaleString()}</strong>
        <span> / {t('month')}</span>
      </p>
      <Link
        aria-label={title}
        as="a"
        target="_blank"
        title={title}
        to={estimatorUrl}
      >
        {t('estimateDetails')}
      </Link>
    </div>
  ) : null;
};

export default Estimate;
