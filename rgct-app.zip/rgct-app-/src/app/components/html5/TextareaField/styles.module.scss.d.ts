export const label: string;
export const isFocused: string;
export const textarea: string;
export const textareaWrap: string;
export const focusWrap: string;
