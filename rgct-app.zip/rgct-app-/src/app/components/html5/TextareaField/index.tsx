import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import { uniqueId } from 'lodash';
import React, { FC, useState } from 'react';
import { useFormContext, ValidationOptions } from 'react-hook-form';

import Field from '../Field';
import styles from './styles.module.scss';

interface TextareaFieldProps {
  autoFocus?: boolean;
  label?: string;
  name: string;
  validation?: ValidationOptions;
}

const TextareaField: FC<TextareaFieldProps> = ({
  autoFocus,
  label,
  name,
  validation,
}) => {
  useStyles(styles);
  const { register, errors, getValues } = useFormContext();
  const [isFocused, setIsFocused] = useState(false);
  const value = getValues()[name];

  const labelId = uniqueId(`${name}-`);

  return (
    <Field hasError={!!errors[name]}>
      <div
        className={cc([
          styles.textareaWrap,
          { [styles.focusWrap]: isFocused || (value && value.length > 0) },
        ])}
      >
        {label && (
          <label
            className={cc([
              styles.label,
              { [styles.isFocused]: isFocused || (value && value.length > 0) },
            ])}
            htmlFor={labelId}
          >
            {label}
          </label>
        )}
        <textarea
          autoFocus={autoFocus}
          className={styles.textarea}
          id={labelId}
          name={name}
          placeholder={label}
          ref={validation ? register(validation) : register}
          onBlur={() => setIsFocused(false)}
          onFocus={() => setIsFocused(true)}
        />
      </div>
    </Field>
  );
};

export default TextareaField;
