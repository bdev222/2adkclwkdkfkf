export const field: string;
export const hasError: string;
