import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import styles from './styles.module.scss';

interface FieldProps {
  hasError?: boolean;
}

const Field: FC<FieldProps> = ({ children, hasError }) => {
  useStyles(styles);

  return (
    <div className={cc([styles.field, { [styles.hasError]: hasError }])}>
      {children}
    </div>
  );
};

export default Field;
