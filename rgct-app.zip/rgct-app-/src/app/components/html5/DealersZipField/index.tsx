import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

import { useDealersState } from '../DealersContext';
import InlineZipField, { InlineZipFieldProps } from '../InlineZipField';
import styles from './styles.module.scss';

type DealersZipFieldProps = InlineZipFieldProps;

const DealersZipField: FC<DealersZipFieldProps> = inlineZipFieldProps => {
  const { onChange } = inlineZipFieldProps;

  useStyles(styles);

  const { t } = useTranslation('dealers');

  const { dealers, didFetchDealers } = useDealersState();

  const [isNoDealerLabelVisible, setIsNoDealerLabelVisible] = useState(false);

  useEffect(() => {
    if (didFetchDealers && !dealers.length) {
      setIsNoDealerLabelVisible(true);

      onChange?.(''); // NOSONAR
    }
  }, [didFetchDealers, dealers]);

  const handleBlur = (zipCode: string, prevZipCode: string) => {
    if (
      (!didFetchDealers && zipCode.length < 5) ||
      (didFetchDealers && !dealers.length)
    ) {
      onChange?.(''); // NOSONAR
    } else if (prevZipCode && zipCode !== prevZipCode) {
      onChange?.(prevZipCode); // NOSONAR
    }
  };

  const handleZipChange = (zipCode: string) => {
    setIsNoDealerLabelVisible(false);

    onChange?.(zipCode); // NOSONAR
  };

  const disclaimers = [
    ...(inlineZipFieldProps.disclaimers ? inlineZipFieldProps.disclaimers : []),
    ...(isNoDealerLabelVisible ? [t('invalidZip')] : []),
  ];

  return (
    <InlineZipField
      {...inlineZipFieldProps}
      disclaimers={disclaimers}
      onBlur={handleBlur}
      onChange={handleZipChange}
    />
  );
};

export default DealersZipField;
