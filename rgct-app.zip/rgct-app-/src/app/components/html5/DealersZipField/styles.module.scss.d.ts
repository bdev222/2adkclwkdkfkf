export const unservicableZipCodeLabel: string;
