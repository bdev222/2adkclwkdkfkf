import {
  Offer as OfferProps,
  OfferBase,
} from '../../../../functions/layout/transforms/util/getOffers/models';

export { OfferType } from '../../../../functions/layout/transforms/util/getOffers/models';

type OfferBannerProps =
  | 'bonus'
  | 'disclaimers'
  | 'endDate'
  | 'id'
  | 'offerDetailTitle'
  | 'primaryLabel'
  | 'series'
  | 'seriesOrCardTitle'
  | 'trimLabel';

export type Offer = OfferBase & Pick<OfferProps, OfferBannerProps>;
