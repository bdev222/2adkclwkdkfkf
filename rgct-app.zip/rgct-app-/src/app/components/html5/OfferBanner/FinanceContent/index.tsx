import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import OfferBonusDetails from '../../OfferBonusDetails';
import { Offer, OfferType } from '../models';
import styles from './styles.module.scss';

interface FinanceContentProps {
  offer: Offer;
  offerDetailTitle?: string;
}

const FinanceContent: FC<FinanceContentProps> = ({
  offer,
  offerDetailTitle,
}) => {
  useStyles(styles);

  const { t } = useTranslation();

  return (
    <div className={styles.container}>
      {(() => {
        switch (offer.type) {
          case 'apr':
            return (
              <ul>
                <li>
                  {offer.apr.rate}%<span>{t('aprAbbr')}.</span>
                </li>
                <li>
                  {offer.apr.duration}
                  <span>{t('monthsAbbr')}</span>
                </li>
              </ul>
            );
          case 'cash':
            return (
              <ul>
                <li>
                  ${parseInt(offer.cash.cashAmount, 10).toLocaleString()}
                  <span>{offer.cash.label}</span>
                </li>
              </ul>
            );
          case 'lease':
            return (
              <ul>
                <li>
                  ${parseInt(offer.lease.monthlyPayment, 10).toLocaleString()}
                  <span>/ {t('monthAbbr')}</span>
                </li>
                <li>
                  {offer.lease.duration}
                  <span>{t('monthsAbbr')}</span>
                </li>
                <li>
                  ${parseInt(offer.lease.dueAtSigning, 10).toLocaleString()}
                  <span>{t('dueAtSigning')}</span>
                </li>
              </ul>
            );
          case 'multiVehicle':
            return (
              <ul>
                <li>
                  $
                  {parseInt(offer.multiVehicle.cashAmount, 10).toLocaleString()}
                  <span>{offer.multiVehicle.label}</span>
                </li>
              </ul>
            );
          default:
            return null;
        }
      })()}
      {offer.bonus &&
        ![OfferType.MultiVehicle, OfferType.Misc].includes(offer.type) && (
          <OfferBonusDetails
            bonus={offer.bonus}
            bonusCopyOverride={offerDetailTitle}
          />
        )}
    </div>
  );
};

export default FinanceContent;
