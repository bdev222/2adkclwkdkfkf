import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, ReactNode } from 'react';
import { useTranslation } from 'react-i18next';

import GxpInlineSave from '../GxpInlineSave';
import BonusDetails from '../OfferBonusDetails';
import ShareButton from '../ShareButton';
import FinanceContent from './FinanceContent';
import { Offer, OfferType } from './models';
import styles from './styles.module.scss';

interface OfferBannerProps {
  ctaComponent: ReactNode;
  offer: Offer;
  showShareButton?: boolean;
}

const OfferBanner: FC<OfferBannerProps> = ({
  ctaComponent,
  offer,
  showShareButton = false,
}) => {
  const {
    bonus,
    endDate,
    offerDetailTitle,
    primaryLabel,
    seriesOrCardTitle,
    trimLabel,
    type,
  } = offer;

  useStyles(styles);

  const { t } = useTranslation('offer');

  return (
    <div className={styles.container}>
      <div className={styles.headings}>
        <div className={styles.offerType} data-type={type}>
          {primaryLabel}
        </div>
        <div className={styles.heading}>
          <h1 className={styles.headingTitle}>{seriesOrCardTitle}</h1>
          {trimLabel && <p className={styles.headingSubTitle}>{trimLabel}</p>}
        </div>
        {bonus &&
          ![OfferType.MultiVehicle, OfferType.Misc].includes(offer.type) && (
            <div className={styles.headingBonusCopy}>
              <BonusDetails
                bonus={bonus}
                bonusCopyOverride={offerDetailTitle}
              />
            </div>
          )}
      </div>
      <FinanceContent offer={offer} offerDetailTitle={offerDetailTitle} />
      <div className={styles.actions}>
        {ctaComponent}
        <p className={styles.expiration}>{t('expiration', endDate)}</p>
        {showShareButton && (
          <div className={styles.shareButton}>
            <ShareButton />
          </div>
        )}
      </div>
      <GxpInlineSave className={styles.gxpInlineSave} offer={offer} />
    </div>
  );
};

export default OfferBanner;
