import { MutableRefObject } from 'react';

import { Dealer } from '../DealersContext/models';

export type ErrorMessage = string | undefined;

export type SetErrorMessage = (message?: string) => void;

export type OnDealerClick = (dealer?: Dealer) => void;

export type OnDealerHover = (dealer?: Dealer) => void;

export type OnDealersFetch = (
  dealers: Dealer[],
  queryTerm: string,
  queryType: string
) => void;

export type SetListView = () => void;

export type MarkersRef = MutableRefObject<Map<string, MarkerRef>>;

interface MarkerRef {
  marker: google.maps.Marker;
  text: string;
}
