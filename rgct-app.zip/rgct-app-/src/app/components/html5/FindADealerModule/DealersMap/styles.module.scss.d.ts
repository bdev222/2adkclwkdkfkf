export const map: string;
