import { GoogleMap, Marker, useLoadScript } from '@react-google-maps/api';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useEffect, useRef } from 'react';

import usePrevious from '../../../../util/usePrevious';
import { useDealersState } from '../../DealersContext';
import { Dealer } from '../../DealersContext/models';
import {
  MarkersRef,
  OnDealerClick,
  OnDealerHover,
  SetListView,
} from '../models';
import setMarkerIcon from '../util/createMarkerIcon';
import styles from './styles.module.scss';

interface DealersMapProps {
  hoveredDealer?: Dealer;
  onDealerClick: OnDealerClick;
  onDealerHover: OnDealerHover;
  selectedDealer?: Dealer;
  setListView: SetListView;
  view: string;
}

const DealersMap: FC<DealersMapProps> = ({
  hoveredDealer,
  onDealerClick,
  onDealerHover,
  selectedDealer,
  setListView,
  view,
}) => {
  useStyles(styles);

  const mapRef = useRef<google.maps.Map>();

  const markersRef: MarkersRef = useRef(new Map());

  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: process.env.GOOGLE_MAPS_API_KEY,
  });

  const { dealers, didFetchDealers, isFetching } = useDealersState();

  const prevActiveDealer = usePrevious(selectedDealer);
  const prevHoveredDealer = usePrevious(hoveredDealer);

  useEffect(() => {
    if (isFetching && !didFetchDealers) {
      markersRef.current = new Map();
    }

    if (didFetchDealers && dealers.length) {
      updateBounds();
    }
  }, [dealers, didFetchDealers, isFetching, view]);

  useEffect(() => {
    if (selectedDealer && selectedDealer !== prevActiveDealer) {
      setMarkerIcon(markersRef, selectedDealer, true);

      if (mapRef.current) {
        mapRef.current.panTo({
          lat: selectedDealer.lat,
          lng: selectedDealer.long,
        });
      }

      if (prevActiveDealer) {
        setMarkerIcon(markersRef, prevActiveDealer, false);
      }
    }

    if (
      hoveredDealer &&
      !prevHoveredDealer &&
      hoveredDealer !== selectedDealer
    ) {
      setMarkerIcon(markersRef, hoveredDealer, true);
    } else if (
      prevHoveredDealer &&
      !hoveredDealer &&
      prevHoveredDealer !== selectedDealer
    ) {
      setMarkerIcon(markersRef, prevHoveredDealer, false);
    }
  }, [selectedDealer, hoveredDealer, prevActiveDealer, prevHoveredDealer]);

  const handleMarkerClick = (dealer: Dealer) => {
    setListView();

    onDealerClick(dealer);
  };

  const handleMarkerLoad = (
    marker: google.maps.Marker,
    dealer: Dealer,
    text: string
  ) => {
    markersRef.current.set(dealer.code, { marker, text });

    setMarkerIcon(markersRef, dealer, selectedDealer?.code === dealer.code);
  };

  const handleMarkerMouseOver = (dealer: Dealer) => {
    onDealerHover(dealer);
  };

  const handleMarkerMouseOut = (dealer: Dealer) => {
    onDealerHover();
  };

  const updateBounds = () => {
    if (typeof google !== 'undefined' && dealers.length > 0) {
      const bounds = dealers.reduce((accBounds, dealer) => {
        return accBounds.extend({
          lat: dealer.lat,
          lng: dealer.long,
        });
      }, new google.maps.LatLngBounds());

      mapRef.current?.fitBounds(bounds); // NOSONAR
    }
  };

  return isLoaded && !loadError ? (
    <div className={styles.map}>
      <GoogleMap
        mapContainerStyle={{
          height: '100%',
          width: '100%',
        }}
        onLoad={map => {
          mapRef.current = map;

          updateBounds();
        }}
        options={{
          fullscreenControl: false,
          mapTypeControl: false,
          maxZoom: 17,
          streetViewControl: false,
          zoomControl: true,
        }}
      >
        {dealers.map((dealer, index) => (
          <Marker
            key={dealer.code}
            position={{ lat: dealer.lat, lng: dealer.long }}
            onClick={() => handleMarkerClick(dealer)}
            onLoad={marker => handleMarkerLoad(marker, dealer, `${index + 1}`)}
            onMouseOver={() => handleMarkerMouseOver(dealer)}
            onMouseOut={() => handleMarkerMouseOut(dealer)}
          />
        ))}
      </GoogleMap>
    </div>
  ) : null;
};

export default DealersMap;
