export const container: string;
export const heading: string;
export const headingContainer: string;
export const resultsContainer: string;
