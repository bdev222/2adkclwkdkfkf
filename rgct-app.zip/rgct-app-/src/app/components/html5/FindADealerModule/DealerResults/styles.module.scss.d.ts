export const dealers: string;
export const errorMessage: string;
export const noDealersFound: string;
export const viewMoreButton: string;
