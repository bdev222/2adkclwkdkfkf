import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useEffect } from 'react';
import { useTranslation } from 'react-i18next';

import { Location } from '../../../../util/campaignCodes';
import isZipCodeString from '../../../../util/isZipCodeString';
import createLinkBlock from '../../../shared/Analytics/blocks/createLinkBlock';
import EventTypes from '../../../shared/Analytics/EventTypes';
import useTrigger from '../../../shared/Analytics/useTrigger';
import Button from '../../Button';
import { useDealers } from '../../DealersContext';
import { Dealer } from '../../DealersContext/models';
import DealerResult from '../DealerResult';
import {
  ErrorMessage,
  OnDealerClick,
  OnDealerHover,
  SetListView,
} from '../models';
import styles from './styles.module.scss';

interface DealerResultsProps {
  errorMessage: ErrorMessage;
  hoveredDealer?: Dealer;
  location: Location;
  onDealerClick: OnDealerClick;
  onDealerHover: OnDealerHover;
  selectedDealer?: Dealer;
  setListView: SetListView;
}

const DealerResults: FC<DealerResultsProps> = ({
  errorMessage,
  hoveredDealer,
  location,
  onDealerClick,
  onDealerHover,
  selectedDealer,
  setListView,
}) => {
  useStyles(styles);

  const trigger = useTrigger();

  const { t } = useTranslation(['findADealer', 'dealers']);

  const [
    { dealers, didFetchDealers, hasMore, queryTerm },
    dealersDispatch,
  ] = useDealers();

  useEffect(() => {
    if (didFetchDealers && dealers.length === 0) {
      setListView();
    }
  }, [dealers, didFetchDealers, setListView]);

  const handleShowMoreBtnClick = () => {
    dealersDispatch({ type: 'showMore' });

    trigger(
      EventTypes.Click,
      createLinkBlock({ text: t('dealers:viewMoreDealers') })
    );
  };

  return (
    <div className={styles.dealers}>
      {errorMessage && (
        <div className={styles.errorMessage}>{errorMessage}</div>
      )}
      {didFetchDealers && dealers.length === 0 && (
        <div className={styles.noDealersFound}>
          {isZipCodeString(queryTerm)
            ? t('noDealersForZip')
            : t('noDealersForQuery', { query: queryTerm })}
        </div>
      )}
      {dealers.map((dealer, index) => (
        <DealerResult
          count={index + 1}
          dealer={dealer}
          isHighlighted={
            selectedDealer?.code === dealer.code ||
            hoveredDealer?.code === dealer.code
          }
          key={dealer.code}
          location={location}
          onDealerClick={onDealerClick}
          onDealerHover={onDealerHover}
          selectedDealer={selectedDealer}
        />
      ))}
      {hasMore && (
        <Button
          className={styles.viewMoreButton}
          isText
          onClick={handleShowMoreBtnClick}
          showCaret
          type="button"
        >
          {t('dealers:viewMoreDealers')}
        </Button>
      )}
    </div>
  );
};

export default DealerResults;
