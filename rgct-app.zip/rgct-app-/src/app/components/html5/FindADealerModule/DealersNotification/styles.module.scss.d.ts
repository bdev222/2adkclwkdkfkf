export const container: string;
export const notification: string;
