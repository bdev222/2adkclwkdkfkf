import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import { useDealersState } from '../../DealersContext';
import styles from './styles.module.scss';

const DealersNotification: FC = () => {
  useStyles(styles);

  const { t } = useTranslation('findADealer');

  const { dealers, didFetchDealers } = useDealersState();

  return didFetchDealers && dealers.length > 0 ? (
    <div className={styles.container}>
      <div
        className={styles.notification}
        dangerouslySetInnerHTML={{ __html: t('covidNotification') }}
      />
    </div>
  ) : null;
};

export default DealersNotification;
