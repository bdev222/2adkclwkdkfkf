import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';

import { Location } from '../../../util/campaignCodes';
import AnalyticsComponent from '../../shared/Analytics/AnalyticsComponent';
import createDealerSearchBlock from '../../shared/Analytics/blocks/createDealerSearchBlock';
import createKeyMetricsBlock from '../../shared/Analytics/blocks/createKeyMetricsBlock';
import createSectionBlock from '../../shared/Analytics/blocks/createSectionBlock';
import { AnalyticsBlock } from '../../shared/Analytics/models';
import DealersContextProvider from '../DealersContext';
import { Dealer } from '../DealersContext/models';
import DealerResults from './DealerResults';
import DealersMap from './DealersMap';
import DealersNotification from './DealersNotification';
import DealersSearch from './DealersSearch';
import { OnDealerClick, OnDealerHover, OnDealersFetch } from './models';
import styles from './styles.module.scss';

interface FindADealerModuleProps {
  location?: Location;
}

const FindADealerModule: FC<FindADealerModuleProps> = ({
  location = Location.ModuleFindADealerOther,
}) => {
  useStyles(styles);

  const { t } = useTranslation('findADealer');

  const dealerSearchBlockRef = useRef<AnalyticsBlock>();

  const [selectedDealer, setSelectedDealer] = useState<Dealer>();
  const [hoveredDealer, setHoveredDealer] = useState<Dealer>();

  const [view, setView] = useState<'dealers' | 'map'>('dealers');

  const [errorMessage, setErrorMessage] = useState<string>();

  const setListView = () => {
    setView('dealers');
  };

  const handleDealerClick: OnDealerClick = dealer => {
    setSelectedDealer(dealer);
  };

  const handleDealerHover: OnDealerHover = dealer => {
    setHoveredDealer(dealer);
  };

  const handleDealersFetch: OnDealersFetch = (
    dealers,
    queryTerm,
    queryType
  ) => {
    const searchBlock = createDealerSearchBlock({
      resultsCount: dealers.length,
      queryTerm,
      queryType,
    });

    dealerSearchBlockRef.current = searchBlock;
  };

  const handleToggleViewClick = () => {
    setView(prevView => (prevView === 'dealers' ? 'map' : 'dealers'));
  };

  const getDealerSearchBlockIfAvailable = () => {
    return dealerSearchBlockRef.current ?? {};
  };

  return (
    <DealersContextProvider>
      <AnalyticsComponent
        blocks={[
          createSectionBlock('fad_module'),
          getDealerSearchBlockIfAvailable,
        ]}
        initialBlocks={createKeyMetricsBlock('km-dealer-search')}
      >
        <section className={styles.container}>
          <div className={styles.headingContainer}>
            <h2 className={styles.heading}>{t('findADealer')}</h2>
          </div>
          <DealersSearch
            hasError={!!errorMessage}
            onDealersFetch={handleDealersFetch}
            onToggleViewClick={handleToggleViewClick}
            setErrorMessage={setErrorMessage}
            setListView={setListView}
            view={view}
          />
          <DealersNotification />
          <div className={styles.resultsContainer} data-view={view}>
            <DealerResults
              errorMessage={errorMessage}
              hoveredDealer={hoveredDealer}
              location={location}
              onDealerClick={handleDealerClick}
              onDealerHover={handleDealerHover}
              selectedDealer={selectedDealer}
              setListView={setListView}
            />
            <DealersMap
              hoveredDealer={hoveredDealer}
              onDealerClick={handleDealerClick}
              onDealerHover={handleDealerHover}
              selectedDealer={selectedDealer}
              setListView={setListView}
              view={view}
            />
          </div>
        </section>
      </AnalyticsComponent>
    </DealersContextProvider>
  );
};

export default FindADealerModule;
