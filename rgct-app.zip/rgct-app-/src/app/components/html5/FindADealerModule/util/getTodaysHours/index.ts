import { Dealer } from '../../../DealersContext/models';

const DAYS_OF_WEEK = [
  'Sunday',
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
];

const FAILED_RESPONSE = false;

function formatTime(time: number): string {
  const hour = Math.floor(time / 60);
  const minutes = time % 60;

  const period = hour > 12 ? 'PM' : 'AM';
  const displayHour = period === 'AM' ? hour : hour - 12;

  let displayTime = `${displayHour}`;

  const displayMinutes =
    minutes === 0 ? '00' : minutes < 10 ? `0${minutes}` : minutes;

  displayTime += `:${displayMinutes} ${period}`;

  return displayTime;
}

export default function getTodaysHours(hours?: Dealer['hours']) {
  try {
    const generalHours = hours?.find(hour => hour.hoursTypeCode === 'General');

    const dayIndex = new Date().getDay();
    const today = DAYS_OF_WEEK[dayIndex];

    const todaysHours = generalHours?.daysOfWeek.find(
      ({ dayOfWeekCode }) => dayOfWeekCode === today
    );

    if (
      !todaysHours?.availabilityEndTimeMeasure ||
      !todaysHours?.availabilityStartTimeMeasure
    ) {
      return FAILED_RESPONSE;
    }

    const startTime = formatTime(
      todaysHours.availabilityStartTimeMeasure.value
    );

    const endTime = formatTime(todaysHours.availabilityEndTimeMeasure.value);

    return {
      endTime,
      startTime,
    };
  } catch (error) {
    console.log(`Unable to get dealer's hours: "${error.message}"`);

    return FAILED_RESPONSE;
  }
}
