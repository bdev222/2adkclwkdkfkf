import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';

import { Dealer } from '../../../DealersContext/models';
import { IconMapMarker } from '../../../Icons';
import { MarkersRef } from '../../models';

export default function setMarkerIcon(
  markersRef: MarkersRef,
  dealer: Dealer,
  isHighlighted: boolean
): void {
  const markerRef = markersRef.current.get(dealer.code);

  if (!markerRef) {
    return;
  }

  const icon = renderToStaticMarkup(
    <IconMapMarker fill={isHighlighted ? 'rgb(235,10,30)' : 'rgb(0,0,0)'}>
      {markerRef.text}
    </IconMapMarker>
  );

  markerRef.marker.setIcon({
    url: `data:image/svg+xml;utf8,${icon}`,
  });
}
