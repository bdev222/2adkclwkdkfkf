import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import { uniqueId } from 'lodash';
import React, { ChangeEvent, FC, FormEvent, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

import useJsdsContexts from '../../../../util/useJsdsContexts';
import usePrevious from '../../../../util/usePrevious';
import createLinkBlock from '../../../shared/Analytics/blocks/createLinkBlock';
import EventTypes from '../../../shared/Analytics/EventTypes';
import useTrigger from '../../../shared/Analytics/useTrigger';
import { fetchDealersByQuery, useDealers } from '../../DealersContext';
import { IconMapMarker, IconSearch } from '../../Icons';
import { OnDealersFetch, SetErrorMessage, SetListView } from '../models';
import styles from './styles.module.scss';

interface DealersSearchProps {
  hasError: boolean;
  onDealersFetch: OnDealersFetch;
  onToggleViewClick: () => void;
  setErrorMessage: SetErrorMessage;
  setListView: SetListView;
  view: 'dealers' | 'map';
}

const DealersSearch: FC<DealersSearchProps> = ({
  hasError,
  onDealersFetch,
  onToggleViewClick,
  setErrorMessage,
  setListView,
  view,
}) => {
  useStyles(styles);

  const { t } = useTranslation('findADealer');

  const { page, site } = useJsdsContexts();

  const trigger = useTrigger();

  const [
    { allDealers, didFetchDealers, queryTerm, queryType },
    dealersDispatch,
  ] = useDealers();

  const [query, setQuery] = useState(page.meta.zipCode.zip);
  const prevQuery = usePrevious(query);

  useEffect(() => {
    if (query && prevQuery === undefined) {
      fetchDealers();
    }
  }, [query, prevQuery]);

  useEffect(() => {
    if (didFetchDealers && allDealers.length > 0) {
      onDealersFetch(allDealers, queryTerm, queryType);
    }
  }, [allDealers, didFetchDealers, onDealersFetch]);

  const fetchDealers = () => {
    const forceZipCodeProximity = site.tdaConfig.useDealerProximitySearch;
    fetchDealersByQuery(dealersDispatch, query, forceZipCodeProximity);
  };

  const handleInputChange = (event: ChangeEvent<HTMLInputElement>) => {
    setErrorMessage();

    setQuery(event.currentTarget.value);
  };

  const handleSearchButtonClick = () => {
    trigger(EventTypes.Click, createLinkBlock({ text: 'Search' }));
  };

  const handleSearchSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!query) {
      setErrorMessage(t('invalidQuery'));
      setListView();
    } else {
      fetchDealers();
    }
  };

  const labelId = uniqueId('findADealer-');

  return (
    <div className={styles.searchContainer}>
      <label className={styles.searchLabel} htmlFor={labelId}>
        {t('findADealerLabel')}
      </label>
      <form className={styles.searchRow} onSubmit={handleSearchSubmit}>
        <div
          className={cc({
            [styles.searchInput]: true,
            [styles.hasError]: hasError,
          })}
        >
          <input
            id={labelId}
            maxLength={80}
            onChange={handleInputChange}
            type="text"
            value={query}
          />
        </div>
        <button
          className={styles.searchSubmit}
          onClick={handleSearchButtonClick}
          type="submit"
        >
          <IconSearch height={24} width={24} />
        </button>
        <button
          className={styles.viewToggle}
          onClick={onToggleViewClick}
          type="button"
        >
          {view === 'dealers' ? (
            <>
              <IconMapMarker
                className={styles.toggleIcon}
                height={18}
                width={14}
              />
              <span>{t('map')}</span>
            </>
          ) : (
            <>
              <div className={cc([styles.toggleIcon, styles.hamburger])}>
                <span />
                <span />
                <span />
              </div>
              <span>{t('list')}</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
};

export default DealersSearch;
