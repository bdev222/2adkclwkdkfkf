import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useEffect, useMemo, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import scrollIntoView from 'scroll-into-view-if-needed';

import { Location } from '../../../../util/campaignCodes';
import makeDealerDistance from '../../../../util/makeDealerDistance';
import AnalyticsContext from '../../../shared/Analytics/AnalyticsContext';
import createDealerBlock from '../../../shared/Analytics/blocks/createDealerBlock';
import Button from '../../Button';
import Cta from '../../Cta';
import { Dealer } from '../../DealersContext/models';
import { IconMapMarker } from '../../Icons';
import { OnDealerClick, OnDealerHover } from '../models';
import getTodaysHours from '../util/getTodaysHours';
import styles from './styles.module.scss';

interface DealerResultProps {
  count: number;
  dealer: Dealer;
  isHighlighted: boolean;
  location: Location;
  onDealerClick: OnDealerClick;
  onDealerHover: OnDealerHover;
  selectedDealer?: Dealer;
}

const DealerResult: FC<DealerResultProps> = ({
  count,
  dealer,
  isHighlighted,
  location,
  onDealerClick,
  onDealerHover,
  selectedDealer,
}) => {
  useStyles(styles);

  const { t } = useTranslation(['findADealer', 'ctas', 'dealers']);

  const resultsRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (resultsRef.current && selectedDealer?.code === dealer.code) {
      scrollIntoView(resultsRef.current, {
        scrollMode: 'if-needed',
      });
    }
  }, [selectedDealer]);

  const handleDealerClick = () => {
    onDealerClick(dealer);
  };

  const handleDealerHover = () => {
    onDealerHover(dealer);
  };

  const handleDealerBlur = () => {
    onDealerHover();
  };

  const address = `${dealer.address}, ${dealer.city}, ${dealer.state} ${dealer.zip}`;

  const todaysHours = useMemo(() => getTodaysHours(dealer.hours), []);

  const ctaLabel = t('ctas:request-quote');

  return (
    <AnalyticsContext blocks={createDealerBlock(dealer)}>
      <div
        className={cc([
          styles.result,
          { [styles.isHighlighted]: isHighlighted },
        ])}
        onBlur={handleDealerBlur}
        onClick={handleDealerClick}
        onFocus={handleDealerHover}
        onMouseOut={handleDealerBlur}
        onMouseOver={handleDealerHover}
        ref={resultsRef}
        role="button"
        tabIndex={0}
      >
        <div className={styles.contents}>
          <IconMapMarker className={styles.marker}>{count}</IconMapMarker>
          <h3 className={styles.dealer}>
            <Button
              analytics={{ metrics: 'km-dealer-detail' }}
              as="a"
              isText
              target={`dealer-${dealer.code}`}
              to={`/dealers/dealer/${dealer.code}/`}
            >
              {dealer.name}
            </Button>
          </h3>
          <address className={styles.address}>
            <Button
              analytics={{ metrics: 'km-dealer-directions' }}
              as="a"
              isText
              target={`map-${dealer.code}`}
              to={`https://maps.google.com/?q=${encodeURIComponent(address)}`}
            >
              {address}
            </Button>
          </address>
          <p className={styles.distance}>
            ({t('dealers:milesAway', makeDealerDistance(dealer))})
          </p>
          {todaysHours && (
            <p className={styles.hours}>{t('todaysHours', todaysHours)}</p>
          )}
          <Button
            analytics={{ metrics: 'km-dealer-contact-call' }}
            as="a"
            className={styles.phone}
            isText
            to={`tel:${dealer.phone}`}
          >
            {dealer.phone}
          </Button>
          <ul className={styles.actions}>
            <li>
              <Button
                analytics={{ metrics: 'km-dealer-detail' }}
                as="a"
                isText
                target={`dealer-${dealer.code}`}
                to={`/dealers/dealer/${dealer.code}/`}
              >
                {t('dealerDetails')}
              </Button>
            </li>
            {dealer.serviceUrl && (
              <li>
                <Button
                  as="a"
                  analytics={{ metrics: 'km-service-scheduled' }}
                  target={`service-${dealer.code}`}
                  to={dealer.serviceUrl}
                  isText
                >
                  {t('scheduleService')}
                </Button>
              </li>
            )}
          </ul>
        </div>
        <div className={styles.ctas}>
          <Button
            analytics={{ metrics: 'km-dealer-visit_site' }}
            as="a"
            target={`website-${dealer.code}`}
            to={dealer.url}
          >
            <span>{t('dealerWebsite')}</span>
          </Button>
          <Cta
            className={styles.cta}
            dealer={dealer}
            id="request-quote"
            location={location}
            name={ctaLabel}
          >
            <span>{ctaLabel}</span>
          </Cta>
        </div>
      </div>
    </AnalyticsContext>
  );
};

export default DealerResult;
