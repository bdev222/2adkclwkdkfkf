import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import Link from '../Link';

interface DownloadProps {
  className?: string;
  isEnglish: boolean;
  path: string;
}

const Download: FC<DownloadProps> = ({ className, isEnglish, path }) => {
  const { t } = useTranslation('ctas');

  const title = t('downloadPdf', {
    context: isEnglish ? 'en' : undefined,
  });

  return (
    <Link
      aria-label={title}
      as="a"
      className={className}
      download
      target="_self"
      title={title}
      to={path}
    >
      {title}
    </Link>
  );
};

export default Download;
