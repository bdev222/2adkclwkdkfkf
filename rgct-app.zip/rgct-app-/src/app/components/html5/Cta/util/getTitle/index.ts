import { Vehicle } from '../../models';

export default function getTitle(name: string, vehicle: Vehicle) {
  const { seriesName, trimLabel, year } = vehicle;

  return {
    name,
    series: seriesName,
    trim: trimLabel,
    year,
  };
}
