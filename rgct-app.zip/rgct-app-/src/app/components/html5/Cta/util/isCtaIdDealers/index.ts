import { CtaIdDealers } from '../..';

export default function isCtaIdDealers(
  ctaId: string | CtaIdDealers
): ctaId is CtaIdDealers {
  return Object.values(CtaIdDealers).includes(ctaId as CtaIdDealers);
}
