import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import { Location } from '../../../util/campaignCodes';
import AnalyticsContext from '../../shared/Analytics/AnalyticsContext';
import createSeriesBlock from '../../shared/Analytics/blocks/createSeriesBlock';
import { Dealer } from '../DealersContext/models';
import CtaButton from './CtaButton';
import CtaLink from './CtaLink';
import { AnalyticsData, BackgroundImages, Offer, Vehicle } from './models';
import getTitle from './util/getTitle';

interface CtaProps {
  analytics?: AnalyticsData;
  backgroundImages?: BackgroundImages;
  className?: string;
  dealer?: Dealer;
  id: string;
  location: Location;
  name: string;
  offer?: Offer;
  tabIndex?: number;
  vehicle?: Vehicle;
}

export enum CtaIdDealers {
  CallDealer = 'call-dealer',
  VisitDealer = 'visit-dealer',
  ViewDealerInventory = 'view-dealer-inventory',
}

function getCtaType(id: string) {
  switch (id) {
    case CtaIdDealers.CallDealer:
    case 'contact-dealer':
    case 'request-quote':
    case 'schedule-test-drive':
    case CtaIdDealers.ViewDealerInventory:
    case CtaIdDealers.VisitDealer:
      return 'button';
    case 'build-&-price':
    case 'certified-used':
    case 'estimate-payment':
    case 'explore-vehicle':
    case 'find-dealer':
    case 'parts-&-services':
    case 'rent-a-car':
    case 'safety':
    case 'trade-in-value':
    case 'view-inventory':
    case 'view-offers':
    case 'what-fits-my-budget':
      return 'link';
    default:
      throw new Error(`Unknown CTA id "${id}"`);
  }
}

const Cta: FC<CtaProps> = ({
  analytics,
  backgroundImages,
  children,
  className,
  dealer,
  id,
  location,
  name,
  offer,
  tabIndex,
  vehicle,
}) => {
  const { t } = useTranslation('ctas');

  const title = vehicle ? t('ctaTitle', getTitle(name, vehicle)) : name;

  return (
    <AnalyticsContext blocks={vehicle ? createSeriesBlock(vehicle) : {}}>
      {getCtaType(id) === 'button' ? (
        <CtaButton
          analytics={analytics}
          backgroundImages={backgroundImages}
          className={className}
          ctaId={id}
          dealer={dealer}
          location={location}
          offer={offer}
          tabIndex={tabIndex}
          title={title}
          vehicle={vehicle}
        >
          {children}
        </CtaButton>
      ) : (
        <CtaLink
          analytics={analytics}
          className={className}
          id={id}
          offer={offer}
          tabIndex={tabIndex}
          title={title}
          vehicle={vehicle}
        >
          {children}
        </CtaLink>
      )}
    </AnalyticsContext>
  );
};

export default Cta;
