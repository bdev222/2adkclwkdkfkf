import React, { FC } from 'react';

import AnalyticsContext from '../../../../shared/Analytics/AnalyticsContext';
import createSectionBlock from '../../../../shared/Analytics/blocks/createSectionBlock';
import DealersContextProvider from '../../../DealersContext';
import Modal, { ModalProps } from '../../../Modal';
import { CtaIdDealers } from '../..';
import { Vehicle } from '../../models';
import DealerList from './DealerList';

interface DealerListModalProps extends ModalProps {
  ctaId: CtaIdDealers;
  vehicle?: Vehicle;
}

const DealerListModal: FC<DealerListModalProps> = ({
  ctaId,
  vehicle,
  ...modalProps
}) => {
  return (
    <AnalyticsContext
      blocks={createSectionBlock(
        ctaId === CtaIdDealers.CallDealer
          ? 'call_dealer_modal'
          : ctaId === CtaIdDealers.VisitDealer
          ? 'visit_dealer_modal'
          : 'select_dealer_overlay'
      )}
    >
      <Modal {...modalProps}>
        <DealersContextProvider>
          <DealerList ctaId={ctaId} vehicle={vehicle} />
        </DealersContextProvider>
      </Modal>
    </AnalyticsContext>
  );
};

export default DealerListModal;
