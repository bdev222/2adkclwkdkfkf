import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import getSeriesWithYear from '../../../../../util/getSeriesWithYear';
import LazyImage from '../../../LazyImage';
import ShareButton from '../../../ShareButton';
import { Offer, Vehicle } from '../../models';
import FinancialsContent from './FinancialsContent';
import styles from './styles.module.scss';

interface VehicleAsideProps {
  offer?: Offer;
  vehicle?: Vehicle;
}

const VehicleAside: FC<VehicleAsideProps> = ({ offer, vehicle }) => {
  useStyles(styles);

  const { t } = useTranslation('offer');

  const placeholderStyles = {
    width: '100%',
    height: '100%',
  };

  return !offer && !vehicle ? null : (
    <div className={styles.container}>
      <header className={styles.header}>
        {offer ? (
          <>
            <span className={styles.offerType} data-type={offer.type}>
              {offer.primaryLabel}
            </span>
            <h2 className={styles.heading}>{offer.seriesOrCardTitle}</h2>
            {offer.trimLabel && (
              <p className={styles.subHeading}>{offer.trimLabel}</p>
            )}
          </>
        ) : vehicle ? (
          <h2 className={styles.heading}>
            {t(
              'common:seriesWithYear',
              getSeriesWithYear(vehicle.seriesName, vehicle.year)
            )}
          </h2>
        ) : null}
      </header>
      <div className={styles.jelly}>
        {vehicle && (
          <LazyImage
            alt={t('common:jellyDescription', {
              color: vehicle.color,
              name: vehicle.seriesName,
              trim: vehicle.trimLabel,
              year: vehicle.year,
            })}
            className={styles.jellyImage}
            placeholderStyles={placeholderStyles}
            src={vehicle.image}
          />
        )}
        {!vehicle && offer && (
          <LazyImage
            alt={offer.offerImage.alt}
            className={styles.jellyImage}
            placeholderStyles={placeholderStyles}
            src={offer.offerImage.src}
          />
        )}
      </div>
      {offer && (
        <>
          <div className={styles.details}>
            <FinancialsContent offer={offer} />
            {offer.bonusTag && <p>{offer.bonusTag}</p>}
            <span className={styles.detailsExpiration}>
              {t('expiration', offer.endDate)}
            </span>
          </div>
          <footer className={styles.footer}>
            <ShareButton />
          </footer>
        </>
      )}
    </div>
  );
};

export default VehicleAside;
