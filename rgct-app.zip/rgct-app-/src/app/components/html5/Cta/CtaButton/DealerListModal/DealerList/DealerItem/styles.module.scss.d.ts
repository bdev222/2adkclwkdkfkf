export const button: string;
export const item: string;
export const dealerName: string;
export const dealerLocation: string;
