export const closeButton: string;
