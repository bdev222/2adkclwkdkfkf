import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useState } from 'react';

import { FormType, Location } from '../../../../../util/campaignCodes';
import getFormCode from '../../../../../util/getFormCode';
import AnalyticsContext from '../../../../shared/Analytics/AnalyticsContext';
import createSectionBlock from '../../../../shared/Analytics/blocks/createSectionBlock';
import EventTypes from '../../../../shared/Analytics/EventTypes';
import { Dealer } from '../../../DealersContext/models';
import Modal, { ModalProps } from '../../../Modal';
import SlpForm from '../../../SlpForm';
import { OnSlpSuccess, OutgoingSlpForm } from '../../../SlpForm/models';
import { BackgroundImages, Offer, Vehicle } from '../../models';
import VehicleAside from '../VehicleAside';
import FormConfirmation from './FormConfirmation';
import styles from './styles.module.scss';

interface FormSuccessProps {
  formValues: Partial<OutgoingSlpForm>;
  dealer: Dealer;
}

interface SlpFormModalProps extends ModalProps {
  backgroundImages?: BackgroundImages;
  ctaId: string;
  location: Location;
  lockedDealer?: Dealer;
  offer?: Offer;
  vehicle?: Vehicle;
}

const SlpFormModal: FC<SlpFormModalProps> = ({
  backgroundImages,
  ctaId,
  location,
  lockedDealer,
  offer,
  vehicle,
  ...modalProps
}) => {
  useStyles(styles);

  const [formSuccessProps, setFormSuccessProps] = useState<FormSuccessProps>();

  const handleSlpSuccess: OnSlpSuccess = (values, dealer) => {
    setFormSuccessProps({
      dealer,
      formValues: values,
    });
  };

  const formCode = getFormCode(ctaId);

  return (
    <AnalyticsContext
      blocks={createSectionBlock(
        `${formCode}_${formSuccessProps ? 'confirmation' : 'form'}_overlay`
      )}
    >
      <Modal {...modalProps}>
        <div>
          {!formSuccessProps ? (
            <div className={styles.container}>
              <VehicleAside offer={offer} vehicle={vehicle} />
              <SlpForm
                analytics={{
                  event: EventTypes.KmPageLoad,
                  timeout: 100,
                }}
                location={location}
                lockedDealer={lockedDealer}
                offer={offer}
                onSuccess={handleSlpSuccess}
                type={ctaId as FormType}
                variation="modal"
                vehicle={vehicle}
              />
            </div>
          ) : (
            <FormConfirmation
              {...formSuccessProps}
              analytics={{
                event: EventTypes.KmPageLoad,
                timeout: 100,
              }}
              backgroundImages={backgroundImages}
              formCode={formCode}
              offer={offer}
              vehicle={vehicle}
            />
          )}
        </div>
      </Modal>
    </AnalyticsContext>
  );
};

export default SlpFormModal;
