export const dealerList: string;
export const top: string;
export const heading: string;
export const items: string;
