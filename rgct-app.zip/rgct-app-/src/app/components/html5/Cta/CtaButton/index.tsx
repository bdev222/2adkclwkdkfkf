import React, { FC } from 'react';

import { Location } from '../../../../util/campaignCodes';
import useModalState from '../../../../util/useModalState';
import AnalyticsButton from '../../../shared/Analytics/AnalyticsButton';
import { Dealer } from '../../DealersContext/models';
import { CtaIdDealers } from '..';
import { AnalyticsData, BackgroundImages, Offer, Vehicle } from '../models';
import isCtaIdDealers from '../util/isCtaIdDealers';
import DealerListModal from './DealerListModal';
import SlpFormModal from './SlpFormModal';

interface CtaButtonProps {
  analytics?: AnalyticsData;
  backgroundImages?: BackgroundImages;
  className?: string;
  ctaId: string | CtaIdDealers;
  dealer?: Dealer;
  location: Location;
  offer?: Offer;
  tabIndex?: number;
  title: string;
  vehicle?: Vehicle;
}

const CtaButton: FC<CtaButtonProps> = ({
  analytics,
  backgroundImages,
  children,
  className,
  ctaId,
  dealer,
  location,
  offer,
  tabIndex,
  title,
  vehicle,
}) => {
  const modalProps = useModalState();

  const handleButtonClick = () => {
    modalProps.openModal();
  };

  return (
    <>
      <AnalyticsButton
        analytics={analytics}
        aria-label={title}
        className={className}
        title={title}
        onClick={handleButtonClick}
        tabIndex={tabIndex}
      >
        {children}
      </AnalyticsButton>
      {isCtaIdDealers(ctaId) ? (
        <DealerListModal ctaId={ctaId} vehicle={vehicle} {...modalProps} />
      ) : (
        <SlpFormModal
          backgroundImages={backgroundImages}
          ctaId={ctaId}
          lockedDealer={dealer}
          location={location}
          offer={offer}
          vehicle={vehicle}
          {...modalProps}
        />
      )}
    </>
  );
};

export default CtaButton;
