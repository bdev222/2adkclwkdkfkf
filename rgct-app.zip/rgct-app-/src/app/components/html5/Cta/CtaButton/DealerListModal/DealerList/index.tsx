import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useEffect } from 'react';
import { FormContext, useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

import useJsdsContexts from '../../../../../../util/useJsdsContexts';
import AnalyticsContext from '../../../../../shared/Analytics/AnalyticsContext';
import createLinkBlock from '../../../../../shared/Analytics/blocks/createLinkBlock';
import createListItemBlock from '../../../../../shared/Analytics/blocks/createListItemBlock';
import EventTypes from '../../../../../shared/Analytics/EventTypes';
import useTrigger from '../../../../../shared/Analytics/useTrigger';
import Button from '../../../../Button';
import { fetchDealersByZip, useDealers } from '../../../../DealersContext';
import { QueryType } from '../../../../DealersContext/models';
import DealersZipField from '../../../../DealersZipField';
import { CtaIdDealers } from '../../..';
import { Vehicle } from '../../../models';
import DealerItem from './DealerItem';
import styles from './styles.module.scss';

interface DealerListProps {
  ctaId: CtaIdDealers;
  vehicle?: Vehicle;
}

const DealerList: FC<DealerListProps> = ({ ctaId, vehicle }) => {
  useStyles(styles);

  const trigger = useTrigger();

  const { page } = useJsdsContexts();

  const { t } = useTranslation('dealers');

  const formProps = useForm();

  const [{ dealers, hasMore }, dealersDispatch] = useDealers();

  const isMirai = vehicle && vehicle.seriesId === 'mirai';

  const queryType = isMirai ? QueryType.Mirai : undefined;

  useEffect(() => {
    fetchDealersByZip(dealersDispatch, page.meta.zipCode.zip, queryType);
  }, [page.meta.zipCode.zip, queryType]);

  useEffect(() => {
    trigger(EventTypes.PageLoad, []);
  }, []);

  const makeCtaTitle = () => {
    if (ctaId === CtaIdDealers.CallDealer) {
      return t(isMirai ? 'callYourMiraiDealer' : 'callYourDealer');
    } else {
      return t(isMirai ? 'selectAMiraiDealer' : 'selectADealer');
    }
  };

  const handleZipSubmit = (zipCode: string) => {
    fetchDealersByZip(dealersDispatch, zipCode, queryType);
  };

  const handleShowMoreBtnClick = () => {
    dealersDispatch({ type: 'showMore' });

    trigger(EventTypes.Click, createLinkBlock({ text: t('viewMoreDealers') }));
  };

  return (
    <div className={styles.dealerList}>
      <div className={styles.top}>
        <h3 className={styles.heading}>{makeCtaTitle()}</h3>
        <FormContext {...formProps}>
          <DealersZipField
            initialZip={page.meta.zipCode.zip}
            name="dealerZip"
            onSubmit={handleZipSubmit}
          />
        </FormContext>
      </div>
      <ul className={styles.items}>
        {dealers.map((dealer, index) => {
          return (
            <li key={dealer.code}>
              <AnalyticsContext blocks={createListItemBlock(index)}>
                <DealerItem ctaId={ctaId} dealer={dealer} vehicle={vehicle} />
              </AnalyticsContext>
            </li>
          );
        })}
      </ul>
      {hasMore && (
        <Button isText onClick={handleShowMoreBtnClick} showCaret type="button">
          {t('viewMoreDealers')}
        </Button>
      )}
    </div>
  );
};

export default DealerList;
