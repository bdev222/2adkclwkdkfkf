import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import AnalyticsButton from '../../../../../shared/Analytics/AnalyticsButton';
import FormConfirmation from '../../../../FormConfirmation';
import { FormConfirmationProps } from '../../../../FormConfirmation/models';
import { IconClose } from '../../../../Icons';
import { useModalContext } from '../../../../Modal/ModalProvider';
import styles from './styles.module.scss';

const SlpFormModalFormConfirmation: FC<FormConfirmationProps> = props => {
  useStyles(styles);

  const { closeModal } = useModalContext();

  return (
    <FormConfirmation
      {...props}
      renderFooter={
        <AnalyticsButton
          analytics={{ text: 'Close' }}
          onClick={closeModal}
          className={styles.closeButton}
        >
          <IconClose />
        </AnalyticsButton>
      }
    />
  );
};

export default SlpFormModalFormConfirmation;
