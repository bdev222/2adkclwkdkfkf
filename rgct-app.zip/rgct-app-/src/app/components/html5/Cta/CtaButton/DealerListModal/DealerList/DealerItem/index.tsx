import useStyles from 'isomorphic-style-loader/useStyles';
import { get } from 'lodash';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import appendTrackingParams from '../../../../../../../util/appendTrackingParams';
import makeDealerDistance from '../../../../../../../util/makeDealerDistance';
import useJsdsContexts from '../../../../../../../util/useJsdsContexts';
import AnalyticsContext from '../../../../../../shared/Analytics/AnalyticsContext';
import createDealerBlock from '../../../../../../shared/Analytics/blocks/createDealerBlock';
import Button from '../../../../../Button';
import { Dealer } from '../../../../../DealersContext/models';
import { CtaIdDealers } from '../../../..';
import { Vehicle } from '../../../../models';
import styles from './styles.module.scss';

interface DealerProps {
  ctaId: CtaIdDealers;
  dealer: Dealer;
  vehicle?: Vehicle;
}

const DealerItem: FC<DealerProps> = ({ ctaId, dealer, vehicle }) => {
  useStyles(styles);

  const {
    page: {
      meta: {
        route: { canvas },
      },
    },
    site: { dealerInventoryUrls, tdaConfig },
  } = useJsdsContexts();

  const { t } = useTranslation('dealers');

  const makeInventoryLink = (
    dealerCode: string,
    baseUrl: string,
    seriesName?: string
  ) => {
    const vehicleUrls = dealerInventoryUrls.get(dealerCode);

    const defaultUrl = get(vehicleUrls, 'No Series', baseUrl);

    const page = canvas === 'allOffers' ? 'all' : 'details';

    const intsrc = `tcom:offers:${page}:${tdaConfig.code}`;
    const intexp = 'RCTCTAGroup:RCTCTAGroupexperienceB';

    const params = `intsrc=${intsrc}&intexp=${intexp}/`;

    const url = seriesName
      ? get(vehicleUrls, seriesName, defaultUrl)
      : defaultUrl;

    const urlConjunction = !url.includes('?')
      ? '?'
      : !url.endsWith('?')
      ? '&'
      : '';

    return `${url}${urlConjunction}${params}`;
  };

  const cta = (() => {
    const title = `${t('select')} ${dealer.name} ${t('common:newWindow')}`;

    switch (ctaId) {
      case CtaIdDealers.CallDealer:
        return {
          title: `${t('call')} ${dealer.name}`,
          to: `tel:${dealer.phone}`,
          label: t('call'),
        };

      case CtaIdDealers.ViewDealerInventory:
        return {
          label: t('select'),
          metrics: 'km-dealer-visit_inventory',
          target: '_blank',
          title,
          to: makeInventoryLink(dealer.code, dealer.url, vehicle?.seriesName),
        };

      default:
        return {
          label: t('select'),
          metrics: 'km-dealer-visit_site',
          target: '_blank',
          title,
          to: appendTrackingParams(dealer.url, canvas, tdaConfig.code),
        };
    }
  })();

  return (
    <AnalyticsContext blocks={createDealerBlock(dealer)}>
      <div className={styles.item}>
        <div>
          <span className={styles.dealerName}>{dealer.name}</span>
          <span className={styles.dealerLocation}>
            {`${dealer.address}, ${dealer.state} ${dealer.zip}`}
            {dealer.distance &&
              ` | ${t('milesAway', makeDealerDistance(dealer))}`}
          </span>
        </div>

        <Button
          analytics={{
            metrics: cta.metrics,
            typeTitle: dealer.name,
          }}
          as="a"
          className={styles.button}
          target={cta.target}
          title={cta.title}
          to={cta.to}
        >
          {cta.label}
        </Button>
      </div>
    </AnalyticsContext>
  );
};

export default DealerItem;
