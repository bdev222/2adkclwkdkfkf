export const content: string;
