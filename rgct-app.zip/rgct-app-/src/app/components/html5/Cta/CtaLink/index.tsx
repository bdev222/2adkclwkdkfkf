import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import useJsdsContexts from '../../../../util/useJsdsContexts';
import Link from '../../Link';
import { AnalyticsData, Offer, OfferType, Vehicle } from '../models';

interface CtaLinkProps {
  analytics?: AnalyticsData;
  className?: string;
  id: string;
  offer?: Offer;
  tabIndex?: number;
  title: string;
  vehicle?: Vehicle;
}

interface GetLinkParams {
  id: string;
  lang: string;
  langPrefix: string;
  offer?: Offer;
  tda?: string;
  vehicle?: Vehicle;
  zipCode: string | null;
}

// Unnormalize a series id to pass back to TCOM. Most likely this is being used
// to convert the correct "supra" series id into TCOM's incorrect "gr-supra".
function convertToTcomSeriesId(seriesId: string) {
  switch (seriesId) {
    case 'supra':
      return 'grsupra';
    default:
      return seriesId;
  }
}

function createBuildAndPriceUrl(vehicle?: Vehicle) {
  let url = 'configurator/';

  if (vehicle) {
    const tcomSeriesId = convertToTcomSeriesId(vehicle.seriesId);

    url += `build/step/model/year/${vehicle.year}/series/${tcomSeriesId}/`;

    if (vehicle.trimId) {
      url += `model/${vehicle.trimId}/`;
    }
  }

  return url;
}

function createEstimatePaymentUrl(vehicle?: Vehicle, offer?: Offer) {
  const url = 'payment-estimator/';

  const params = [];

  if (vehicle) {
    params.push(`series=${vehicle.seriesId}&year=${vehicle.year}`);

    if (vehicle.trimId) {
      params.push(`trim=${vehicle.trimId}`);
    }
  }

  if (
    offer &&
    !(offer.type === OfferType.Misc || offer.type === OfferType.MultiVehicle)
  ) {
    params.push(`offer=${offer.id}`);
  }

  return params.length ? `${url}?${params.join('&')}` : url;
}

function createExploreVehicleUrl(vehicle?: Vehicle) {
  if (!vehicle) {
    return 'all-vehicles/';
  }

  return `${convertToTcomSeriesId(vehicle?.seriesId)}/`;
}

function createFindDealerUrl(zipCode: string | null) {
  let url = 'dealers/';

  if (zipCode) {
    url += `?zipcode=${zipCode}`;
  }

  return url;
}

function createInventoryUrl(vehicle?: Vehicle) {
  let url = 'search-inventory/';

  if (vehicle) {
    const tcomSeriesId = convertToTcomSeriesId(vehicle.seriesId);

    url += `page/results/year/${vehicle.year}/series/${tcomSeriesId}/`;

    if (vehicle.trimCode) {
      url += `grade/${vehicle.trimCode}/`;
    }
  }

  return url;
}

function createViewOffersUrl(vehicle?: Vehicle, tda?: string) {
  let url = 'deals-incentives/';

  if (vehicle) {
    url += `?vehicles=${vehicle.seriesId}`;
  }

  if (tda) {
    url = `${tda}/${url}`;
  }

  return url;
}

function getUrl({
  id,
  lang,
  langPrefix,
  tda,
  offer,
  vehicle,
  zipCode,
}: GetLinkParams) {
  switch (id) {
    case 'build-&-price':
      return `${langPrefix}/${createBuildAndPriceUrl(vehicle)}`;
    case 'certified-used':
      return lang === 'es'
        ? '//www.toyotacertificados.com/'
        : '//www.toyotacertified.com/';
    case 'estimate-payment':
      return `${langPrefix}/${createEstimatePaymentUrl(vehicle, offer)}`;
    case 'explore-vehicle':
      return `${langPrefix}/${createExploreVehicleUrl(vehicle)}`;
    case 'find-dealer':
      return `${langPrefix}/${createFindDealerUrl(zipCode)}`;
    case 'parts-&-services':
      return '/owners/parts-service/toyota-care-plus';
    case 'rent-a-car':
      return lang === 'es'
        ? '/espanol/alquilar/index.html'
        : '/rental/index.html';
    case 'safety':
      return `${langPrefix}/safety-sense/`;
    case 'trade-in-value':
      return `${langPrefix}/kbb/`;
    case 'view-inventory':
      return `${langPrefix}/${createInventoryUrl(vehicle)}`;
    case 'view-offers':
      return `${langPrefix}/${createViewOffersUrl(vehicle, tda)}`;
    case 'what-fits-my-budget':
      return `${langPrefix}/what-fits-my-budget/`;
    default:
      throw new Error(`Unable to get URL for CTA with id "${id}"`);
  }
}

const CtaLink: FC<CtaLinkProps> = ({
  analytics,
  children,
  className,
  id,
  offer,
  tabIndex,
  title,
  vehicle,
}) => {
  const {
    page: {
      lang,
      meta: { route, zipCode },
    },
  } = useJsdsContexts();

  const { t } = useTranslation();

  const to = getUrl({
    id,
    lang,
    offer,
    langPrefix: route.langPrefix,
    tda: route.tdaContext,
    vehicle,
    zipCode: zipCode.confirmedZip,
  });

  const target = id === 'view-offers' ? '_self' : '_blank';

  return (
    <Link
      analytics={analytics}
      aria-label={title}
      as="a"
      className={className}
      rel="noreferrer"
      tabIndex={tabIndex}
      target={target}
      title={target === '_self' ? title : `${title} ${t('common:newWindow')}`}
      to={to}
    >
      {children}
    </Link>
  );
};

export default CtaLink;
