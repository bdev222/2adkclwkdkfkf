import {
  Offer as OfferProps,
  OfferBase,
} from '../../../../functions/layout/transforms/util/getOffers/models';

export { OfferType } from '../../../../functions/layout/transforms/util/getOffers/models';

export interface AnalyticsData {
  text?: string;
  typeTitle?: string;
}

export interface BackgroundImages {
  desktop: string;
  mobile: string;
}

export interface Vehicle {
  color: string;
  image: string;
  seriesId: string;
  seriesName: string;
  trimCode?: string;
  trimId?: string;
  trimLabel?: string;
  year: string;
}

type OfferCardProps =
  | 'bonusTag'
  | 'disclaimers'
  | 'endDate'
  | 'id'
  | 'primaryLabel'
  | 'ribbon'
  | 'offerImage'
  | 'series'
  | 'seriesOrCardTitle'
  | 'trimLabel';

export type Offer = OfferBase & Pick<OfferProps, OfferCardProps>;
