import cc from 'classcat';
import React, { FC, SVGAttributes } from 'react';
import { useTranslation } from 'react-i18next';

export const IconCheckmark: FC<SVGAttributes<SVGElement>> = props => {
  const { t } = useTranslation('icons');

  return (
    <svg {...props} viewBox="0 0 32 32">
      <title>{t('checkmark')}</title>
      <polygon points="11.79,27.79 8.42,24.42 0,16 3.37,12.63 11.79,21.05 28.63,4.21 32,7.58 " />
    </svg>
  );
};

export const IconMinus: FC<SVGAttributes<SVGElement>> = props => {
  const { t } = useTranslation('icons');

  return (
    <svg {...props} viewBox="0 0 32 32">
      <title>{t('minus')}</title>
      <rect y="13.71" width="32" height="4.57" />
    </svg>
  );
};

export const IconPlus: FC<SVGAttributes<SVGElement>> = props => {
  const { t } = useTranslation('icons');

  return (
    <svg {...props} viewBox="0 0 32 32">
      <title>{t('plus')}</title>
      <polygon
        points="32,18.29 18.29,18.29 18.29,32 13.71,32 13.71,18.28 0,18.29 0,13.71 13.71,13.71 13.71,0
        18.29,0 18.29,13.71 32,13.71 "
      />
    </svg>
  );
};

export const IconArrow: FC<SVGAttributes<SVGElement>> = props => {
  const { t } = useTranslation('icons');

  return (
    <svg className={cc([props.className, 'iconArrow'])} width="8" height="14">
      <title>{t('arrow')}</title>
      <path
        d="M1.778 13.364A1 1 0 01.364 11.95L5.314 7 .364 2.05A1 1 0 111.778.636l5.657 5.657a1 1 0 01.078 1.327l-.078.087-5.657 5.657z"
        fillRule="evenodd"
      />
    </svg>
  );
};

export const IconArrowUp: FC<SVGAttributes<SVGElement>> = props => {
  const { t } = useTranslation('icons');

  return (
    <svg
      {...props}
      className={cc([props.className, 'iconArrowUp'])}
      viewBox="-276.2 495.6 32 32"
    >
      <title>{t('arrowUp')}</title>
      <path d="M-252.2 500.3v2h-16v-2h16zm-14.4 10.4l1.4 1.4 3.9-3.9v16.1h2v-16.1l3.9 3.9 1.4-1.4-6.4-6.4-6.2 6.4z" />
    </svg>
  );
};

export const IconSearch: FC<SVGAttributes<SVGElement>> = props => {
  const { t } = useTranslation('icons');

  return (
    <svg height="14" viewBox="0 0 14 14" width="14" {...props}>
      <title>{t('search')}</title>
      <path
        d="m6.5 1c3.03756612 0 5.5 2.46243388 5.5 5.5 0 1.15722994-.3573982 2.23098505-.9678374 3.11690796l3.6749442 3.67598524c.3905243.3905243.3905243 1.0236893 0 1.4142136-.360484.3604839-.927715.3882135-1.3200062.0831886l-.0942074-.0831886-3.67598524-3.6749442c-.88592291.6104392-1.95967802.9678374-3.11690796.9678374-3.03756612 0-5.5-2.46243388-5.5-5.5s2.46243388-5.5 5.5-5.5zm0 2c-1.93299662 0-3.5 1.56700338-3.5 3.5s1.56700338 3.5 3.5 3.5 3.5-1.56700338 3.5-3.5-1.56700338-3.5-3.5-3.5z"
        fillRule="evenodd"
        transform="translate(-1 -1)"
      />
    </svg>
  );
};

export const IconShare: FC<SVGAttributes<SVGElement>> = props => {
  const { t } = useTranslation('icons');

  return (
    <svg {...props} viewBox="0 0 64 64">
      <title>{t('share')}</title>
      <path
        d="M29.26,25.15h5.48v-5.48h-5.48V25.15z M21.04,25.15h21.91v-5.48H21.04V25.15z M29.26,25.15H12.83
	v32.87h38.35V25.15H34.74v10.96c0,1.51-1.22,2.74-2.74,2.74c-1.51,0-2.74-1.23-2.74-2.74V25.15z M34.74,9.86v9.81h16.45
	c3.02,0,5.46,2.45,5.46,5.46v32.9c0,3.02-2.44,5.46-5.46,5.46H12.81c-3.02,0-5.46-2.45-5.46-5.46v-32.9c0-3.02,2.44-5.46,5.46-5.46
	h16.45V9.86l-3.09,3.09c-1.06,1.06-2.78,1.06-3.86-0.02c-1.07-1.07-1.06-2.81-0.02-3.86l7.78-7.78c0.53-0.53,1.22-0.79,1.91-0.79
	l0.02,0.01c0.7,0,1.39,0.26,1.91,0.78l7.78,7.78c1.06,1.06,1.06,2.78-0.02,3.86C40.61,14,38.87,14,37.82,12.95L34.74,9.86z"
      />
    </svg>
  );
};

export const IconClose: FC<SVGAttributes<SVGElement>> = props => {
  const { t } = useTranslation('icons');

  return (
    <svg {...props} viewBox="0 0 32 32">
      <title>{t('close')}</title>
      <polygon
        points="32,4.57 27.43,0 16,11.43 4.57,0 0,4.57 11.43,16 0,27.43 4.57,32 16,20.57 27.43,32 32,27.43
        20.57,16 "
      />
    </svg>
  );
};

export const IconVehicle: FC<SVGAttributes<SVGElement>> = props => {
  const { t } = useTranslation('icons');

  return (
    <svg {...props} viewBox="0 0 32 32">
      <title>{t('vehicle')}</title>
      <path
        d="M26.47,25.43H5.53v2.01H0.26V15.82l3.43-4.14H0.9c0.11-1.79,0.61-2.69,1.48-2.69h1.08v1.05h0.9
        c2.19-3.52,3.88-5.35,5.05-5.47V4.56h13.02c1.18,0,2.91,1.83,5.18,5.48h0.9V8.99h1.08c0.88,0,1.37,0.89,1.49,2.69h-2.8l3.43,4.14
        v11.63h-5.27V25.43L26.47,25.43z M5.45,11.52h21.02l-3.02-4.97H8.44L5.45,11.52L5.45,11.52z M22.45,18.54h6.03V14.5L22.45,18.54
        L22.45,18.54z M9.44,18.54L3.41,14.5v4.04L9.44,18.54L9.44,18.54z M16.29,20.46c1.11,0,2-0.45,2-1c0-0.55-0.9-0.99-2-0.99
        s-2.01,0.45-2.01,0.99C14.29,20.02,15.19,20.46,16.29,20.46z"
      />
    </svg>
  );
};

export const IconEdit: FC<SVGAttributes<SVGElement>> = props => {
  const { t } = useTranslation('icons');

  return (
    <svg {...props} viewBox="0 0 15 15">
      <title>{t('edit')}</title>
      <g
        stroke="none"
        strokeWidth="1"
        fill="none"
        fillRule="evenodd"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <g transform="translate(-725.000000, -528.000000)">
          <g transform="translate(726.560000, 529.560000)">
            <g>
              <polygon
                stroke="#979797"
                strokeWidth="1.4322"
                fill="#979797"
                points="12.0974485 2.00296331 2.07982012 12.0205917 0 12.0974485 0.0768568047 10.0166911 10.0935479 0"
              />
              <path
                d="M8.83384615,0.913846154 L11.2707692,3.35076923"
                stroke="#FFFFFF"
                strokeWidth="1.32"
              />
              <path
                d="M0.609230769,9.13846154 L3.04615385,11.5753846"
                stroke="#FFFFFF"
                strokeWidth="1.32"
              />
            </g>
          </g>
        </g>
      </g>
    </svg>
  );
};

export const IconCar: FC<SVGAttributes<SVGElement>> = props => {
  const { t } = useTranslation('icons');

  return (
    <svg {...props} viewBox="0 0 32 23">
      <title>{t('car')}</title>
      <g stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
        <g
          transform="translate(-38.000000, -36.000000)"
          fill="#000000"
          fillRule="nonzero"
        >
          <g transform="translate(35.800000, 13.750000)">
            <g>
              <g>
                <g transform="translate(0.000000, 15.120000)">
                  <path d="M28.3968,27.8139 L8.1432,27.8139 L8.1432,29.75835 L3.045,29.75835 L3.045,18.507075 L6.3684,14.505075 L3.66052499,14.505075 C3.77145,12.769425 4.252125,11.903775 5.096025,11.903775 L6.14437501,11.903775 L6.14437501,12.91515 L7.01655,12.91515 C9.13935,9.50910001 10.768425,7.74300001 11.90595,7.61902499 L11.90595,7.6125 L24.5079001,7.6125 C25.6497751,7.6125 27.320175,9.380775 29.52345,12.91515 L30.395625,12.91515 L30.395625,11.903775 L31.4418,11.903775 C32.29005,11.903775 32.7685499,12.769425 32.879475,14.5029 L30.1716001,14.5029 L33.495,18.5049 L33.495,29.75835 L28.3968,29.75835 L28.3968,27.816075 L28.3968,27.8139 Z M8.06054999,14.355 L28.40115,14.355 L25.4757749,9.54825 L10.955475,9.54825 L8.06272501,14.355 L8.06054999,14.355 Z M24.5079001,21.141 L30.343425,21.141 L30.343425,17.232525 L24.5079001,21.138825 L24.5079001,21.141 Z M11.925525,21.141 L6.09,17.2303501 L6.09,21.1366499 L11.925525,21.1366499 L11.925525,21.141 Z M18.5549251,23.004975 C19.625025,23.004975 20.49285,22.5743251 20.49285,22.0414501 C20.49285,21.51075 19.625025,21.0801 18.5549251,21.0801 C17.484825,21.0801 16.6148249,21.51075 16.6148249,22.0414501 C16.6148249,22.5743251 17.484825,23.004975 18.5549251,23.004975 Z" />
                </g>
              </g>
            </g>
          </g>
        </g>
      </g>
    </svg>
  );
};

export const IconPin: FC<SVGAttributes<SVGElement>> = props => {
  const { t } = useTranslation('icons');

  return (
    <svg {...props} width="24px" height="36px" viewBox="0 0 61 103">
      <title>{t('pin')}</title>
      <g stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
        <g fill="#EB0A1F" fillRule="nonzero">
          <path d="M30.6,0.8 C13.8,0.8 0.2,14.4 0.2,31.2 C0.2,48 30.6,102.7 30.6,102.7 C30.6,102.7 61,47.9 61,31.2 C61,14.5 47.4,0.8 30.6,0.8 Z M19.7,29 C19.7,23 24.6,18.1 30.6,18.1 C36.6,18.1 41.5,23 41.5,29 C41.5,35 36.6,39.9 30.6,39.9 C24.6,39.9 19.7,35.1 19.7,29 Z" />
        </g>
      </g>
    </svg>
  );
};

export const IconMapMarker: FC<SVGAttributes<SVGElement>> = ({
  children,
  ...props
}) => {
  const { t } = useTranslation('icons');

  return (
    <svg
      fill="rgb(0,0,0)"
      height="38"
      viewBox="0 0 27 38"
      width="27"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <title>{t('mapMarker')}</title>
      <g transform="translate(-286.000000, -228.000000)">
        <path
          d="M299.276725,228 C291.978408,228 286,233.978408 286,241.276725 C286,248.342117 298.1121,264.258658 298.655592,264.957433 C298.810875,265.112717 299.0438,265.268 299.276725,265.268 C299.50965,265.268 299.742575,265.112717 299.897858,264.957433 C300.44135,264.258658 312.55345,248.342117 312.55345,241.276725 C312.55345,233.978408 306.575042,228 299.276725,228 Z"
          fillRule="nonzero"
        />
        <circle fill="rgb(255,255,255)" cx="299.25" cy="241.25" r="8.25" />
      </g>
      {children && (
        <text
          x="13.5"
          y="17"
          textAnchor="middle"
          fontFamily="tcomMed, Helvetica, Arial, sans-serif"
          fontSize="10"
        >
          {children}
        </text>
      )}
    </svg>
  );
};

export const IconLoad: FC<SVGAttributes<SVGElement>> = props => {
  const { t } = useTranslation('icons');

  return (
    <svg viewBox="0 0 56 56" height="56px" width="56px" {...props}>
      <title>{t('load')}</title>
      <g>
        <g data-name="loader generic">
          <g>
            <circle fill="#fff" fillOpacity="0.6" cx="28" cy="28" r="28" />
            <path
              fill="none"
              stroke="#000"
              strokeLinecap="round"
              strokeWidth="3px"
              d="M28,48A20,20,0,1,0,8,28"
            />
          </g>
        </g>
      </g>
    </svg>
  );
};

export const IconRequired: FC<SVGAttributes<SVGElement>> = props => {
  const { t } = useTranslation('icons');

  return (
    <svg width="5" height="5" {...props}>
      <title>{t('required')}</title>
      <path
        d="M3.348 4.548l.816-.588-1.044-1.2 1.548-.36-.312-.96-1.464.624L3.036.48h-1.02l.144 1.584L.696 1.44l-.312.96 1.548.36-1.044 1.2.816.588.828-1.356z"
        fill="#EB0A1E"
        fillRule="evenodd"
      />
    </svg>
  );
};

export const IconBulletCheckMark: FC<SVGAttributes<SVGElement>> = props => {
  const { t } = useTranslation('icons');

  return (
    <svg viewBox="0 0 20 20" {...props}>
      <title>{t('checkmark')}</title>
      <path
        d="M12.712 3C7.357 3 3 7.357 3 12.712c0 5.355 4.357 9.712 9.712 9.712 5.355 0 9.712-4.357 9.712-9.712C22.424 7.357 18.067 3 12.712 3zm-1.774 14.586l-3.764-4.182 1.111-1 2.615 2.905 6.2-7.385 1.146.96-7.31 8.702z"
        fill="#1CB05C"
      />
    </svg>
  );
};

export const IconBulletX: FC<SVGAttributes<SVGElement>> = props => {
  const { t } = useTranslation('icons');

  return (
    <svg width="24" height="24" {...props}>
      <title>{t('x')}</title>
      <path
        fill="#000000"
        d="M10 0C4.486 0 0 4.486 0 10s4.486 10 10 10 10-4.486 10-10S15.514 0 10 0zm4.167 13.333l-.834.834L10 10.833l-3.333 3.334-.834-.834L9.167 10 5.833 6.667l.834-.834L10 9.167l3.333-3.334.834.834L10.833 10l3.334 3.333z"
        fillRule="nonzero"
      />
    </svg>
  );
};
