import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import useJsdsContexts from '../../../../util/useJsdsContexts';
import AnalyticsContext from '../../../shared/Analytics/AnalyticsContext';
import AnalyticsInlineTrigger from '../../../shared/Analytics/AnalyticsInlineTrigger';
import createLinkModuleBlock from '../../../shared/Analytics/blocks/createLinkModuleBlock';
import createSectionBlock from '../../../shared/Analytics/blocks/createSectionBlock';
import EventTypes from '../../../shared/Analytics/EventTypes';
import Breadcrumbs from '../../Breadcrumbs';
import ColumnsList from '../../ColumnsList';
import CtaButton from '../../CtaButton';
import { OffersContent } from '../../models';
import Offers from '../../Offers';
import Section from '../../Section';

type OffersViewProps = OffersContent;

const OffersView: FC<OffersViewProps> = props => {
  const {
    breadcrumbs,
    filterOptions,
    headline,
    introCopy,
    primaryCTA,
    tdaPrefix,
    vehicleColumns,
    vehicleList,
    zipCode,
  } = props;

  const { t } = useTranslation('seoPage');

  const { page } = useJsdsContexts();

  return (
    <AnalyticsInlineTrigger
      blocks={[createSectionBlock('local_offers_by_type')]}
      km="km-offers-search"
      type={EventTypes.PageLoad}
    >
      <div>
        <Breadcrumbs breadcrumbs={breadcrumbs} />
        <AnalyticsContext blocks={createSectionBlock('hero')} ssrOnly>
          <div>
            <Section background="white">
              <h1>{headline}</h1>
              <p>{introCopy}</p>
              <CtaButton
                analytics={{ module: 'local_offers_by_type' }}
                url={`${page.meta.route.prefix}local-specials/`}
              >
                {primaryCTA}
              </CtaButton>
            </Section>
          </div>
        </AnalyticsContext>
        <AnalyticsContext
          blocks={createLinkModuleBlock('local_offers_by_type')}
          ssrOnly
        >
          <div>
            {tdaPrefix && vehicleList.length > 0 ? (
              <Offers
                filterOptions={filterOptions}
                tdaPrefix={tdaPrefix}
                vehicles={vehicleList}
                zipCode={zipCode}
              />
            ) : (
              <Section background="grey">
                <h2 data-size="large">{t('browseAllVehicleOffers')}</h2>
                <ColumnsList columns={vehicleColumns} mobileRowLength={2} />
                <CtaButton url={`${page.meta.route.prefix}local-specials/`}>
                  {t('viewAllOffers')}
                </CtaButton>
              </Section>
            )}
          </div>
        </AnalyticsContext>
      </div>
    </AnalyticsInlineTrigger>
  );
};

export default OffersView;
