import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import useJsdsContexts from '../../../../util/useJsdsContexts';
import AnalyticsContext from '../../../shared/Analytics/AnalyticsContext';
import AnalyticsInlineTrigger from '../../../shared/Analytics/AnalyticsInlineTrigger';
import createLinkModuleBlock from '../../../shared/Analytics/blocks/createLinkModuleBlock';
import createSectionBlock from '../../../shared/Analytics/blocks/createSectionBlock';
import EventTypes from '../../../shared/Analytics/EventTypes';
import ColumnsList from '../../ColumnsList';
import CtaButton from '../../CtaButton';
import CtaLink from '../../CtaLink';
import DisplayModule from '../../DisplayModule';
import HeroImage from '../../HeroImage';
import { NationalContent } from '../../models';
import Section from '../../Section';
import ZipCodeInput from '../../ZipCodeInput';

type NationalViewProps = NationalContent;

const NationalView: FC<NationalViewProps> = props => {
  const {
    contentModuleSectionHeadline,
    headline,
    heroImage,
    introCopy,
    modules,
    primaryCTA,
    stateSelectorCopy,
    stateSelectorFADCopy,
    stateSelectorFADCTA,
    stateSelectorHeadline,
    vehicleOfferSelectorCTA,
    vehicleOfferSelectorHeadline,
    stateColumns,
    vehicleColumns,
  } = props;

  const { t } = useTranslation('seoPage');

  const { page } = useJsdsContexts();

  return (
    <AnalyticsInlineTrigger
      blocks={createSectionBlock('local_offers_dealer_hub')}
      type={EventTypes.PageLoad}
    >
      <div>
        <Section background="white">
          <AnalyticsContext blocks={createSectionBlock('hero')} ssrOnly>
            <div>
              <h1 data-size="large">{headline}</h1>
              <p>{introCopy}</p>
              <CtaButton
                analytics={{ module: 'local_offers_dealer_hub' }}
                url={`${page.meta.route.prefix}local-specials/`}
              >
                {primaryCTA}
              </CtaButton>
            </div>
          </AnalyticsContext>
        </Section>
        <HeroImage src={heroImage} />
        <Section background="grey">
          <AnalyticsInlineTrigger
            blocks={createSectionBlock('local_offers_state_selection')}
            type={EventTypes.SubPageLoad}
          >
            <AnalyticsContext
              blocks={createLinkModuleBlock('local_offers_dealer_hub')}
              ssrOnly
            >
              <div>
                <h2 data-size="large">{stateSelectorHeadline}</h2>
                <p>{stateSelectorCopy}</p>
                <ColumnsList columns={stateColumns} />
                <h3 data-size="small">{stateSelectorFADCopy}</h3>
                <ZipCodeInput
                  analytics={{ module: 'local_offers_dealer_hub' }}
                  buttonValue={stateSelectorFADCTA}
                />
                <h2 data-size="medium">{t('outsideUS')}</h2>
                <CtaLink
                  target="_blank"
                  title={`${t('learnMoreInEnglish')} ${t('common:newWindow')}`}
                  url="https://global.toyota/"
                >
                  {t('learnMoreInEnglish')}
                </CtaLink>
              </div>
            </AnalyticsContext>
          </AnalyticsInlineTrigger>
        </Section>
        {modules.length > 0 && (
          <AnalyticsInlineTrigger
            blocks={createSectionBlock('local_offers_highlights')}
            type={EventTypes.SubPageLoad}
          >
            <Section background="white">
              <h2 data-size="large">{contentModuleSectionHeadline}</h2>
            </Section>
            <AnalyticsContext
              blocks={createLinkModuleBlock('local_offers_dealer_hub')}
              ssrOnly
            >
              <div>
                {modules.map((module, index) => (
                  <DisplayModule
                    key={`${index}-${module.cta.url}`}
                    img={module.image}
                    imgSide={index % 2 === 0 ? 'right' : 'left'}
                    {...module}
                  />
                ))}
              </div>
            </AnalyticsContext>
          </AnalyticsInlineTrigger>
        )}
        <AnalyticsInlineTrigger
          blocks={createSectionBlock('local_offers_vehicle_selection')}
          type={EventTypes.SubPageLoad}
        >
          <Section background="grey">
            <AnalyticsContext
              blocks={createLinkModuleBlock('local_offers_dealer_hub')}
              ssrOnly
            >
              <div>
                <h2 data-size="large">{vehicleOfferSelectorHeadline}</h2>
                <ColumnsList columns={vehicleColumns} mobileRowLength={2} />
                <CtaButton url={`${page.meta.route.prefix}local-specials/`}>
                  {vehicleOfferSelectorCTA}
                </CtaButton>
              </div>
            </AnalyticsContext>
          </Section>
        </AnalyticsInlineTrigger>
      </div>
    </AnalyticsInlineTrigger>
  );
};

export default NationalView;
