import React, { FC } from 'react';

import useJsdsContexts from '../../../../util/useJsdsContexts';
import AnalyticsContext from '../../../shared/Analytics/AnalyticsContext';
import AnalyticsInlineTrigger from '../../../shared/Analytics/AnalyticsInlineTrigger';
import createLinkModuleBlock from '../../../shared/Analytics/blocks/createLinkModuleBlock';
import createSectionBlock from '../../../shared/Analytics/blocks/createSectionBlock';
import EventTypes from '../../../shared/Analytics/EventTypes';
import Breadcrumbs from '../../Breadcrumbs';
import ColumnsList from '../../ColumnsList';
import CtaButton from '../../CtaButton';
import CtaLink from '../../CtaLink';
import { StateContent } from '../../models';
import Section from '../../Section';
import ZipCodeInput from '../../ZipCodeInput';

type StateViewProps = StateContent;

const StateView: FC<StateViewProps> = props => {
  const {
    allCitiesUrl,
    breadcrumbs,
    cityColumns,
    headline,
    introCopy,
    metroSelectorCityCTA,
    metroSelectorCityHeadline,
    metroSelectorFADCopy,
    metroSelectorFADCTA,
    metroSelectorHeadline,
    primaryCTA,
    stateColumns,
    stateSelectorFADCopy,
    stateSelectorFADCTA,
    stateSelectorHeadline,
  } = props;

  const { page } = useJsdsContexts();

  return (
    <AnalyticsInlineTrigger
      blocks={createSectionBlock('local_offers_state')}
      type={EventTypes.PageLoad}
    >
      <div>
        <Breadcrumbs breadcrumbs={breadcrumbs} />
        <Section background="white">
          <AnalyticsContext blocks={createSectionBlock('hero')} ssrOnly>
            <div>
              <h1 data-size="large">{headline}</h1>
              <p>{introCopy}</p>
              <CtaButton
                analytics={{ module: 'local_offers_state' }}
                url={`${page.meta.route.prefix}local-specials/`}
              >
                {primaryCTA}
              </CtaButton>
            </div>
          </AnalyticsContext>
        </Section>
        <AnalyticsInlineTrigger
          blocks={createSectionBlock('local_offers_city_selection')}
          type={EventTypes.SubPageLoad}
        >
          <Section background="grey">
            <AnalyticsContext
              blocks={createLinkModuleBlock('local_offers_state')}
              ssrOnly
            >
              <h2 data-size="large">{metroSelectorHeadline}</h2>
              <div>
                <ColumnsList columns={cityColumns} />
                <h3 data-size="small">{metroSelectorFADCopy}</h3>
                <ZipCodeInput
                  analytics={{ module: 'local_offers_state' }}
                  buttonValue={metroSelectorFADCTA}
                />
                <h2 data-size="medium">{metroSelectorCityHeadline}</h2>
                <CtaLink url={`${page.meta.route.prefix}${allCitiesUrl}`}>
                  {metroSelectorCityCTA}
                </CtaLink>
              </div>
            </AnalyticsContext>
          </Section>
        </AnalyticsInlineTrigger>
        <AnalyticsInlineTrigger
          blocks={createSectionBlock('local_offers_state_selection')}
          type={EventTypes.SubPageLoad}
        >
          <Section background="white">
            <AnalyticsContext
              blocks={createLinkModuleBlock('local_offers_state')}
              ssrOnly
            >
              <div>
                <h2 data-size="large">{stateSelectorHeadline}</h2>
                <ColumnsList columns={stateColumns} />
                <h3 data-size="small">{stateSelectorFADCopy}</h3>
                <ZipCodeInput
                  analytics={{ module: 'local_offers_state' }}
                  buttonValue={stateSelectorFADCTA}
                />
              </div>
            </AnalyticsContext>
          </Section>
        </AnalyticsInlineTrigger>
      </div>
    </AnalyticsInlineTrigger>
  );
};

export default StateView;
