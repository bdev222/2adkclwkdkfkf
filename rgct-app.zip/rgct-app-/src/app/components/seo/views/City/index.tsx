import React, { FC } from 'react';

import useJsdsContexts from '../../../../util/useJsdsContexts';
import AnalyticsContext from '../../../shared/Analytics/AnalyticsContext';
import AnalyticsInlineTrigger from '../../../shared/Analytics/AnalyticsInlineTrigger';
import createLinkModuleBlock from '../../../shared/Analytics/blocks/createLinkModuleBlock';
import createSectionBlock from '../../../shared/Analytics/blocks/createSectionBlock';
import EventTypes from '../../../shared/Analytics/EventTypes';
import Breadcrumbs from '../../Breadcrumbs';
import ColumnsList from '../../ColumnsList';
import CtaButton from '../../CtaButton';
import DisplayModule from '../../DisplayModule';
import FeaturedOffers from '../../FeaturedOffers';
import HeroImage from '../../HeroImage';
import { CityContent } from '../../models';
import Section from '../../Section';
import ZipCodeInput from '../../ZipCodeInput';

type CityViewProps = CityContent;

const CityView: FC<CityViewProps> = props => {
  const {
    breadcrumbs,
    cityColumns,
    citySelectorFADCopy,
    citySelectorFADCTA,
    citySelectorHeadline,
    contentModuleSectionHeadline,
    headline,
    heroImage,
    introCopy,
    modules,
    offers,
    offersModuleHeadline,
    primaryCTA,
    tdaPrefix,
    vehicleColumns,
    vehicleOfferSelectorCTA,
    vehicleOfferSelectorHeadline,
    zipcode,
  } = props;

  const { page } = useJsdsContexts();

  return (
    <AnalyticsInlineTrigger
      blocks={createSectionBlock('local_offers_city')}
      type={EventTypes.PageLoad}
    >
      <div>
        <Breadcrumbs breadcrumbs={breadcrumbs} />
        <AnalyticsContext blocks={createSectionBlock('hero')} ssrOnly>
          <div>
            <Section background="white">
              <h1 data-size="large">{headline}</h1>
              <p>{introCopy}</p>
              <CtaButton
                analytics={{ module: 'local_offers_city' }}
                url={`${page.meta.route.prefix}local-specials/`}
              >
                {primaryCTA}
              </CtaButton>
            </Section>
          </div>
        </AnalyticsContext>
        <HeroImage src={heroImage} />
        <AnalyticsInlineTrigger
          blocks={createSectionBlock('featured_offers')}
          type={EventTypes.SubPageLoad}
        >
          <Section background="grey">
            <h2 data-size="large">{offersModuleHeadline}</h2>
            <AnalyticsContext
              blocks={createLinkModuleBlock('local_offers_city')}
              ssrOnly
            >
              <div>
                <FeaturedOffers offers={offers} tdaPrefix={tdaPrefix} />
              </div>
            </AnalyticsContext>
          </Section>
        </AnalyticsInlineTrigger>
        {modules.length > 0 && (
          <AnalyticsInlineTrigger
            blocks={createSectionBlock('local_offers_highlights')}
            type={EventTypes.SubPageLoad}
          >
            <Section background="white">
              <h2 data-size="large">{contentModuleSectionHeadline}</h2>
            </Section>
            <AnalyticsContext
              blocks={createLinkModuleBlock('local_offers_city')}
              ssrOnly
            >
              <div>
                {modules.map((module, index) => (
                  <DisplayModule
                    key={index}
                    img={module.image}
                    imgSide={index % 2 === 0 ? 'right' : 'left'}
                    {...module}
                  />
                ))}
              </div>
            </AnalyticsContext>
          </AnalyticsInlineTrigger>
        )}
        <AnalyticsInlineTrigger
          blocks={createSectionBlock('local_offers_vehicle_selection')}
          type={EventTypes.SubPageLoad}
        >
          <Section background="white">
            <AnalyticsContext
              blocks={createLinkModuleBlock('local_offers_city')}
              ssrOnly
            >
              <div>
                <h2 data-size="large">{vehicleOfferSelectorHeadline}</h2>
                <ColumnsList columns={vehicleColumns} mobileRowLength={2} />
                <CtaButton url={`${page.meta.route.prefix}local-specials/`}>
                  {vehicleOfferSelectorCTA}
                </CtaButton>
              </div>
            </AnalyticsContext>
          </Section>
        </AnalyticsInlineTrigger>
        <AnalyticsInlineTrigger
          blocks={createSectionBlock('local_offers_city_selection')}
          type={EventTypes.SubPageLoad}
        >
          <Section background="grey">
            <AnalyticsContext
              blocks={createLinkModuleBlock('local_offers_city')}
              ssrOnly
            >
              <div>
                <h2 data-size="large">{citySelectorHeadline}</h2>
                <ColumnsList columns={cityColumns} />
                <h3 data-size="small">{citySelectorFADCopy}</h3>
                <ZipCodeInput
                  analytics={{ module: 'local_offers_city' }}
                  buttonValue={citySelectorFADCTA}
                />
              </div>
            </AnalyticsContext>
          </Section>
        </AnalyticsInlineTrigger>
      </div>
      <script
        dangerouslySetInnerHTML={{
          __html: `(
                    function () {
                      function setZipCode() {
                        tcom_v2.getGeolocation().then(function (geoLocation) {
                         geoLocation.setZip(${zipcode});
                        });
                      }
                      window.addEventListener('load', function (){
                        setZipCode();
                      });
                    }
                  )()`,
        }}
      />
    </AnalyticsInlineTrigger>
  );
};

export default CityView;
