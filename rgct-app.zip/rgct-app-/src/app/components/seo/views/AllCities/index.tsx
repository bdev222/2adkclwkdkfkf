import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import useJsdsContexts from '../../../../util/useJsdsContexts';
import AnalyticsContext from '../../../shared/Analytics/AnalyticsContext';
import AnalyticsInlineTrigger from '../../../shared/Analytics/AnalyticsInlineTrigger';
import createLinkModuleBlock from '../../../shared/Analytics/blocks/createLinkModuleBlock';
import createSectionBlock from '../../../shared/Analytics/blocks/createSectionBlock';
import EventTypes from '../../../shared/Analytics/EventTypes';
import Breadcrumbs from '../../Breadcrumbs';
import ColumnsList from '../../ColumnsList';
import CtaButton from '../../CtaButton';
import CtaLink from '../../CtaLink';
import { AllCitiesContent } from '../../models';
import Section from '../../Section';
import ZipCodeInput from '../../ZipCodeInput';

type AllCitiesViewProps = AllCitiesContent;

const AllCitiesView: FC<AllCitiesViewProps> = props => {
  const {
    breadcrumbs,
    cityColumns,
    citySelectorFADCopy,
    citySelectorFADCTA,
    citySelectorHeadline,
    introCopy,
    name,
    primaryCTA,
  } = props;

  const { t } = useTranslation('seoPage');

  const { page } = useJsdsContexts();

  return (
    <AnalyticsInlineTrigger
      blocks={createSectionBlock('local_offers_all_cities')}
      type={EventTypes.PageLoad}
    >
      <div>
        <Breadcrumbs breadcrumbs={breadcrumbs} />
        <AnalyticsContext blocks={createSectionBlock('hero')} ssrOnly>
          <div>
            <Section background="white">
              <h1 data-size="large">{t('localDealsByState', { name })}</h1>
              <p>{introCopy}</p>
              <CtaButton
                analytics={{ module: 'local_offers_all_cities' }}
                url={`${page.meta.route.prefix}local-specials/`}
              >
                {primaryCTA}
              </CtaButton>
            </Section>
            <Section background="grey">
              <h2 data-size="small">{citySelectorFADCopy}</h2>
              <ZipCodeInput
                analytics={{ module: 'local_offers_all_cities' }}
                buttonValue={citySelectorFADCTA}
              />
            </Section>
          </div>
        </AnalyticsContext>
        <AnalyticsInlineTrigger
          blocks={createSectionBlock('local_offers_city_selection')}
          type={EventTypes.SubPageLoad}
        >
          <Section background="white">
            <AnalyticsContext
              blocks={createLinkModuleBlock('local_offers_all_cities')}
              ssrOnly
            >
              <div>
                <h1>{citySelectorHeadline}</h1>
                <ColumnsList columns={cityColumns} />
                <h2 data-size="medium">{t('outsideUS')}</h2>
                <CtaLink
                  target="_blank"
                  title={`${t('learnMoreInEnglish')} ${t('common:newWindow')}`}
                  url="https://global.toyota/"
                >
                  {t('learnMoreInEnglish')}
                </CtaLink>
              </div>
            </AnalyticsContext>
          </Section>
        </AnalyticsInlineTrigger>
      </div>
    </AnalyticsInlineTrigger>
  );
};

export default AllCitiesView;
