import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import OfferCard from '../OfferCard';
import { Offer } from '../OfferCard/models';
import styles from './styles.module.scss';

interface FeaturedOffersProps {
  offers: Offer[];
  tdaPrefix: string;
}

const FeaturedOffers: FC<FeaturedOffersProps> = ({ offers, tdaPrefix }) => {
  useStyles(styles);

  return (
    <div className={styles.featuredOffers}>
      {offers.map((offer, index) => (
        <OfferCard
          className={styles.offerCard}
          index={index}
          key={index}
          offer={offer}
          tdaPrefix={tdaPrefix}
        />
      ))}
    </div>
  );
};

export default FeaturedOffers;
