export const featuredOffers: string;
export const offerCard: string;
