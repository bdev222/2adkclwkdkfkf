import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import AnalyticsContext from '../../shared/Analytics/AnalyticsContext';
import createLinkBlock from '../../shared/Analytics/blocks/createLinkBlock';
import createSectionBlock from '../../shared/Analytics/blocks/createSectionBlock';
import EventTypes from '../../shared/Analytics/EventTypes';
import inlineTriggerEvent from '../../shared/Analytics/util/inlineTriggerEvent';
import { FilterColumn } from './models';
import styles from './styles.module.scss';

interface FilterProps {
  filterOptions: FilterColumn[][];
  zipCode: string;
}

const Filter: FC<FilterProps> = ({ filterOptions, zipCode }) => {
  useStyles(styles);

  const { t } = useTranslation('seoPage');

  return (
    <AnalyticsContext
      blocks={createSectionBlock('local_offers_filter')}
      ssrOnly
    >
      <div
        className={styles.filterToggle}
        role="button"
        id="mobileFilterToggle"
      >
        {t('filters')}
      </div>
      <div className={styles.filterContainer} id="filters">
        <div className={styles.locationContainer}>
          {`${t('location')} `}
          {zipCode}
        </div>
        <div className={styles.filters}>
          {filterOptions.map((filterChunk, filterChunkIndex) => (
            <div key={filterChunkIndex} className={styles.filterRow}>
              {filterChunk.map((section, sectionIndex) => (
                <div key={sectionIndex} className={styles.filterSection}>
                  <div
                    className={styles.filterSectionHeader}
                    dangerouslySetInnerHTML={{
                      __html: section.heading,
                    }}
                  />
                  {section.options.map((filter, filterIndex) => (
                    <div
                      className={cc([
                        styles.filterOption,
                        {
                          [styles.activeFilter]: filter.isSelected,
                        },
                      ])}
                      key={filterIndex}
                    >
                      <a
                        {...inlineTriggerEvent(EventTypes.Click, [
                          createLinkBlock({
                            href: filter.link,
                            text: filter.series,
                          }),
                        ])}
                        href={filter.link}
                      >
                        {filter.series}
                      </a>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
      <script
        dangerouslySetInnerHTML={{
          __html: `
            (function() {
              var filtersElem = document.getElementById('filters');
              var filterToggle = document.getElementById('mobileFilterToggle');

              if (!filtersElem || !filterToggle) {
                throw new Error('Elements not found');
              }

              filterToggle.addEventListener('click', function(event) {
                filtersElem.classList.toggle("${styles.expanded}");
                filterToggle.classList.toggle("${styles.expanded}");
              })
            })()
          `,
        }}
      />
    </AnalyticsContext>
  );
};

export default Filter;
