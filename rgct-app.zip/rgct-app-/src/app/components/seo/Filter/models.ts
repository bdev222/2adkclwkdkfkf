import {
  FilterColumn,
  FilterOption,
} from '../../../../functions/layout/transforms/seoPage/models';

export { FilterColumn, FilterOption };
