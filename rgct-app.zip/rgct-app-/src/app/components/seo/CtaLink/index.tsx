import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import createLinkBlock from '../../shared/Analytics/blocks/createLinkBlock';
import EventTypes from '../../shared/Analytics/EventTypes';
import inlineTriggerEvent from '../../shared/Analytics/util/inlineTriggerEvent';
import styles from './styles.module.scss';

interface CtaLinkProps {
  target?: string;
  title?: string;
  url: string;
}

const CtaLink: FC<CtaLinkProps> = ({
  children,
  target = '_self',
  title,
  url,
}) => {
  useStyles(styles);

  const isCrossOrigin = /^(http|\/\/)/.test(url);

  return (
    <a
      {...inlineTriggerEvent(EventTypes.Click, [
        createLinkBlock({
          href: url,
          text: typeof children === 'string' ? children : undefined,
        }),
      ])}
      className={styles.link}
      href={url}
      target={target}
      title={title}
      rel={isCrossOrigin ? 'noopener' : undefined}
    >
      {children}
    </a>
  );
};

export default CtaLink;
