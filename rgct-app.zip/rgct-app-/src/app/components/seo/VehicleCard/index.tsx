import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import AnalyticsContext from '../../shared/Analytics/AnalyticsContext';
import createSectionBlock from '../../shared/Analytics/blocks/createSectionBlock';
import OfferCard from '../OfferCard';
import { VehicleDetails } from './models';
import styles from './styles.module.scss';

interface VehicleCardProps {
  tdaPrefix: string;
  vehicle: VehicleDetails;
}

const VehicleCard: FC<VehicleCardProps> = ({ tdaPrefix, vehicle }) => {
  useStyles(styles);

  const { t } = useTranslation('seoPage');

  return (
    <div className={styles.vehicleCard}>
      <div className={styles.headline}>
        <h1 className={styles.header}>
          {t('seriesDeals', { series: vehicle.name })}
        </h1>
        <span className={styles.offerCount}>
          {t('offersAvailable', { count: vehicle.offers.length })}
        </span>
      </div>
      <div className={styles.heroContainer}>
        <figure className={styles.vehicleFigure}>
          <img
            alt="Background"
            className={styles.vehicleBackground}
            src={vehicle.backgroundImage}
          />
          <img
            alt={vehicle.name}
            className={styles.vehicleJelly}
            src={vehicle.image}
          />
          <figcaption>{vehicle.jellyText}</figcaption>
        </figure>
      </div>
      <AnalyticsContext
        blocks={createSectionBlock('local_offers_offer_overview')}
        ssrOnly
      >
        <div className={styles.vehicleOffers}>
          {vehicle.offers.map((offer, index) => (
            <OfferCard
              index={index}
              key={offer.id}
              offer={offer}
              tdaPrefix={tdaPrefix}
            />
          ))}
        </div>
      </AnalyticsContext>
    </div>
  );
};

export default VehicleCard;
