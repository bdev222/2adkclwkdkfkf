import { VehicleDetails } from '../../../../functions/layout/transforms/seoPage/models';

export { VehicleDetails };
