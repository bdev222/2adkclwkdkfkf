export const displayModule: string;
export const textContainer: string;
export const imageLeft: string;
export const imageRight: string;
export const header: string;
export const description: string;
export const image: string;
