import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import CtaLink from '../CtaLink';
import styles from './styles.module.scss';

interface DisplayModuleProps {
  copy: string;
  cta: {
    url: string;
    target: string;
    text: string;
  };
  headline: string;
  img: string;
  imgSide: 'left' | 'right';
}

const DisplayModule: FC<DisplayModuleProps> = ({
  copy,
  cta,
  headline,
  img,
  imgSide,
}) => {
  useStyles(styles);

  return (
    <figure
      className={cc([
        styles.displayModule,
        {
          [styles.imageLeft]: imgSide === 'left',
          [styles.imageRight]: imgSide === 'right',
        },
      ])}
    >
      <img className={styles.image} src={img} alt={headline} />
      <figcaption className={styles.textContainer}>
        <h3 className={styles.header}>{headline}</h3>
        <p className={styles.description}>{copy}</p>
        <CtaLink url={cta.url} target={cta.target}>
          {cta.text}
        </CtaLink>
      </figcaption>
    </figure>
  );
};

export default DisplayModule;
