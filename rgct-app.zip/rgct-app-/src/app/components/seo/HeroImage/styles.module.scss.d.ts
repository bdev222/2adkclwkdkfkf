export const heroImage: string;
export const image: string;
