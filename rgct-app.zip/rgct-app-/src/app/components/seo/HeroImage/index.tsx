import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import styles from './styles.module.scss';

interface HeroImageProps {
  alt?: string;
  src: string;
}

const HeroImage: FC<HeroImageProps> = ({ alt = '', src }) => {
  useStyles(styles);

  return (
    <div className={styles.heroImage}>
      <img className={styles.image} src={src} alt={alt} />
    </div>
  );
};

export default HeroImage;
