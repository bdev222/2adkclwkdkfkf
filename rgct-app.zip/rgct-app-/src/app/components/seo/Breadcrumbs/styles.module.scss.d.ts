export const breadcrumbs: string;
export const breadcrumb: string;
