import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import { Breadcrumb } from '../../../../functions/layout/transforms/seoPage/models';
import styles from './styles.module.scss';

interface BreadcrumbProps {
  breadcrumbs: Breadcrumb[];
}

const Breadcrumbs: FC<BreadcrumbProps> = ({ breadcrumbs }) => {
  useStyles(styles);

  return (
    <div className={styles.breadcrumbs}>
      {breadcrumbs.map(crumb => (
        <span className={styles.breadcrumb} key={crumb.url}>
          <a href={crumb.url}>{crumb.label}</a>
        </span>
      ))}
    </div>
  );
};

export default Breadcrumbs;
