import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import Filter from '../Filter';
import { FilterColumn } from '../Filter/models';
import VehicleCard from '../VehicleCard';
import { VehicleDetails } from '../VehicleCard/models';
import styles from './styles.module.scss';

interface OffersProps {
  filterOptions: FilterColumn[][];
  tdaPrefix: string;
  vehicles: VehicleDetails[];
  zipCode: string;
}

const Offers: FC<OffersProps> = ({
  filterOptions,
  tdaPrefix,
  vehicles,
  zipCode,
}) => {
  useStyles(styles);

  return (
    <section className={styles.container}>
      <div className={styles.component}>
        <div className={styles.filter}>
          <Filter filterOptions={filterOptions} zipCode={zipCode} />
        </div>
        <div className={styles.viewer}>
          {vehicles.map(vehicle => (
            <VehicleCard
              key={vehicle.id}
              tdaPrefix={tdaPrefix}
              vehicle={vehicle}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Offers;
