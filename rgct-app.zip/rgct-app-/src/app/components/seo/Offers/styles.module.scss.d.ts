export const container: string;
export const component: string;
export const filter: string;
export const viewer: string;
