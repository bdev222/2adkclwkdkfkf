import { Column } from '../../../../functions/layout/transforms/seoPage/models';

export { Column };
