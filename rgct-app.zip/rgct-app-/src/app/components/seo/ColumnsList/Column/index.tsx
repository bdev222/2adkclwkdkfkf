import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import createLinkBlock from '../../../shared/Analytics/blocks/createLinkBlock';
import createListItemBlock from '../../../shared/Analytics/blocks/createListItemBlock';
import EventTypes from '../../../shared/Analytics/EventTypes';
import inlineTriggerEvent from '../../../shared/Analytics/util/inlineTriggerEvent';
import { Column as IColumn } from '../models';
import styles from './styles.module.scss';

interface ColumnProps {
  column: IColumn;
  index: number;
  mobileRowLength?: number;
}

const Column: FC<ColumnProps> = ({ column, index, mobileRowLength }) => {
  useStyles(styles);
  const { heading, links } = column;
  return (
    <>
      <div key={index} className={styles.column}>
        {heading && (
          <h4
            className={styles.header}
            dangerouslySetInnerHTML={{ __html: heading }}
          />
        )}
        {links.map((link, linkIndex) => (
          <a
            {...inlineTriggerEvent(EventTypes.Click, [
              createLinkBlock({ href: link.url, text: link.label }),
              createListItemBlock(linkIndex),
            ])}
            className={styles.link}
            href={link.url}
            key={linkIndex}
          >
            {link.label}
          </a>
        ))}
      </div>
      {mobileRowLength && (index + 1) % mobileRowLength === 0 && (
        <hr className={styles.divider} />
      )}
    </>
  );
};

export default Column;
