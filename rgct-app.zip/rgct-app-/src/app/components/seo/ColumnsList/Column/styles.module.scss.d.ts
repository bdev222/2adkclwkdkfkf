export const column: string;
export const divider: string;
export const header: string;
export const link: string;
