export const columnsContainer: string;
export const dividedContainer: string;
