import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import Column from './Column';
import { Column as IColumn } from './models';
import styles from './styles.module.scss';

interface ColumnsListProps {
  columns: IColumn[];
  mobileRowLength?: number;
}

const ColumnsList: FC<ColumnsListProps> = ({ columns, mobileRowLength }) => {
  useStyles(styles);

  return (
    <div
      className={cc([
        styles.columnsContainer,
        { [styles.dividedContainer]: !!mobileRowLength },
      ])}
    >
      {columns.map((column, columnIndex) => (
        <Column
          column={column}
          index={columnIndex}
          key={columnIndex}
          mobileRowLength={mobileRowLength}
        />
      ))}
    </div>
  );
};

export default ColumnsList;
