import { SeoFieldsType } from '../../../../functions/layout/transforms/seoPage/models';

export { SeoFieldsType };
