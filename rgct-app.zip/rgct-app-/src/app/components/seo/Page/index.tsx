import { JSDSRendering } from 'jsds-react';
import React, { FC } from 'react';
import Helmet from 'react-helmet';

import useJsdsContexts from '../../../util/useJsdsContexts';
import AnalyticsContext from '../../shared/Analytics/AnalyticsContext';
import AllCitiesView from '../views/AllCities';
import CityView from '../views/City';
import NationalView from '../views/National';
import OffersView from '../views/Offers';
import StateView from '../views/State';
import VehicleView from '../views/Vehicle';
import VehicleOffersView from '../views/VehicleOffers';
import analyticsInitScript from './analyticsInitScript.html';
import analyticsUtilScript from './analyticsUtilScript.html';
import analyticsWaypointScript from './analyticsWaypointScript.html';
import { SeoFieldsType } from './models';

type SeoPageProps = JSDSRendering<SeoFieldsType>;

const SeoPage: FC<SeoPageProps> = ({ fields }) => {
  const { page } = useJsdsContexts();

  return (
    <>
      <Helmet>
        <title>{fields.meta.title}</title>
        <meta name="description" content={fields.meta.description} />
        <meta name="keywords" content={fields.meta.keywords} />
        <link rel="canonical" href={fields.meta.canonical} />
      </Helmet>

      <div
        dangerouslySetInnerHTML={{
          __html: [
            // Order is important here. The util scripts must come first, and
            // the waypoints script must come before the init scripts.
            analyticsUtilScript,
            analyticsWaypointScript,
            analyticsInitScript,
          ].join(''),
        }}
      />

      <AnalyticsContext blocks={{ language: page.meta.route.lang }} ssrOnly>
        <div>
          {(() => {
            switch (fields.view) {
              case 'allCities':
                return <AllCitiesView {...fields.content} />;
              case 'city':
                return <CityView {...fields.content} />;
              case 'national':
                return <NationalView {...fields.content} />;
              case 'offers':
                return <OffersView {...fields.content} />;
              case 'state':
                return <StateView {...fields.content} />;
              case 'vehicle':
                return <VehicleView {...fields.content} />;
              case 'vehicleOffers':
                return <VehicleOffersView {...fields.content} />;
              default:
                return null;
            }
          })()}
        </div>
      </AnalyticsContext>
    </>
  );
};

export default SeoPage;
