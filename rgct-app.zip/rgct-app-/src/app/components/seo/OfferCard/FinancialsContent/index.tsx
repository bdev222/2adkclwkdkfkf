import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import { OfferCard } from '../models';
import styles from './styles.module.scss';

interface FinancialsContentProps {
  offer: OfferCard;
}

const FinancialsContent: FC<FinancialsContentProps> = ({ offer }) => {
  useStyles(styles);

  const { t } = useTranslation();

  switch (offer.type) {
    case 'apr': {
      return (
        <ul className={styles.container}>
          <li>
            {offer.apr.rate}%<span>{t('aprAbbr')}.</span>
          </li>
          <li>
            {offer.apr.duration}
            <span>{t('monthsAbbr')}</span>
          </li>
        </ul>
      );
    }
    case 'cash': {
      const cashAmount = parseInt(offer.cash.cashAmount, 10);

      return !isNaN(cashAmount) ? (
        <ul className={styles.container}>
          <li>
            ${cashAmount.toLocaleString()}
            <span>{offer.cash.label}</span>
          </li>
        </ul>
      ) : null;
    }
    case 'lease': {
      const dueAtSigning = parseInt(offer.lease.dueAtSigning, 10);

      return !isNaN(dueAtSigning) ? (
        <ul className={styles.container}>
          <li>
            ${offer.lease.monthlyPayment}
            <span>/ {t('monthAbbr')}</span>
          </li>
          <li>
            {offer.lease.duration}
            <span>{t('monthsAbbr')}</span>
          </li>
          <li>
            ${parseInt(offer.lease.dueAtSigning, 10).toLocaleString()}
            <span>{t('dueAtSigning')}</span>
          </li>
        </ul>
      ) : null;
    }
    case 'multiVehicle': {
      return (
        <ul className={styles.container}>
          <li>
            ${parseInt(offer.multiVehicle.cashAmount, 10).toLocaleString()}
            <span>{offer.multiVehicle.label}</span>
          </li>
        </ul>
      );
    }
    default:
      return null;
  }
};

export default FinancialsContent;
