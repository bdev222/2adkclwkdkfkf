import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import AnalyticsContext from '../../shared/Analytics/AnalyticsContext';
import createLinkBlock from '../../shared/Analytics/blocks/createLinkBlock';
import createListItemBlock from '../../shared/Analytics/blocks/createListItemBlock';
import createOfferBlock from '../../shared/Analytics/blocks/createOfferBlock';
import createSeriesBlock from '../../shared/Analytics/blocks/createSeriesBlock';
import EventTypes from '../../shared/Analytics/EventTypes';
import inlineTriggerEvent from '../../shared/Analytics/util/inlineTriggerEvent';
import CardImage from './CardImage';
import FinancialsContent from './FinancialsContent';
import { Offer } from './models';
import styles from './styles.module.scss';

interface OfferCardProps {
  className?: string;
  index: number;
  offer: Offer;
  tdaPrefix: string;
}

const OfferCard: FC<OfferCardProps> = ({
  className,
  index,
  offer,
  tdaPrefix,
}) => {
  const {
    bonusTag,
    cardImage,
    description,
    endDate,
    id,
    includedTrim,
    offerTitle,
    primaryLabel,
    ribbon,
    secondaryLabel,
    series,
    seriesOrCardTitle,
    trimLabel,
    type,
  } = offer;

  useStyles(styles);

  const { t } = useTranslation('offer');

  const cardLink = `${tdaPrefix}/deals-incentives/${id}/`;

  let seriesBlock;

  if (includedTrim) {
    seriesBlock = {
      seriesName: series[0].name[0],
      trimLabel: includedTrim,
      year: series[0].year,
    };
  }

  return (
    <AnalyticsContext
      blocks={[
        createListItemBlock(index),
        createOfferBlock(offer),
        seriesBlock ? createSeriesBlock(seriesBlock) : {},
        createLinkBlock({ href: cardLink, text: 'View Details' }),
      ]}
      ssrOnly
    >
      <a
        {...inlineTriggerEvent(EventTypes.Click, [
          createLinkBlock({ href: cardLink, text: 'View Details' }),
          createListItemBlock(index),
        ])}
        href={cardLink}
        className={cc([styles.container, className])}
      >
        <div
          className={cc([
            styles.ribbonAndLabels,
            { [styles.isColumn]: secondaryLabel },
          ])}
        >
          <span
            className={cc([
              styles.ribbon,
              { [styles.isHiddenMobile]: !secondaryLabel },
            ])}
          >
            {ribbon}
          </span>
          <span className={styles.offerLabelsContainer}>
            <span className={styles.offerLabels}>
              <span className={styles.primaryLabel} data-type={type}>
                {primaryLabel}
                {secondaryLabel ? (
                  <span className={styles.secondaryLabel}>
                    {secondaryLabel}
                  </span>
                ) : (
                  <span className={styles.inlineMobileRibbon}>{ribbon}</span>
                )}
              </span>
            </span>
          </span>
        </div>
        <div className={styles.content}>
          <div className={styles.subHeading}>
            <div
              className={cc([
                styles.seriesOrCardTitle,
                { [styles.hasImage]: cardImage },
              ])}
            >
              {seriesOrCardTitle}
            </div>

            {offerTitle && (
              <div className={styles.offerHeading}>{offerTitle}</div>
            )}
          </div>
          {cardImage && <CardImage alt={cardImage.alt} src={cardImage.src} />}
          <FinancialsContent offer={offer} />
        </div>
        <div className={styles.bonusDescriptionTrimContainer}>
          {bonusTag && <div className={styles.bonusTag}>{bonusTag}</div>}
          {trimLabel && <div className={styles.trim}>{trimLabel}</div>}
          {description && (
            <div className={styles.description}>{description}</div>
          )}
        </div>
        <footer className={styles.footer}>
          <span className={styles.viewDetails}>{t('viewDetails')}</span>
          <span className={styles.endDate}>{t('expiration', endDate)}</span>
        </footer>
      </a>
    </AnalyticsContext>
  );
};

export default OfferCard;
