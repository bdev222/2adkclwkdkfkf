import { Offer } from '../../../../functions/layout/transforms/seoPage/models';
import { OfferBase } from '../../../../functions/layout/transforms/util/getOffers/models';

type OfferCardProps =
  | 'bonusTag'
  | 'cardImage'
  | 'description'
  | 'endDate'
  | 'id'
  | 'includedTrim'
  | 'primaryLabel'
  | 'ribbon'
  | 'secondaryLabel'
  | 'series'
  | 'seriesOrCardTitle'
  | 'trimLabel';

type OfferCard = OfferBase & Pick<Offer, OfferCardProps>;

export { Offer, OfferCard };
