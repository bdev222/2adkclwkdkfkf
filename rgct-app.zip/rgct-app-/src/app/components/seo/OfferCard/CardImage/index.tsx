import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import styles from './styles.module.scss';

interface CardImageProps {
  alt: string;
  src: string;
}

const CardImage: FC<CardImageProps> = ({ alt, src }) => {
  useStyles(styles);

  return (
    <div className={styles.container}>
      <img alt={alt} className={styles.specialImg} src={src} />
    </div>
  );
};

export default CardImage;
