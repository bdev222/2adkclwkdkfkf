export const container: string;
export const specialImg: string;
