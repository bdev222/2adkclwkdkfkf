export const buttonLink: string;
export const hoverAnimation: string;
