import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import createLinkBlock from '../../shared/Analytics/blocks/createLinkBlock';
import createLinkModuleBlock from '../../shared/Analytics/blocks/createLinkModuleBlock';
import EventTypes from '../../shared/Analytics/EventTypes';
import inlineTriggerEvent from '../../shared/Analytics/util/inlineTriggerEvent';
import styles from './styles.module.scss';

interface CtaButtonProps {
  analytics?: {
    km?: string;
    module?: string;
  };
  buttonId?: string;
  url: string;
}

const CtaButton: FC<CtaButtonProps> = ({
  analytics: { km, module } = {},
  buttonId,
  url,
  children,
}) => {
  useStyles(styles);

  const isCrossOrigin = /^(http|\/\/)/.test(url);

  return (
    <a
      {...inlineTriggerEvent(EventTypes.Click, [
        createLinkBlock({
          href: url,
          text: typeof children === 'string' ? children : undefined,
          metrics: km,
        }),
        module ? createLinkModuleBlock(module) : {},
      ])}
      className={styles.buttonLink}
      href={url}
      id={buttonId}
      rel={isCrossOrigin ? 'noopener' : undefined}
    >
      {children}
    </a>
  );
};

export default CtaButton;
