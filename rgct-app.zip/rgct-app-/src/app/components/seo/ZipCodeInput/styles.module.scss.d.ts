export const zipCodeInput: string;
export const input: string;
