import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import useJsdsContexts from '../../../util/useJsdsContexts';
import CtaButton from '../CtaButton';
import styles from './styles.module.scss';

interface ZipCodeInputProps {
  analytics?: {
    km?: string;
    module?: string;
  };
  buttonValue: string;
}

const ZipCodeInput: FC<ZipCodeInputProps> = ({ analytics, buttonValue }) => {
  useStyles(styles);

  const {
    page: {
      meta: {
        route: { prefix },
      },
    },
  } = useJsdsContexts();

  const { t } = useTranslation('common');

  const timestamp = new Date().getTime();

  return (
    <label className={styles.zipCodeInput}>
      <input
        className={styles.input}
        id={`zipCodeInputElement-${timestamp}`}
        inputMode="numeric"
        maxLength={5}
        pattern="[0-9]*"
        placeholder={t('zipCode').toUpperCase()}
        role="textbox"
        type="text"
      />
      <CtaButton
        analytics={analytics}
        buttonId={`zipCodeSubmit-${timestamp}`}
        url={`${prefix}dealers/`}
      >
        {buttonValue}
      </CtaButton>
      <script
        dangerouslySetInnerHTML={{
          __html: `(
            function () {
              var inputElement = document.getElementById("zipCodeInputElement-${timestamp}");

              var submitButton = document.getElementById("zipCodeSubmit-${timestamp}");

              function setZipCodeAndForward(event) {
                event.preventDefault();

                var url = event.currentTarget.getAttribute('href');

                var userZipCode = inputElement.value;

                tcom_v2.getGeolocation().then(function (geoLocation) {
                  geoLocation.setZip(userZipCode);

                  location.assign(url);
                });
              }

              submitButton.addEventListener('click', setZipCodeAndForward);

              function handleZipcodeChange(event) {
                event.currentTarget.value = event.currentTarget.value.replace(/[^0-9]/g, '');
              };

              inputElement.addEventListener('keyup', handleZipcodeChange);
            }
      )()`,
        }}
      />
    </label>
  );
};

export default ZipCodeInput;
