import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import styles from './styles.module.scss';

interface SectionProps {
  background: 'grey' | 'white';
}

const Section: FC<SectionProps> = ({ background = 'white', children }) => {
  useStyles(styles);

  return (
    <section className={styles.section} data-bg={background}>
      {children}
    </section>
  );
};

export default Section;
