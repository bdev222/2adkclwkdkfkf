import {
  AllCitiesContent,
  CityContent,
  NationalContent,
  OffersContent,
  StateContent,
  VehicleContent,
  VehicleOffersContent,
} from '../../../functions/layout/transforms/seoPage/models';

export {
  AllCitiesContent,
  CityContent,
  NationalContent,
  OffersContent,
  StateContent,
  VehicleContent,
  VehicleOffersContent,
};
