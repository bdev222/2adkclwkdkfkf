import { registerJSDSComponents } from 'jsds-react';

import ErrorBoundary from '../shared/ErrorBoundary';
import SeoPage from './Page';

export default registerJSDSComponents({
  errorBoundary: ErrorBoundary,
  seoPage: SeoPage,
});
