import i18n from 'i18next';
import XHR from 'i18next-xhr-backend';
import { Dictionaries } from 'jsds-lambda';
import { initReactI18next } from 'react-i18next';

import interpolateTranslation from '../../util/interpolateTranslation';

export default function i18nInit(
  language?: string,
  dictionaries?: Dictionaries,
  allowPartialBundles = true
) {
  return new Promise((resolve, reject) => {
    const options: i18n.InitOptions = {
      backend: {
        customHeaders: {
          'x-api-key': `${process.env.RGCT_REST_APIKEY}`,
        },
        loadPath: '/rgct/api/dictionary/{{lng}}/{{ns}}',
        parse: (data: string) => {
          const parsedData = JSON.parse(data);
          return parsedData.phrases ? parsedData.phrases : parsedData;
        },
      },
      debug: false,
      defaultNS: 'common',
      fallbackLng: false,
      interpolation: {
        escapeValue: false, // not needed for react
        format: interpolateTranslation,
      },
      lng: language,
      load: 'currentOnly',
      partialBundledLanguages: allowPartialBundles,
      ns: dictionaries ? Object.keys(dictionaries) : [],
      react: {
        useSuspense: false,
      },
    };

    const initCallback = (error?: Error) => {
      if (error) {
        reject(error);
        return;
      }
      resolve();
    };

    if (dictionaries && language) {
      options.resources = {
        [language]: dictionaries,
      };
    }

    i18n.use(initReactI18next).use(XHR).init(options, initCallback);
  });
}
