declare module 'float-sidebar';
declare module 'intersection-observer';
declare module 'isomorphic-style-loader/StyleContext';
declare module 'isomorphic-style-loader/useStyles';
declare module 'isomorphic-style-loader/withStyles';
declare module 'react-amphtml';
declare module 'react-amphtml/setup';
declare module 'url-search-params-polyfill';
