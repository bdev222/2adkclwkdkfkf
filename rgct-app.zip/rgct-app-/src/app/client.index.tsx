import { loadableReady } from '@loadable/component';
import StyleContext from 'isomorphic-style-loader/StyleContext';
import { Dictionaries } from 'jsds-lambda';
import { JSDSProvider } from 'jsds-react';
import React from 'react';
import ReactDOM from 'react-dom';
import { useSSR } from 'react-i18next';
import { BrowserRouter } from 'react-router-dom';

import AppRoot from './AppRoot';
import i18ninit from './i18n';
import componentFactory from './renderings/html/factory';
import { setServerSideRenderingState } from './routing/RouteHandler';
import baseStyles from './styles/html5/app.scss';

let renderFunction = ReactDOM.render;

let ClientAppRoot = AppRoot;

let i18nOptions: [string?, Dictionaries?] = [];

const loadPolyfills = async () => {
  const promises = [];

  if (typeof window.URLSearchParams === 'undefined') {
    promises.push(import('url-search-params-polyfill'));
  }

  if (typeof window.IntersectionObserver === 'undefined') {
    promises.push(import('intersection-observer'));
  }

  return Promise.all(promises);
};

/*
  SSR Data
  If we're running in a server-side rendering scenario,
  the server will provide the window.__SSR_STATE__ object
  for us to acquire the initial state to run with on the client.

  This enables us to skip a network request to load up the layout data.
*/
if (window.__SSR_STATE__) {
  // push the initial SSR state into the route handler, where it will be used
  setServerSideRenderingState(window.__SSR_STATE__);

  // when React initializes from a SSR-based initial state, you need to render with `hydrate` instead of `render`
  renderFunction = ReactDOM.hydrate;
}

if (window.__SSR_I18N__) {
  const { lang, dictionaries } = window.__SSR_I18N__;

  i18nOptions = [lang, dictionaries[lang]];

  ClientAppRoot = props => {
    useSSR(dictionaries, lang);
    return <AppRoot {...props} />;
  };
}

// initialize the dictionary, then render the app
i18ninit(...i18nOptions).then(async () => {
  // HTML element to place the app into
  const rootElement = document.getElementById('root');

  const insertCss = (...styles: any[]) => {
    const removeCss = styles.map(style => style._insertCss());
    return () => removeCss.forEach(dispose => dispose());
  };

  await Promise.all([loadPolyfills(), loadableReady()]);

  renderFunction(
    <StyleContext.Provider value={{ insertCss }}>
      <JSDSProvider componentFactory={componentFactory}>
        <ClientAppRoot
          path={window.location.pathname}
          Router={BrowserRouter}
          styles={baseStyles}
        />
      </JSDSProvider>
    </StyleContext.Provider>,
    rootElement
  );
});
