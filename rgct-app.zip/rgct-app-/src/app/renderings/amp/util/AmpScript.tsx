import * as React from 'react';
import Helmet from 'react-helmet';

interface AmpScriptProps {
  'custom-element': string;
  src: string;
}

export default (props: AmpScriptProps) => (
  <Helmet>
    <script async {...props} />
  </Helmet>
);
