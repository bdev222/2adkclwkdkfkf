import { JSDSPlaceholder, JSDSRendering } from 'jsds-react';
import { get } from 'lodash';
import React, { FC } from 'react';
import Helmet from 'react-helmet';
import { useTranslation } from 'react-i18next';

import useJsdsContexts from '../../../util/useJsdsContexts';

type LayoutProps = JSDSRendering<{
  page: string;
}>;

const Layout: FC<LayoutProps> = ({ fields, placeholders }) => {
  const { t } = useTranslation();

  const { page } = useJsdsContexts();

  return (
    <>
      {/* react-helmet enables setting <head> contents, like title and OG meta tags */}
      <Helmet titleTemplate={`%s | ${t('siteTitle')}`}>
        <title>{page.title || t('defaultPageTitle')}</title>
        <meta
          name="description"
          content={get(page, 'meta.route.fields.pageDescription.value', '')}
        />
        <meta
          name="keywords"
          content={get(page, 'meta.route.fields.keywords.value', '')}
        />
      </Helmet>

      <div>
        <h1>Layout (AMP)</h1>
        <p>{`You are hitting the page ${fields.page}`}</p>
        <p>Below is an example of a placeholder</p>
        {placeholders.content && (
          <JSDSPlaceholder components={placeholders.content} />
        )}
      </div>
    </>
  );
};

export default Layout;
