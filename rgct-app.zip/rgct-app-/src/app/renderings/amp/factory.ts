import { registerJSDSComponents } from 'jsds-react';

import Content from './Content';
import Layout from './Layout';

export default registerJSDSComponents({
  Content,
  Layout,
});
