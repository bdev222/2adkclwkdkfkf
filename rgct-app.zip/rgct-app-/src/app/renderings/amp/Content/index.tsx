import { JSDSRendering } from 'jsds-react';
import React, { FC } from 'react';

type ContentProps = JSDSRendering<{
  text: string;
}>;

const Content: FC<ContentProps> = ({ fields }) => {
  return (
    <div>
      <h3>I am a content component</h3>
      <p>{fields.text}</p>
    </div>
  );
};

export default Content;
