export const container: string;
export const content: string;
