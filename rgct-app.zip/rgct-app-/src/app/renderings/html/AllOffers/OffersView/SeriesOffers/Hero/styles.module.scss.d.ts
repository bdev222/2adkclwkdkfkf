export const container: string;
export const backgroundImages: string;
export const content: string;
export const description: string;
export const badges: string;
export const jelly: string;
