import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import LazyImage from '../../../../../../components/html5/LazyImage';
import { BackgroundImages, Badge, Jelly } from '../../../models';
import styles from './styles.module.scss';

interface HeroProps {
  badges?: Badge[];
  bgImages?: BackgroundImages;
  jelly?: Jelly;
  seriesName: string;
}

const Hero: FC<HeroProps> = ({ badges, bgImages, jelly, seriesName }) => {
  useStyles(styles);

  const { t } = useTranslation();

  const jellyDescription = t('jellyDescription', {
    color: jelly?.color,
    name: seriesName,
    trim: jelly?.trim,
    year: jelly?.year,
  });

  return (
    <div className={styles.container}>
      {bgImages && (
        <div className={styles.backgroundImages}>
          <picture>
            <source srcSet={bgImages.mobile} media="(max-width: 767px)" />
            <LazyImage alt="" role="presentation" src={bgImages.desktop} />
          </picture>
        </div>
      )}
      <div className={styles.content}>
        {jelly && (
          <>
            <div
              className={styles.description}
              dangerouslySetInnerHTML={{ __html: jellyDescription }}
            />
            <div className={styles.jelly}>
              <LazyImage
                alt={jellyDescription}
                placeholderStyles={{ width: '100%', height: '100%' }}
                src={jelly.image}
              />
            </div>
          </>
        )}
        <div className={styles.badges}>
          {badges?.map((badge, index) => (
            <LazyImage src={badge.image} alt={badge.description} key={index} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Hero;
