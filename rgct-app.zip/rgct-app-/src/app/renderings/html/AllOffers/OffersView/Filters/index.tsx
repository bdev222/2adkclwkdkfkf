import React, { Dispatch, FC, SetStateAction, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { useHistory } from 'react-router';

import AnalyticsContext from '../../../../../components/shared/Analytics/AnalyticsContext';
import createSectionBlock from '../../../../../components/shared/Analytics/blocks/createSectionBlock';
import { QueryParams } from '../../../../../util/QueryParams';
import useJsdsContexts from '../../../../../util/useJsdsContexts';
import Filters from '../../../Filters';
import { OnFilterChange } from '../../../Filters/models';
import { OffersView } from '../../models';
import saveFiltersState from '../util/saveFiltersState';

interface FiltersProps {
  didFetchAllOffers: OffersView['didFetchAllOffers'];
  filters: OffersView['filters'];
  offersCount: number;
  preselectedFilters: OffersView['preselectedFilters'];
  setIsLoadingOffers: Dispatch<SetStateAction<boolean>>;
}

const VANITY_PARAM_REGEX = /([\w]+family|gr-supra|grsupra)/g;

const AllOffersFilters: FC<FiltersProps> = ({
  didFetchAllOffers,
  filters,
  offersCount,
  preselectedFilters,
  setIsLoadingOffers,
}) => {
  const history = useHistory();
  const { page } = useJsdsContexts();

  const { t } = useTranslation('allOffers');

  const filterParams = useRef(
    new QueryParams('offers[]', 'viewAllOffers', 'vehicles[]', 'years[]')
  );

  useEffect(() => {
    for (const [key, values] of Object.entries(preselectedFilters)) {
      if (values) {
        for (const value of values) {
          filterParams.current.set(key, value);
        }
      }
    }

    saveFiltersState(filterParams.current);
  }, [preselectedFilters]);

  const hasNoFilters = () =>
    filterParams.current.get('offers').length === 0 &&
    filterParams.current.get('vehicles').length === 0 &&
    filterParams.current.get('years').length === 0;

  const handleFilterChange: OnFilterChange = ({
    categoryId,
    name,
    newValue,
  }) => {
    const key =
      categoryId === 'offerType'
        ? 'offers'
        : categoryId === 'years'
        ? 'years'
        : 'vehicles';

    if (newValue) {
      filterParams.current.set(key, name);
    } else {
      filterParams.current.unset(key, name);
    }

    if (key === 'vehicles') {
      const vanityParams = filterParams.current.searchParams
        .get(key)
        ?.match(VANITY_PARAM_REGEX);

      // prettier ignore to keep // NOSONAR on same line
      // prettier-ignore
      vanityParams?.forEach(vanity => { // NOSONAR
        filterParams.current.unset(key, vanity);
      });
    }

    saveFiltersState(filterParams.current);

    updateRoute();
  };

  const handleFiltersClear = () => {
    // If we don't have any filters then don't do anything. This avoids an issue
    // where hitting "Clear" on empty filters will show the loading overlay.
    if (hasNoFilters()) {
      return;
    }

    filterParams.current.clear('offers', 'vehicles', 'years');

    saveFiltersState(filterParams.current);

    updateRoute();
  };

  const updateRoute = () => {
    const { prefix } = page.meta.route;

    if (hasNoFilters()) {
      filterParams.current.set('viewAllOffers', '1');
    } else {
      filterParams.current.unset('viewAllOffers');
    }

    setIsLoadingOffers(true);

    history.push(`${prefix}/deals-incentives/?${filterParams.current}`, {
      resetScroll: false,
      showLoadingOverlay: false,
    });
  };

  return (
    <AnalyticsContext blocks={createSectionBlock('offers_filter')}>
      <Filters
        ariaLabel="All offers filter"
        didFetchAllOffers={didFetchAllOffers}
        filters={filters}
        filtersCount={filterParams.current.get('vehicles').length}
        filtersCountLabel={t('selectedVehicles')}
        offersCount={offersCount}
        onChange={handleFilterChange}
        onClear={handleFiltersClear}
      />
    </AnalyticsContext>
  );
};

export default AllOffersFilters;
