export const button: string;
export const isShowing: string;
export const isAbsolute: string;
export const intersection: string;
