export const offers: string;
