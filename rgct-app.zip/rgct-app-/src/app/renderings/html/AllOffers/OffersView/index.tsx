import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useCallback, useEffect, useRef, useState } from 'react';

import LoadingContent from '../../../../components/html5/LoadingContent';
import AnalyticsContext from '../../../../components/shared/Analytics/AnalyticsContext';
import createKeyMetricsBlock from '../../../../components/shared/Analytics/blocks/createKeyMetricsBlock';
import createOffersListBlock from '../../../../components/shared/Analytics/blocks/createOffersListBlock';
import createSectionBlock from '../../../../components/shared/Analytics/blocks/createSectionBlock';
import createSeriesBlock from '../../../../components/shared/Analytics/blocks/createSeriesBlock';
import createSupressPageLoadBlock from '../../../../components/shared/Analytics/blocks/createSuppressPageLoadBlock';
import EventTypes from '../../../../components/shared/Analytics/EventTypes';
import RootAnalyticsContext from '../../../../components/shared/Analytics/RootAnalyticsContext';
import useTrigger from '../../../../components/shared/Analytics/useTrigger';
import getDeviceType from '../../../../util/getDeviceType';
import { QueryParams } from '../../../../util/QueryParams';
import { OffersView as IOffersView } from '../models';
import Filters from './Filters';
import ScrollToTop from './ScrollToTop';
import SeriesOffers from './SeriesOffers';
import SpecialOffers from './SpecialOffers';
import styles from './styles.module.scss';

type OffersViewProps = IOffersView;

const OffersView: FC<OffersViewProps> = ({
  allSeries,
  ctas,
  didFetchAllOffers,
  filters,
  targetFilterYear,
  totalOffersCount,
  preselectedFilters,
  specialOffers,
}) => {
  useStyles(styles);

  const trigger = useTrigger();

  useEffect(() => {
    trigger(EventTypes.KmPageLoad, [
      createKeyMetricsBlock('km-offers-search'),
      createSectionBlock('offers'),
      allSeries.length === 1 ? createSeriesBlock(allSeries[0]) : {},
    ]);
  }, []);

  const getOffersListBlock = useCallback(() => {
    const filterParams = new QueryParams('offers[]', 'vehicles[]', 'years[]');

    const filtersString = [
      ...filterParams.get('vehicles'),
      ...filterParams.get('offers'),
      ...filterParams.get('years'),
    ].join(',');

    return createOffersListBlock(filtersString);
  }, [filters]);

  const [isLoadingOffers, setIsLoadingOffers] = useState(false);

  const sidebar = useRef<HTMLDivElement>(null);
  const content = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    let destroy = () => {}; // NOSONAR

    (async () => {
      const deviceType = getDeviceType();

      if (deviceType === 'desktop') {
        const FloatSidebar = (await import('float-sidebar')).default;

        const floatSidebar = FloatSidebar({
          bottomSpacing: 20,
          relative: content.current,
          sidebar: sidebar.current,
          topSpacing: 65, // Match height of sticky <nav> element
        });

        floatSidebar.forceUpdate();

        destroy = floatSidebar.destroy;
      }
    })();

    return () => destroy();
  }, []);

  useEffect(() => {
    setIsLoadingOffers(false);
  }, [filters]);

  return (
    <RootAnalyticsContext
      blocks={[createSectionBlock('offers'), createSupressPageLoadBlock()]}
    >
      <AnalyticsContext blocks={getOffersListBlock}>
        <div className={styles.container}>
          <aside className={styles.sidebar} ref={sidebar}>
            <div className="sidebar__inner">
              <Filters
                didFetchAllOffers={didFetchAllOffers}
                filters={filters}
                offersCount={totalOffersCount}
                preselectedFilters={preselectedFilters}
                setIsLoadingOffers={setIsLoadingOffers}
              />
            </div>
          </aside>
          <div className={styles.offersContainer} ref={content}>
            <ScrollToTop>
              <LoadingContent isLoading={isLoadingOffers}>
                {allSeries.map((series, index) => (
                  <div
                    className={cc([
                      styles.series,
                      {
                        [styles.hasDivider]:
                          specialOffers?.length || index < allSeries.length - 1,
                      },
                    ])}
                    key={series.seriesName}
                  >
                    <SeriesOffers
                      ctas={ctas}
                      preselectedFilters={preselectedFilters}
                      series={series}
                      targetFilterYear={targetFilterYear}
                    />
                  </div>
                ))}
                {specialOffers && specialOffers.length > 0 && (
                  <SpecialOffers ctas={ctas} offers={specialOffers} />
                )}
              </LoadingContent>
            </ScrollToTop>
          </div>
        </div>
      </AnalyticsContext>
    </RootAnalyticsContext>
  );
};

export default OffersView;
