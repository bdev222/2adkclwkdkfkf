export const heading: string;
export const container: string;
export const offersCount: string;
