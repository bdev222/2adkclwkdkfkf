import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';

import LazyImage from '../../../../../../components/html5/LazyImage';
import { Badge } from '../../../models';
import styles from './styles.module.scss';

interface MobileBadgesProps {
  badges: Badge[];
}

const MobileBadges: FC<MobileBadgesProps> = ({ badges }) => {
  useStyles(styles);

  return (
    <div className={styles.badges}>
      {badges.map((badge, index) => (
        <LazyImage src={badge.image} alt={badge.description} key={index} />
      ))}
    </div>
  );
};

export default MobileBadges;
