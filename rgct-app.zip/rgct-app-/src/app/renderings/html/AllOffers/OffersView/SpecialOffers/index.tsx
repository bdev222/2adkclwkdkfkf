import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import OfferCard from '../../../../../components/html5/OfferCard';
import OffersCtas from '../../../../../components/html5/OffersCtas';
import AnalyticsContext from '../../../../../components/shared/Analytics/AnalyticsContext';
import createSectionBlock from '../../../../../components/shared/Analytics/blocks/createSectionBlock';
import { Location } from '../../../../../util/campaignCodes';
import { Offer, OffersView } from '../../models';
import Header from '../Header';
import styles from './styles.module.scss';

interface SpecialOffersProps {
  ctas?: OffersView['ctas'];
  offers: Offer[];
}

const SpecialOffers: FC<SpecialOffersProps> = ({ ctas, offers }) => {
  useStyles(styles);

  const { t } = useTranslation('offer');

  return (
    <>
      <Header heading={t('specialOffers')} offersCount={offers.length} />
      <AnalyticsContext blocks={createSectionBlock('special_offers')}>
        <div className={styles.offers}>
          {offers.map(offer => (
            <OfferCard key={offer.id} offer={offer} />
          ))}
        </div>
      </AnalyticsContext>
      {ctas && <OffersCtas ctas={ctas} location={Location.ModalAllOffers} />}
    </>
  );
};

export default SpecialOffers;
