import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import styles from './styles.module.scss';

interface HeaderProps {
  heading: string;
  offersCount: number;
}

const Header: FC<HeaderProps> = ({ heading, offersCount }) => {
  useStyles(styles);

  const { t } = useTranslation();

  return (
    <header className={styles.container}>
      <h1 className={styles.heading}>{heading}</h1>
      <p className={styles.offersCount}>
        {t('availableOffers', { count: offersCount })}
      </p>
    </header>
  );
};

export default Header;
