export const badges: string;
