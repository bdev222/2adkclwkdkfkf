import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import NoOffers from '../../../../../components/html5/NoOffers';
import OfferCard from '../../../../../components/html5/OfferCard';
import OffersCtas from '../../../../../components/html5/OffersCtas';
import AnalyticsContext from '../../../../../components/shared/Analytics/AnalyticsContext';
import createSeriesBlock from '../../../../../components/shared/Analytics/blocks/createSeriesBlock';
import { Location } from '../../../../../util/campaignCodes';
import getSeriesWithYear from '../../../../../util/getSeriesWithYear';
import { OffersView, PreselectedFilters, Series } from '../../models';
import Header from '../Header';
import Hero from './Hero';
import MobileBadges from './MobileBadges';
import OffersUnavailable from './OffersUnavailable';
import styles from './styles.module.scss';

interface SeriesOffersProps {
  ctas: OffersView['ctas'];
  preselectedFilters: PreselectedFilters;
  series: Series;
  targetFilterYear?: string;
}

const SeriesOffers: FC<SeriesOffersProps> = ({
  ctas,
  preselectedFilters,
  targetFilterYear,
  series: {
    badges,
    bgImages,
    defaultJelly,
    estimates,
    isInvalidModelYear,
    jelly,
    offers,
    offersCount,
    relatedOffers,
    seriesId,
    seriesName,
    year,
  },
}) => {
  useStyles(styles);

  const { t } = useTranslation();

  const heading = targetFilterYear
    ? t('seriesWithYear', getSeriesWithYear(seriesName, targetFilterYear))
    : seriesName;

  const shouldShowHero = !!(badges || bgImages || jelly);

  return (
    <>
      <div className={styles.header}>
        <div className={styles.hero}>
          {shouldShowHero && (
            <Hero
              badges={badges}
              bgImages={bgImages}
              jelly={jelly}
              seriesName={seriesName}
            />
          )}
        </div>
        <Header heading={heading} offersCount={offersCount} />
      </div>
      <AnalyticsContext blocks={createSeriesBlock({ seriesName, year })}>
        <div
          className={cc([
            styles.offers,
            { [styles.hasOffers]: offers.length || relatedOffers.length },
          ])}
        >
          {offers.length ? (
            offers.map(offer => <OfferCard key={offer.id} offer={offer} />)
          ) : estimates ? (
            <NoOffers
              estimates={estimates}
              seriesName={seriesName}
              vehicle={{
                ...defaultJelly,
                seriesId,
                seriesName,
                year,
              }}
            />
          ) : isInvalidModelYear ? (
            <OffersUnavailable
              heading={heading}
              preselectedFilters={preselectedFilters}
              seriesId={seriesId}
              seriesName={seriesName}
            />
          ) : null}
          {relatedOffers.map(offer => (
            <OfferCard key={offer.id} offer={offer} />
          ))}
        </div>
      </AnalyticsContext>
      {badges && <MobileBadges badges={badges} />}
      {ctas && !isInvalidModelYear && (
        <OffersCtas
          backgroundImages={bgImages}
          ctas={ctas}
          location={Location.ModalAllOffers}
          vehicle={{
            ...defaultJelly,
            seriesId,
            seriesName,
            year,
          }}
        />
      )}
    </>
  );
};

export default SeriesOffers;
