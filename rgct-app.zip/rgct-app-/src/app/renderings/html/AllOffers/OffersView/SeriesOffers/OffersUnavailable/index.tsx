import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC } from 'react';
import { useTranslation } from 'react-i18next';

import Button from '../../../../../../components/html5/Button';
import AnalyticsContext from '../../../../../../components/shared/Analytics/AnalyticsContext';
import createSectionBlock from '../../../../../../components/shared/Analytics/blocks/createSectionBlock';
import { PreselectedFilters } from '../../../models';
import styles from './styles.module.scss';

interface OffersUnavailableProps {
  heading: string;
  preselectedFilters: PreselectedFilters;
  seriesId: string;
  seriesName: string;
}

const OffersUnavailable: FC<OffersUnavailableProps> = ({
  heading,
  preselectedFilters,
  seriesId,
  seriesName,
}) => {
  useStyles(styles);

  const { t } = useTranslation('allOffers');

  const viewOffersParams = [];

  if (preselectedFilters.offers) {
    viewOffersParams.push(`offers=${preselectedFilters.offers.join(',')}`);
  }

  if (preselectedFilters.vehicles) {
    const vehiclesParam = [
      ...new Set([...preselectedFilters.vehicles, seriesId]),
    ].join(',');

    viewOffersParams.push(`vehicles=${vehiclesParam}`);
  }

  let year;
  if (preselectedFilters.years) {
    year = preselectedFilters.years.join(', ');
  }

  const searchOffersLabel = t('searchOffers');

  return (
    <AnalyticsContext blocks={[createSectionBlock('offers are not available')]}>
      <div className={styles.container}>
        <div className={styles.content}>
          <p>{t('offersUnavailable', { seriesName, year })}</p>
          <p>{t('seeAvailableOffers', { seriesName })}</p>
        </div>
        <Button
          analytics={{ text: searchOffersLabel, typeTitle: heading }}
          as="a"
          to={`?${viewOffersParams.join('&')}`}
        >
          {searchOffersLabel}
        </Button>
      </div>
    </AnalyticsContext>
  );
};

export default OffersUnavailable;
