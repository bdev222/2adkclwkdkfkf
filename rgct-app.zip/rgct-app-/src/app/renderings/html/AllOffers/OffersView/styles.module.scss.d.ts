export const container: string;
export const sidebar: string;
export const offersContainer: string;
export const series: string;
export const hasDivider: string;
