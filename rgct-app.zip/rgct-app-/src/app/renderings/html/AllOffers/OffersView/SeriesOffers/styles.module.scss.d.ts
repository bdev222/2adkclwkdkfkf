export const offers: string;
export const hasOffers: string;
export const header: string;
export const hero: string;
