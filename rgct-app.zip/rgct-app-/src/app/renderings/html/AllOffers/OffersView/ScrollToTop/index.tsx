import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useEffect, useState } from 'react';
import { useInView } from 'react-intersection-observer';

import { IconArrowUp } from '../../../../../components/html5/Icons';
import AnalyticsButton from '../../../../../components/shared/Analytics/AnalyticsButton';
import styles from './styles.module.scss';

const ScrollToTop: FC = ({ children }) => {
  useStyles(styles);

  // Top is used to determine when to show scroll to top button
  const [refTop, inViewTop, entryTop] = useInView({
    rootMargin: '200px',
  });
  const [showScroll, setShowScroll] = useState(false);

  // Bottom is used to determine when to change scroll to top button to absolute positioning
  // so that it never overlaps the Footer
  const [refBottom, inViewBottom, entryBottom] = useInView({
    rootMargin: '0px 0px -45px 0px',
  });
  const [isAbsolute, setIsAbsolute] = useState(false);

  useEffect(() => {
    if (entryTop) {
      setShowScroll(!inViewTop);
    }
  }, [entryTop, inViewTop]);

  useEffect(() => {
    if (entryBottom) {
      setIsAbsolute(inViewBottom || entryBottom.boundingClientRect.top < 0);
    }
  }, [entryBottom, inViewBottom]);

  const scrollTop = () => {
    const hasSmooth = getComputedStyle(document.body).scrollBehavior;

    if (hasSmooth) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      const animateToTop = () => {
        const top =
          document.documentElement.scrollTop || document.body.scrollTop;

        if (top > 0) {
          window.requestAnimationFrame(animateToTop);
          window.scrollTo({ top: top - top / 8 });
        }
      };

      animateToTop();
    }
  };

  return (
    <>
      <span className={styles.intersection} ref={refTop} />
      {children}
      <AnalyticsButton
        analytics={{ text: 'Back To Top' }}
        className={cc([
          styles.button,
          {
            [styles.isShowing]: showScroll,
            [styles.isAbsolute]: isAbsolute,
          },
        ])}
        onClick={scrollTop}
      >
        <IconArrowUp />
      </AnalyticsButton>
      <span className={styles.intersection} ref={refBottom} />
    </>
  );
};

export default ScrollToTop;
