import { QueryParams } from '../../../../../../util/QueryParams';

export default function saveFiltersState(filterParams: QueryParams): void {
  const queryParams = [];

  const vehicles = filterParams.get('vehicles');
  const years = filterParams.get('years');
  const offerTypes = filterParams.get('offers');

  if (Array.isArray(vehicles) && vehicles.length > 0) {
    queryParams.push(`vehicles=${vehicles.join(',')}`);
  }

  if (Array.isArray(years) && years.length > 0) {
    queryParams.push(`years=${years.join(',')}`);
  }

  if (Array.isArray(offerTypes) && offerTypes.length > 0) {
    queryParams.push(`offers=${offerTypes.join(',')}`);
  }

  const savedQueryParams =
    queryParams.length > 0 ? queryParams.join('&') : 'viewAllOffers=1';

  window.sessionStorage.setItem('rgct:allOffers:queryParams', savedQueryParams);
}
