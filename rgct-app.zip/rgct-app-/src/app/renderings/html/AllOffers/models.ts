import type {
  AllOffersFields,
  Badge,
  Jelly,
  Offer,
  OffersView,
  PreselectedFilters,
  PreselectView,
  Series,
  SeriesCategory,
  SeriesItem,
} from '../../../../functions/layout/transforms/allOffers/models';
import type { BackgroundImages } from '../../../../functions/layout/transforms/util/getBackgroundImages/';

export {
  AllOffersFields,
  BackgroundImages,
  Badge,
  Jelly,
  Offer,
  OffersView,
  PreselectedFilters,
  PreselectView,
  Series,
  SeriesCategory,
  SeriesItem,
};

export type Ctas = OffersView['ctas'];

export type Filters = OffersView['filters'];
