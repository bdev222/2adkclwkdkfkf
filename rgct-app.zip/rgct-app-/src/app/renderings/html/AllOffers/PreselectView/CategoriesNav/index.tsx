import cc from 'classcat';
import useStyles from 'isomorphic-style-loader/useStyles';
import React, { FC, useEffect } from 'react';
import { useTranslation } from 'react-i18next';

import { IconCar } from '../../../../../components/html5/Icons';
import Link from '../../../../../components/html5/Link';
import AnalyticsButton from '../../../../../components/shared/Analytics/AnalyticsButton';
import AnalyticsContext from '../../../../../components/shared/Analytics/AnalyticsContext';
import createOffersListBlock from '../../../../../components/shared/Analytics/blocks/createOffersListBlock';
import createSectionBlock from '../../../../../components/shared/Analytics/blocks/createSectionBlock';
import { ExperienceType } from '../../../../../util/getSessionExperience';
import { QueryParams } from '../../../../../util/QueryParams';
import { SeriesCategory } from '../../models';
import styles from './styles.module.scss';

interface CategoriesNavProps {
  categoryInView: string;
  didFetchAllOffers: boolean;
  experienceType: ExperienceType | null;
  offersCount: number;
  onSelectedModalOpen: () => void;
  onViewOffersClick: () => void;
  selectedSeriesCount: number;
  seriesCategories: SeriesCategory[];
}

const CategoriesNav: FC<CategoriesNavProps> = ({
  categoryInView,
  didFetchAllOffers,
  experienceType,
  offersCount,
  onSelectedModalOpen,
  onViewOffersClick,
  selectedSeriesCount,
  seriesCategories,
}) => {
  useStyles(styles);

  const { t } = useTranslation('preselect');

  useEffect(() => {
    document.body.classList.add(styles.padBodyBottom);

    return () => {
      document.body.classList.remove(styles.padBodyBottom);
    };
  }, []);

  const selectedParams = new QueryParams('selected[]');

  const isShowOffersButton = experienceType === 'control';

  return (
    <AnalyticsContext
      blocks={[
        createSectionBlock('preselect_offers_vehicle_nav'),
        createOffersListBlock(selectedParams.get('selected').toString()),
      ]}
    >
      <nav className={styles.nav}>
        <ul className={styles.navList}>
          {seriesCategories.map(category => (
            <li className={styles.navLinkContainer} key={category.id}>
              <Link
                as="a"
                className={cc([
                  styles.navLink,
                  { [styles.isInView]: categoryInView === category.id },
                ])}
                to={`#${category.id}`}
              >
                <span dangerouslySetInnerHTML={{ __html: category.label }} />
              </Link>
            </li>
          ))}
        </ul>
        {isShowOffersButton && (
          <AnalyticsButton
            analytics={{ typeTitle: 'View all Offers' }}
            type="button"
            className={cc([styles.viewOffersBtn, styles.desktopOffersBtn])}
            onClick={onViewOffersClick}
          >
            <span>
              {didFetchAllOffers
                ? t('common:viewAllOffers')
                : offersCount === 0
                ? t('common:continue')
                : t('offersCount', { count: offersCount })}
            </span>
          </AnalyticsButton>
        )}
      </nav>
      {isShowOffersButton && (
        <div className={styles.mobileOffersBar}>
          {selectedSeriesCount > 0 && (
            <button
              className={styles.btnMobileSelected}
              onClick={onSelectedModalOpen}
            >
              <div className={styles.mobileSelectedCount}>
                <IconCar />
                <span>{selectedSeriesCount}</span>
              </div>
            </button>
          )}
          <AnalyticsButton
            analytics={{ typeTitle: 'View all Offers' }}
            type="button"
            className={styles.viewOffersBtn}
            onClick={onViewOffersClick}
          >
            <span>
              {offersCount === 0
                ? t('common:continue')
                : t('offersCount', { count: offersCount })}
            </span>
          </AnalyticsButton>
        </div>
      )}
    </AnalyticsContext>
  );
};

export default CategoriesNav;
