import { JSDSRendering } from 'jsds-react';
import React, { FC } from 'react';

import { AllOffersFields } from './models';
import OffersView from './OffersView';
import PreselectView from './PreselectView';

type AllOffersProps = JSDSRendering<AllOffersFields>;

const AllOffers: FC<AllOffersProps> = ({ fields }) => {
  return fields.view === 'offers' ? (
    <OffersView {...fields} />
  ) : (
    <PreselectView {...fields} />
  );
};

export default AllOffers;
