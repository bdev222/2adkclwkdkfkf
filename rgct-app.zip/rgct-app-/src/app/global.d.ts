declare module '*.html' {
  const value: string;
  export default value;
}

declare module '*.scss';

declare module '*.css';

type Subtract<T, K> = Omit<T, keyof K>;

interface Window {
  __SSR_I18N__?: any;
  __SSR_STATE__?: any;
  DGDataHub?: any;
  fireTag?: (event: string, data: any) => void;
  IntersectionObserver: IntersectionObserver; // https://github.com/Microsoft/TypeScript/issues/16255
  mboxRecipe?: any[];
  tcom_v2?: any;
}

declare namespace React {
  interface HTMLAttributes<T> extends DOMAttributes<T> {
    on?: string;
  }
}

declare namespace JSX {
  interface IntrinsicElements {
    'amp-accordion': any;
    'amp-img': any;
    'amp-list': any;
    'amp-sidebar': any;
  }
}
