exports.ids = ["OfferDetail"];
exports.modules = {

/***/ "./src/app/components/shared/Analytics/blocks/createSuppressPageLoadBlock/index.ts":
/*!*****************************************************************************************!*\
  !*** ./src/app/components/shared/Analytics/blocks/createSuppressPageLoadBlock/index.ts ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return createSupressPageLoadBlock; });
function createSupressPageLoadBlock(){return{suppressPageLoad:'true'};}

/***/ }),

/***/ "./src/app/renderings/html/OfferDetail/index.tsx":
/*!*******************************************************!*\
  !*** ./src/app/renderings/html/OfferDetail/index.tsx ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_object_assign__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.assign */ "./node_modules/core-js/modules/es.object.assign.js");
/* harmony import */ var core_js_modules_es_object_assign__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_assign__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_html5_OfferDetail__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../components/html5/OfferDetail */ "./src/app/components/html5/OfferDetail/index.tsx");
/* harmony import */ var _components_shared_Analytics_blocks_createSuppressPageLoadBlock__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../components/shared/Analytics/blocks/createSuppressPageLoadBlock */ "./src/app/components/shared/Analytics/blocks/createSuppressPageLoadBlock/index.ts");
/* harmony import */ var _components_shared_Analytics_RootAnalyticsContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../components/shared/Analytics/RootAnalyticsContext */ "./src/app/components/shared/Analytics/RootAnalyticsContext/index.tsx");
function _extends(){_extends=Object.assign||function(target){for(var i=1;i<arguments.length;i++){var source=arguments[i];for(var key in source){if(Object.prototype.hasOwnProperty.call(source,key)){target[key]=source[key];}}}return target;};return _extends.apply(this,arguments);}var OfferDetail=function OfferDetail(_ref){var fields=_ref.fields;return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_components_shared_Analytics_RootAnalyticsContext__WEBPACK_IMPORTED_MODULE_4__["default"],{blocks:Object(_components_shared_Analytics_blocks_createSuppressPageLoadBlock__WEBPACK_IMPORTED_MODULE_3__["default"])()},react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_components_html5_OfferDetail__WEBPACK_IMPORTED_MODULE_2__["default"],_extends({},fields,{fireInitialKeyMetric:true})));};/* harmony default export */ __webpack_exports__["default"] = (OfferDetail);

/***/ })

};;
//# sourceMappingURL=OfferDetail.js.map